# FinX — Multi-Domain, Multilingual & Firebase Full-Stack Enhancement Plan

FinX will be upgraded in place—preserving all existing working routes, components, and the Gemini assistant bridge—into a persistent, multi-user, multi-business financial platform backed by Firebase Authentication and Cloud Firestore, featuring five visually distinct domain experiences with 3D perspective logos, complete multilingual coverage, a friendly search-grounded voice assistant, and a live Year-to-Date (YTD) financial ledger.

### User Review & Critical Decisions

> [!IMPORTANT]
> Confirmed Phase 1 selections and key architectural notes for approval before modifying code:
> - **Confirmed Persistence & Auth**: **Firebase Auth + Cloud Firestore** (provisioned via AI Studio Firebase setup and secured with strict owner-scoped Firestore rules and audit logging).
> - **Confirmed 3D Domain Branding**: **Lightweight 3D CSS & SVG perspective animations** tailored per domain, hardware-accelerated (`transform`/`opacity`) with an automatic `prefers-reduced-motion` and low-power accessibility toggle.
> - **Confirmed Assistant & Voice Direction**: **Friendly, secure, context-aware FinX Voice & Text Assistant** powered by Gemini with **live Google Search grounding** (`googleSearch`), source citations with dates, spontaneous chat language switching independent of UI language, and strict financial safety boundaries.
> - **Sign-In Provider Note**: Provisioned Firebase projects enable **Google Sign-In** (`signInWithPopup`) out of the box. Email/Password login UI will also be offered cleanly alongside Google Sign-In, with clear setup guidance if Email/Password is not yet enabled in the Firebase Console, plus an explicit Demo Workspace preview banner if a visitor explores prior to signing in.

---

### 1. Overview & Core Concept

- **What It Does**: Transforms FinX from an in-memory single-workspace prototype into an isolated multi-user, multi-business financial operating system. Users authenticate, select their preferred avatar presentation (Male, Female, or Neutral—or upload a compressed custom portrait), choose active financial domains during onboarding or settings, create multiple independent Business or Consultancy workspaces, track real Year-to-Date transactions from the top-right dashboard header, and converse via voice or text in 21+ languages.
- **Target Audience / Persona**: Individuals managing personal budgets, retail/product entrepreneurs tracking SKU inventory and suppliers, consultancy founders managing client retainers and payroll, retail learners exploring investment concepts, and analysts forecasting cross-domain cash flow.
- **Key Value**: Real persistent cloud storage per user and per business profile, zero cross-domain template cloning, effortless multitasking across accounts without losing form drafts, and reliable multilingual voice execution.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Welcome & Pre-Login Discovery**: Visitors see the existing FinX Welcome experience with an always-accessible, friendly "Talk to FinX" voice/text companion (unable to access private data until signed in) and searchable global language selector.
  2. **Personalized Login & Registration**: Two-column layout featuring custom illustrated avatar previews. Users explicitly choose **Male**, **Female**, or **Neutral** avatar presentation (never auto-inferred from name) or upload a cropped photo, select preferred domains (1 to 5), and receive a warm personalized welcome banner upon entering the dashboard.
  3. **Domain Onboarding & Multi-Business Switcher**: Users can toggle active domains on/off, create multiple Product Business or Consultancy profiles (each with isolated ledgers, inventory, clients, and branding), and switch active workspaces from the persistent header bar.
  4. **Top-Right YTD Transactions Hub**: Available at the top-right of the global dashboard header (and filtered automatically when viewed inside a specific domain). Opens a clean non-destructive drawer/panel with Financial Year selector, Monthly / Quarterly / Yearly aggregations, domain/type/date filters, live saved record table, manual refresh button, last-updated timestamp, and loading/error states.
  5. **Multitasking Workspace**: Persistent unsaved-draft preservation across route/panel switches, global search (`Ctrl+K` / header search), clickable breadcrumb + back trail, quick-action triggers, notification center, recent activity feed, and duplicate-submit guards with clear toast confirmations.

- **Visual Identity & Domain-Specific Palettes**:
  Each of the five financial domains maintains a 60-30-10 surface-to-accent discipline, single-elevation cards (`1px` subtle borders, no card-within-card nesting, no thick left borders, and zero static pill enclosures), while expressing a unique visual mood and dedicated 3D animated SVG perspective emblem on entry:
  1. **Individual Finance**: *Calm Blue, Deep Teal & Soft Neutral* (`#0EA5E9` / `#14B8A6` accents on clean slate-tinted canvas) — 3D kinetic vault & compass emblem. Focus: cashflow calendar, budgets, goals, recurring bills/subscriptions.
  2. **Product Business Finance**: *Vibrant Amber-Orange, Navy Blue & Warm Neutral* (`#EA580C` / `#1E3A8A`) — 3D isometric stacked crate & ledger prism. Focus: SKU catalog, supplier/customer directory, sales & purchase orders, low-stock alerts, P&L, sales forecasting.
  3. **Service & Consultancy Finance**: *Royal Purple, Crisp Violet & White/Light-Slate Gradients* (`#7C3AED` / `#8B5CF6`) — 3D layered orbital nodes & retainer crest. Focus: client & retainer CRM, milestone profitability, itemized invoice generation & printable view, payment tracking, staff payroll.
  4. **Investment Intelligence**: *Emerald Green, Dark Navy & Burnished Gold* (`#059669` / `#D97706` on `#0B1324`) — 3D faceted emerald prism & orbital trend arc. Focus: simulated paper portfolio, allocation breakdown, risk/return comparisons, calculators, educational guides (no return guarantees).
  5. **Financial Intelligence**: *Deep Navy, Cyan & Electric Blue* (`#06B6D4` / `#2563EB` on `#09111F`) — 3D glassmorphic data cube & neural grid. Focus: cross-business comparisons, cash-flow forecasting, scenario modeling, anomaly detection, AI report generation, document extraction.

- **Typography & Script Completeness**:
  - **Display & UI**: `Plus Jakarta Sans` paired with `DM Sans`, plus `JetBrains Mono` (`tabular-nums`) for all currency figures, percentages, timestamps, and ledger tables.
  - **Multilingual Script Fonts**: Load Google Fonts for `Noto Sans Telugu`, `Noto Sans Devanagari` (Hindi/Marathi), `Noto Sans Tamil`, `Noto Sans Kannada`, `Noto Sans Malayalam`, `Noto Sans Bengali`, `Noto Sans Gujarati`, and `Noto Sans Arabic` (with automatic RTL layout switching for Arabic and Urdu) so every script renders cleanly without fallback boxes.
  - **Consistent Icons & Accessibility**: All icons paired with clear visible labels or tooltips, uniform sizing, `>= 40px` touch targets, `focus-visible` outlines, and full keyboard navigation.

- **Interactive Feedback & 3D Motion**:
  - Entering any domain plays a crisp, non-blocking 3D CSS perspective brand entrance highlighting the domain logo and user's active business name (`transform`/`opacity` only, `< 450ms` settle, immediately interactive, skipped cleanly when `Reduced Motion` is enabled).

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Client-Owned Firestore Persistence + Security Rules vs. Custom Backend DB**:
  - *Chosen Approach*: Use **Firebase Authentication** and **Cloud Firestore** with per-user root ownership and workspace subcollections, enforced by hardened Eight-Pillar `firestore.rules` deployed to the project and mirrored in `firebase-blueprint.json`.
  - *Why*: Eliminates ephemeral in-memory resets, guarantees user-specific and business-specific data isolation even across refreshes/devices, and avoids starter-tier IAM issues with server-side Admin SDK.
  - *Alternatives Considered*: Express JSON/SQLite storage (rejected per user selection of Firebase Auth + Cloud Firestore).

- **Decision 2 — Profile Photo Upload Storage within Firestore**:
  - *Chosen Approach*: Provide curated SVG illustrated avatar presets (Male, Female, Neutral) plus optional client-side image upload automatically cropped and compressed to a compact square thumbnail (`<= 48 KB` data URL) validated strictly by max-length rules in Firestore.
  - *Why*: Works reliably alongside Auth + Firestore without provisioning external object buckets while staying far under Firestore's 1 MB document ceiling.

- **Decision 3 — Friendly Voice + Grounded Search Without Response-Schema Conflicts**:
  - *Chosen Approach*: Upgrade the Express `/api/assistant/chat` bridge to use `gemini-4-hydrogen` with `{ googleSearch: {} }` grounding when live facts, market rates, or current events are relevant, returning verified grounding source links (`groundingChunks`) and dates alongside conversational replies—plus optional structured navigation intent parsing.
  - *Why*: Delivers a warm, conversational, up-to-date assistant that explicitly separates verified live facts (with clickable sources), workspace numbers, estimates, and opinions without fabricating news or financial returns.

- **Decision 4 — Strict Voice Stability & Permissions Governance**:
  - *Chosen Approach*: Persist exact `voiceInputLocale`, `voiceOutputLocale`, and `voiceOutputVoiceURI` in Firestore user settings; bind explicit TTS/STT state transitions (`idle -> requesting-permission -> listening -> processing -> speaking`); abort stale utterances cleanly; prevent duplicate command firing via speech recognition debouncing and mic lock during TTS playback; provide a 1-click Stop Speech button and always-available text input alternative.

---

### 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **System Architecture Diagram**:

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          FinX React Client (SPA)                        │
│  ┌──────────────┐  ┌────────────────────┐  ┌─────────────────────────┐  │
│  │ Auth & Avatar│  │  5 Domain Modules  │  │  Top-Right YTD Hub +    │  │
│  │  Onboarding  │  │  (3D CSS/SVG Logos │  │  Multitask Draft Store  │  │
│  │ (M/F/Neutral)│  │   & Isolated UI)   │  │  (Global Search, Toasts)│  │
│  └──────┬───────┘  └─────────┬──────────┘  └────────────┬────────────┘  │
│         │                    │                          │               │
│  ┌──────▼────────────────────▼──────────────────────────▼────────────┐  │
│  │  FinX State, i18next (21+ Langs + RTL) & Voice Engine (STT/TTS)   │  │
│  └──────┬───────────────────────────────────────────────┬────────────┘  │
└─────────┼───────────────────────────────────────────────┼───────────────┘
          │ Firebase SDK (Auth + Live Listeners)          │ HTTPS / JSON
          ▼                                               ▼
┌───────────────────────────┐             ┌───────────────────────────────┐
│   Firebase Cloud Project  │             │   Express Backend (Port 3000) │
│  • Firebase Auth (Google  │             │  • /api/assistant/chat        │
│    + Email/Password UI)   │             │    - gemini-4-hydrogen        │
│  • Cloud Firestore        │             │    - googleSearch grounding   │
│    - Users & Avatars      │             │    - Spontaneous lang detect  │
│    - Workspaces / Profiles│             │  • /api/assistant/health      │
│    - Domain Ledgers & YTD │             │  • Server-side GEMINI_API_KEY │
│    - Audit & Activity Logs│             └───────────────────────────────┘
│  • Hardened security rules│
└───────────────────────────┘
```

- **Firestore Data Model & Isolation**:
  - **User Profile & Preferences**: Stores display name, explicit `avatarCategory` (`male` | `female` | `neutral`), `avatarPresetId` or bounded `customPhotoDataUrl`, `enabledDomains[]`, `activeWorkspaceId`, UI language, independent AI text language, persisted voice locale & voice URI, and currency/accessibility preferences.
  - **Workspaces / Business Profiles (Owned per `userId`)**: Allows multiple Product Business and Service/Consultancy profiles (plus Personal & Investment containers), each holding its own name, domain type, branding accent, and metadata so two businesses never leak records into one another.
  - **Domain Subcollections (Scoped under `users/{userId}/workspaces/{workspaceId}/...`)**:
    - *Transactions & Budgets*: Personal income/expenses, budgets, savings goals, recurring bills, subscriptions, plus business sales, purchases, and operating expenses—indexed by fiscal date and domain for instant server/client-validated YTD aggregation.
    - *Product Catalog & Parties*: SKUs, reorder thresholds, suppliers, and customers.
    - *Service Operations*: Clients, projects, milestone invoices, and staff payroll entries.
    - *Investment & Intelligence*: Simulated paper portfolio positions, saved scenarios, and uploaded document metadata.
    - *Audit Logs*: Immutable timestamped entries recording create/update/delete events, domain switching, and workspace actions for transparency and security verification.

- **Interactive Component & State Mapping**:
  - **Firestore Connection & Error Boundary**: Startup `getDocFromServer` connectivity verification plus a unified `handleFirestoreError` wrapper surfacing `OperationType` and path context to a clean React `ErrorBoundary`.
  - **Draft-Preserving Multitasking Context**: Form states across transaction entry, invoicing, inventory creation, and planner items live in a lightweight draft cache keyed by workspace/route so inspecting YTD transactions, answering an AI voice prompt, or checking notifications never discards unsaved user typing.
  - **Real YTD Computation Engine**: Recomputes Monthly, Quarterly, and Yearly summaries exclusively from live Firestore-persisted records matching the active user and selected domain/business filter; manual Refresh re-queries server snapshots and updates the exact last-synced timestamp.
  - **Staged Delivery & Verification Sequence**:
    1. *Stage 1*: Provision Firebase (`firebase_setup` UI -> `ProvisionFirebase`), author `firebase-blueprint.json`, `security_spec.md`, `firestore.rules.test.ts`, ESLint security rules audit, and deploy `firestore.rules`.
    2. *Stage 2*: Implement Firebase Auth + Personalized Login/Registration/Settings (Male/Female/Neutral avatars + compressed photo upload + post-login greeting) + User/Workspace persistence layer & Audit Logs.
    3. *Stage 3*: Complete 21+ language i18n coverage across every page/dialog/error + Indic/Arabic fonts + RTL layout + Hardened Voice Assistant settings & speech stability.
    4. *Stage 4*: Implement Multi-Domain onboarding/picker, Multi-Business switcher, 5 distinct domain color/feature workspaces with lightweight 3D CSS/SVG perspective emblems, updated icons/tooltips, and multitasking draft/search/breadcrumb UX.
    5. *Stage 5*: Build Top-Right YTD Transactions widget & full drawer backed 100% by Firestore records, with Financial Year, period views, domain filters, and manual refresh.
    6. *Stage 6*: Upgrade FinX AI backend (`gemini-4-hydrogen`, spontaneous language matching, `googleSearch` live grounding with source citations/dates, and strict facts-vs-estimates separation).
    7. *Stage 7*: Full verification via `vite build`, TypeScript lint, Firestore security rules ESLint + tests, and live API/UI smoke checks across pre-login and authenticated flows.
