import React, { Suspense, lazy } from 'react';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ToastStack } from './components/ToastStack';
import { FinXProvider, useFinX } from './context/FinXContext';
import { DashboardLayout } from './layouts/DashboardLayout';
import { WelcomePage } from './pages/WelcomePage';

const AuthPage = lazy(() => import('./pages/AuthPage').then((m) => ({ default: m.AuthPage })));
const DashboardPage = lazy(() => import('./pages/DashboardPage').then((m) => ({ default: m.DashboardPage })));
const PersonalFinancePage = lazy(() =>
  import('./pages/PersonalFinancePage').then((m) => ({ default: m.PersonalFinancePage }))
);
const ProductBusinessPage = lazy(() =>
  import('./pages/ProductBusinessPage').then((m) => ({ default: m.ProductBusinessPage }))
);
const ServiceBusinessPage = lazy(() =>
  import('./pages/ServiceBusinessPage').then((m) => ({ default: m.ServiceBusinessPage }))
);
const InvestmentKnowledgePage = lazy(() =>
  import('./pages/InvestmentKnowledgePage').then((m) => ({ default: m.InvestmentKnowledgePage }))
);
const FinancialIntelligencePage = lazy(() =>
  import('./pages/FinancialIntelligencePage').then((m) => ({ default: m.FinancialIntelligencePage }))
);
const FinXAssistantPage = lazy(() =>
  import('./pages/FinXAssistantPage').then((m) => ({ default: m.FinXAssistantPage }))
);
const FinXMessagesPage = lazy(() =>
  import('./pages/FinXMessagesPage').then((m) => ({ default: m.FinXMessagesPage }))
);
const DocumentAnalyzerPage = lazy(() =>
  import('./pages/DocumentAnalyzerPage').then((m) => ({ default: m.DocumentAnalyzerPage }))
);
const SmartPlannerPage = lazy(() =>
  import('./pages/SmartPlannerPage').then((m) => ({ default: m.SmartPlannerPage }))
);
const ExtensionCenterPage = lazy(() =>
  import('./pages/ExtensionCenterPage').then((m) => ({ default: m.ExtensionCenterPage }))
);
const LearningCenterPage = lazy(() =>
  import('./pages/LearningCenterPage').then((m) => ({ default: m.LearningCenterPage }))
);
const ReportsAnalyticsPage = lazy(() =>
  import('./pages/ReportsAnalyticsPage').then((m) => ({ default: m.ReportsAnalyticsPage }))
);
const PrivacySecurityPage = lazy(() =>
  import('./pages/PrivacySecurityPage').then((m) => ({ default: m.PrivacySecurityPage }))
);
const SettingsPage = lazy(() => import('./pages/SettingsPage').then((m) => ({ default: m.SettingsPage })));
const VoiceCompanionOverlay = lazy(() =>
  import('./assistant/VoiceCompanionOverlay').then((m) => ({ default: m.VoiceCompanionOverlay }))
);
const YtdTransactionsDrawer = lazy(() =>
  import('./components/YtdTransactionsDrawer').then((m) => ({ default: m.YtdTransactionsDrawer }))
);

const PageLoader: React.FC<{ fullScreen?: boolean }> = ({ fullScreen = false }) => (
  <div
    className={`${
      fullScreen ? 'min-h-screen bg-slate-50 dark:bg-[#101827]' : 'min-h-[360px]'
    } flex items-center justify-center p-6`}
  >
    <div className="text-center space-y-3">
      <div className="w-9 h-9 mx-auto rounded-xl border-2 border-teal-500 border-t-transparent animate-spin" />
      <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
        Loading FinX module...
      </p>
    </div>
  </div>
);

const FinXRouter: React.FC = () => {
  const { route, isAuthenticated, authLoading } = useFinX();

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-[#101827] flex items-center justify-center p-6">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 mx-auto rounded-xl border-2 border-teal-500 border-t-transparent animate-spin" />
          <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
            Initializing FinX workspace...
          </p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    if (route === 'login') {
      return (
        <Suspense fallback={<PageLoader fullScreen />}>
          <AuthPage key="login" mode="login" />
        </Suspense>
      );
    }
    if (route === 'register') {
      return (
        <Suspense fallback={<PageLoader fullScreen />}>
          <AuthPage key="register" mode="register" />
        </Suspense>
      );
    }
    return <WelcomePage />;
  }

  const renderWorkspacePage = () => {
    switch (route) {
      case 'dashboard':
        return <DashboardPage />;
      case 'personal-finance':
        return <PersonalFinancePage />;
      case 'product-business':
        return <ProductBusinessPage />;
      case 'service-business':
        return <ServiceBusinessPage />;
      case 'investment-knowledge':
        return <InvestmentKnowledgePage />;
      case 'financial-intelligence':
        return <FinancialIntelligencePage />;
      case 'assistant':
        return <FinXAssistantPage />;
      case 'messages':
        return <FinXMessagesPage />;
      case 'documents':
        return <DocumentAnalyzerPage />;
      case 'planner':
        return <SmartPlannerPage />;
      case 'extensions':
        return <ExtensionCenterPage />;
      case 'learning':
        return <LearningCenterPage />;
      case 'reports':
        return <ReportsAnalyticsPage />;
      case 'security':
        return <PrivacySecurityPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <DashboardLayout>
      <Suspense fallback={<PageLoader />}>{renderWorkspacePage()}</Suspense>
    </DashboardLayout>
  );
};

export default function App() {
  return (
    <ErrorBoundary>
      <FinXProvider>
        <FinXRouter />
        <Suspense fallback={null}>
          <VoiceCompanionOverlay />
          <YtdTransactionsDrawer />
        </Suspense>
        <ToastStack />
      </FinXProvider>
    </ErrorBoundary>
  );
}
