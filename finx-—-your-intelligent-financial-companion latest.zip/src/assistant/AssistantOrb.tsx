import React from 'react';
import { Mic, Volume2 } from 'lucide-react';
import { VoiceStatus } from '../types/finx';

interface AssistantOrbProps {
  status: VoiceStatus;
  compact?: boolean;
  audioLevels?: number[];
  reducedMotion?: boolean;
}

const DEFAULT_BARS = [0.22, 0.28, 0.34, 0.28, 0.22, 0.26, 0.18];

export const AssistantOrb: React.FC<AssistantOrbProps> = ({
  status,
  compact = false,
  audioLevels,
  reducedMotion = false,
}) => {
  const isListening = status === 'listening' || status === 'requesting-permission';
  const isSpeaking = status === 'speaking';
  const isProcessing = status === 'processing';
  const isActive = isListening || isSpeaking || isProcessing;

  const sizeClass = compact ? 'w-11 h-11' : 'w-14 h-14';
  const bars = audioLevels && audioLevels.length > 0 ? audioLevels : DEFAULT_BARS;

  return (
    <div className="flex items-center gap-3 shrink-0">
      <div
        className={`relative ${sizeClass} rounded-full flex items-center justify-center border transition-transform duration-200 ${
          isListening
            ? 'border-teal-400 bg-teal-500/15 scale-105 animate-finx-orb'
            : isSpeaking
              ? 'border-cyan-400 bg-cyan-500/15 scale-105 animate-finx-orb'
              : isProcessing
                ? 'border-teal-500/70 bg-teal-500/10'
                : status === 'error'
                  ? 'border-red-400/70 bg-red-500/10'
                  : 'border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-[#172235]'
        }`}
      >
        {isSpeaking ? (
          <Volume2 className="w-5 h-5 text-cyan-600 dark:text-[#22D3EE]" />
        ) : (
          <Mic
            className={`w-5 h-5 ${
              isListening
                ? 'text-teal-600 dark:text-[#14B8A6]'
                : status === 'error'
                  ? 'text-red-500 dark:text-[#F87171]'
                  : 'text-slate-600 dark:text-[#94A3B8]'
            }`}
          />
        )}
      </div>

      {/* Live 7-Band Audio Spectrum Bars */}
      <div className="flex items-center gap-1 h-7" aria-hidden="true">
        {bars.map((level, idx) => {
          const heightPx = reducedMotion
            ? isActive
              ? 16
              : 7
            : isActive
              ? Math.round(7 + Math.min(1, Math.max(0.14, level)) * 20)
              : 7;

          return (
            <span
              key={idx}
              style={{
                height: `${heightPx}px`,
                animationDelay: `${idx * 90}ms`,
              }}
              className={`w-1 rounded-full transition-all duration-100 ${
                isActive
                  ? `${
                      isProcessing && !reducedMotion ? 'animate-finx-wave ' : ''
                    }${
                      isSpeaking
                        ? 'bg-cyan-500 dark:bg-[#22D3EE]'
                        : 'bg-teal-600 dark:bg-[#14B8A6]'
                    }`
                  : 'bg-slate-300 dark:bg-slate-700'
              }`}
            />
          );
        })}
      </div>
    </div>
  );
};
