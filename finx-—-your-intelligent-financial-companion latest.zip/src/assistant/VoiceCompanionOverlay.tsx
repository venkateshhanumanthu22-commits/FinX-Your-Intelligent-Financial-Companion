import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  AudioWaveform,
  BookOpen,
  ChevronDown,
  ChevronUp,
  HelpCircle,
  MessageSquare,
  Mic,
  MicOff,
  Minimize2,
  Pause,
  Play,
  RotateCcw,
  Send,
  Settings2,
  Sparkles,
  Square,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { SearchableLanguageSelector } from '../components/SearchableLanguageSelector';
import { useFinX } from '../context/FinXContext';
import { useVoiceAssistant } from '../hooks/useVoiceAssistant';
import { getAllSpeechVariants, getLanguageDef } from '../i18n/languages';
import { NEURAL_VOICE_PERSONAS } from '../services/aiAssistantService';
import { getVoicesForLocale, inspectSpeechLanguageSupport } from '../services/voiceService';
import { NeuralVoiceName } from '../types/finx';
import { AssistantOrb } from './AssistantOrb';

export const VoiceCompanionOverlay: React.FC = () => {
  const { t } = useTranslation(['assistant', 'common']);
  const {
    assistantOpen,
    assistantMinimized,
    assistantMode,
    setAssistantMode,
    openAssistant,
    minimizeAssistant,
    closeAssistant,
    assistantMessages,
    assistantBusy,
    assistantError,
    sendAssistantMessage,
    resetAssistantChat,
    isAuthenticated,
    languagePrefs,
    updateLanguagePrefs,
    settings,
    navigate,
    route,
  } = useFinX();

  const [inputText, setInputText] = useState('');
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);

  const chatEndRef = useRef<HTMLDivElement | null>(null);
  const speechVariants = useMemo(() => getAllSpeechVariants(), []);

  const voice = useVoiceAssistant({
    voiceInputLocale: languagePrefs.voiceInputLocale,
    voiceOutputLocale: languagePrefs.voiceOutputLocale,
    voiceOutputVoiceURI: languagePrefs.voiceOutputVoiceURI,
    autoSpeakResponses: languagePrefs.autoSpeakResponses,
    speechRate: settings.voiceSpeechRate,
    neuralVoiceName: languagePrefs.neuralVoiceName || 'Kore',
    preferNeuralVoice: languagePrefs.preferNeuralVoice !== false,
    handsFreeLoop: languagePrefs.handsFreeLoop !== false,
    onFinalTranscript: async (spokenText) => {
      const result = await sendAssistantMessage(spokenText);
      return result?.replyText || null;
    },
  });

  const speechSupport = useMemo(
    () =>
      inspectSpeechLanguageSupport(
        languagePrefs.voiceInputLocale,
        languagePrefs.voiceOutputLocale,
        languagePrefs.voiceOutputVoiceURI
      ),
    [
      languagePrefs.voiceInputLocale,
      languagePrefs.voiceOutputLocale,
      languagePrefs.voiceOutputVoiceURI,
      voice.availableVoices,
    ]
  );

  const availableVoicesForOutput = useMemo(
    () => getVoicesForLocale(languagePrefs.voiceOutputLocale),
    [languagePrefs.voiceOutputLocale, voice.availableVoices]
  );

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [assistantMessages, assistantBusy, voice.interimTranscript]);

  const handleSendText = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed || assistantBusy) return;
    setInputText('');
    const result = await sendAssistantMessage(trimmed);
    if (result?.replyText && languagePrefs.autoSpeakResponses && !voice.isMuted) {
      void voice.speakText(result.replyText);
    }
  };

  const handleSuggestionClick = async (prompt: string) => {
    if (assistantBusy) return;
    const result = await sendAssistantMessage(prompt);
    if (result?.replyText && languagePrefs.autoSpeakResponses && !voice.isMuted) {
      void voice.speakText(result.replyText);
    }
  };

  const handleMinimize = () => {
    voice.stopSpeaking();
    if (voice.sessionActive) {
      voice.endVoiceSession();
    }
    minimizeAssistant();
  };

  const handleClose = () => {
    voice.endVoiceSession();
    closeAssistant();
  };

  const suggestedQuestions = isAuthenticated
    ? (t('assistant:suggestedPostLogin', { returnObjects: true }) as string[])
    : (t('assistant:suggestedPreLogin', { returnObjects: true }) as string[]);

  const statusLabel = voice.isPaused
    ? t('assistant:status.paused')
    : voice.status === 'listening'
      ? t('assistant:status.listening')
      : voice.status === 'requesting-permission'
        ? t('assistant:status.requesting')
        : voice.status === 'processing' || assistantBusy
          ? t('assistant:status.processing')
          : voice.status === 'speaking'
            ? t('assistant:status.speaking')
            : voice.status === 'error'
              ? t('assistant:status.error')
              : t('assistant:status.idle');

  const activeTextLangDef = getLanguageDef(languagePrefs.textAssistantLanguage);

  // Floating button when closed or minimized
  if (!assistantOpen) {
    // On dedicated assistant page we don't need an extra floating button unless minimized from another route
    if (route === 'assistant' && !assistantMinimized) return null;

    return (
      <button
        type="button"
        onClick={() => openAssistant()}
        aria-label={t('common:actions.talkToFinX')}
        className={`fixed end-4 md:end-5 z-40 inline-flex items-center gap-2 px-4 py-3 rounded-full bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 font-display font-semibold text-sm shadow-lg hover:bg-teal-700 dark:hover:bg-[#22D3EE] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-teal-500 transition-transform active:scale-95 whitespace-nowrap ${
          isAuthenticated ? 'bottom-20 md:bottom-5' : 'bottom-5'
        }`}
      >
        <Mic className="w-4 h-4 shrink-0" />
        <span>{t('common:actions.talkToFinX')}</span>
        {assistantMinimized && assistantMessages.length > 1 && (
          <span className="text-xs font-mono-nums opacity-80">
            · {assistantMessages.length}
          </span>
        )}
      </button>
    );
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label={t('common:nav.assistant')}
    >
      <div className="w-full sm:max-w-3xl h-[92vh] sm:h-[85vh] flex flex-col rounded-t-2xl sm:rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] shadow-2xl overflow-hidden">
        {/* Top Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#172235]">
          <div className="flex items-center gap-3 min-w-0">
            <AssistantOrb
              status={assistantBusy && voice.status === 'idle' ? 'processing' : voice.status}
              compact
              audioLevels={voice.audioLevels}
              reducedMotion={settings.reducedMotion}
            />
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h2 className="font-display font-bold text-base truncate">
                  {t('common:nav.assistant')}
                </h2>
                <span className="text-xs text-slate-500 dark:text-[#94A3B8]">·</span>
                <span
                  className={`text-xs font-medium whitespace-nowrap ${
                    voice.status === 'listening'
                      ? 'text-teal-600 dark:text-[#14B8A6]'
                      : voice.status === 'speaking'
                        ? 'text-cyan-600 dark:text-[#22D3EE]'
                        : voice.status === 'error'
                          ? 'text-red-600 dark:text-[#F87171]'
                          : 'text-slate-600 dark:text-[#94A3B8]'
                  }`}
                >
                  {voice.isHdRecording ? t('assistant:status.hdRecording') : statusLabel}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-[#94A3B8] truncate">
                {activeTextLangDef.nativeName} · {languagePrefs.voiceInputLocale} ·{' '}
                {languagePrefs.preferNeuralVoice !== false
                  ? `${languagePrefs.neuralVoiceName || 'Kore'}`
                  : t('assistant:controls.fallbackBrowserVoice')}
              </p>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => setShowVoiceSettings((s) => !s)}
              title={t('common:language.selectorTitle')}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                showVoiceSettings
                  ? 'border-teal-500 bg-teal-500/10 text-teal-700 dark:text-[#14B8A6]'
                  : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{activeTextLangDef.code.toUpperCase()}</span>
            </button>

            <button
              type="button"
              onClick={resetAssistantChat}
              title={t('assistant:controls.resetChat')}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
              aria-label={t('assistant:controls.resetChat')}
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleMinimize}
              title={t('assistant:controls.minimize')}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors"
              aria-label={t('assistant:controls.minimize')}
            >
              <Minimize2 className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleClose}
              title={t('assistant:controls.close')}
              className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-[#94A3B8] hover:text-red-600 dark:hover:text-[#F87171] transition-colors"
              aria-label={t('assistant:controls.close')}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mode Switch & Privacy Boundary Notice */}
        <div className="px-4 sm:px-5 py-2.5 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101827] flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex items-center p-1 rounded-lg bg-slate-100 dark:bg-[#172235]">
            <button
              type="button"
              onClick={() => setAssistantMode('finance-assistant')}
              className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                assistantMode === 'finance-assistant'
                  ? 'bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC] shadow-xs'
                  : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>{t('assistant:modeFinance')}</span>
            </button>
            <button
              type="button"
              onClick={() => setAssistantMode('finx-guide')}
              className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                assistantMode === 'finx-guide'
                  ? 'bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC] shadow-xs'
                  : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>{t('assistant:modeGuide')}</span>
            </button>
          </div>

          <p className="text-xs text-slate-500 dark:text-[#94A3B8] leading-snug">
            {isAuthenticated ? t('assistant:postLoginNotice') : t('assistant:preLoginNotice')}
          </p>
        </div>

        {/* Expandable Language & Voice Settings Drawer */}
        {showVoiceSettings && (
          <div className="px-4 sm:px-5 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#172235] space-y-4 overflow-y-auto max-h-72">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <SearchableLanguageSelector
                  label={t('common:language.textAssistantLanguage')}
                  value={languagePrefs.textAssistantLanguage}
                  align="left"
                  onChange={(code) =>
                    updateLanguagePrefs({
                      textAssistantLanguage: code,
                      useSameLanguageEverywhere: false,
                    })
                  }
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  {t('common:language.voiceInputLanguage')}
                </label>
                <select
                  value={languagePrefs.voiceInputLocale}
                  onChange={(e) =>
                    updateLanguagePrefs({
                      voiceInputLocale: e.target.value,
                      useSameLanguageEverywhere: false,
                    })
                  }
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC]"
                >
                  {speechVariants.map((v) => (
                    <option key={v.locale} value={v.locale}>
                      {v.nativeName} · {v.label} ({v.locale})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  {t('common:language.voiceOutputLanguage')}
                </label>
                <select
                  value={languagePrefs.voiceOutputLocale}
                  onChange={(e) =>
                    updateLanguagePrefs({
                      voiceOutputLocale: e.target.value,
                      voiceOutputVoiceURI: 'auto',
                      useSameLanguageEverywhere: false,
                    })
                  }
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC]"
                >
                  {speechVariants.map((v) => (
                    <option key={v.locale} value={v.locale}>
                      {v.nativeName} · {v.label} ({v.locale})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  {t('assistant:controls.neuralVoiceLabel')}
                </label>
                <select
                  value={languagePrefs.neuralVoiceName || 'Kore'}
                  onChange={(e) =>
                    updateLanguagePrefs({ neuralVoiceName: e.target.value as NeuralVoiceName })
                  }
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC]"
                >
                  {NEURAL_VOICE_PERSONAS.map((persona) => (
                    <option key={persona.id} value={persona.id}>
                      {persona.label} ({persona.tone})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  {t('assistant:controls.fallbackBrowserVoice')}
                </label>
                <select
                  value={languagePrefs.voiceOutputVoiceURI}
                  onChange={(e) => updateLanguagePrefs({ voiceOutputVoiceURI: e.target.value })}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC]"
                >
                  <option value="auto">
                    {t('assistant:controls.automaticMatching', { count: availableVoicesForOutput.length })}
                  </option>
                  {availableVoicesForOutput.map((v) => (
                    <option key={v.voiceURI} value={v.voiceURI}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
              <div className="flex flex-wrap items-center gap-4">
                <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-[#F8FAFC] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={languagePrefs.autoSpeakResponses}
                    onChange={(e) => updateLanguagePrefs({ autoSpeakResponses: e.target.checked })}
                    className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                  />
                  <span>{t('assistant:controls.autoSpeak')}</span>
                </label>

                <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-[#F8FAFC] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={languagePrefs.preferNeuralVoice !== false}
                    onChange={(e) => updateLanguagePrefs({ preferNeuralVoice: e.target.checked })}
                    className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                  />
                  <span>{t('assistant:controls.neuralHdSpeech')}</span>
                </label>

                <label className="inline-flex items-center gap-2 text-xs text-slate-700 dark:text-[#F8FAFC] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={languagePrefs.handsFreeLoop !== false}
                    onChange={(e) => updateLanguagePrefs({ handsFreeLoop: e.target.checked })}
                    className="rounded border-slate-300 text-teal-600 focus:ring-teal-500"
                  />
                  <span>{t('assistant:controls.handsFreeLoop')}</span>
                </label>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={voice.testMicrophone}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] hover:border-teal-500 whitespace-nowrap"
                >
                  {t('assistant:controls.testMic')}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    voice.previewSelectedVoice(
                      t('assistant:greeting', { lng: getLanguageDef(languagePrefs.voiceOutputLocale).code })
                    )
                  }
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] hover:border-teal-500 whitespace-nowrap"
                >
                  {t('assistant:controls.previewVoice')}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    voice.refreshDiagnostics();
                    setShowDiagnostics((d) => !d);
                  }}
                  className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] hover:border-teal-500 whitespace-nowrap"
                >
                  <span>{t('assistant:controls.diagnostics')}</span>
                  {showDiagnostics ? (
                    <ChevronUp className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>

            <div className="text-xs text-slate-500 dark:text-[#94A3B8] space-y-1">
              <p>{t('common:settings.sttLabel')}: {speechSupport.sttNote}</p>
              <p>{t('common:settings.ttsLabel')}: {speechSupport.ttsNote}</p>
              {voice.micTestResult && (
                <p className="text-teal-600 dark:text-[#14B8A6] font-medium">
                  {voice.micTestResult}
                </p>
              )}
            </div>

            {showDiagnostics && voice.diagnostics && (
              <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#101827] text-xs font-mono-nums space-y-1">
                <div>Origin: {voice.diagnostics.origin}</div>
                <div>Secure Context: {String(voice.diagnostics.isSecureContext)}</div>
                <div>mediaDevices API: {String(voice.diagnostics.mediaDevicesAvailable)}</div>
                <div>SpeechRecognition API: {String(voice.diagnostics.speechRecognitionAvailable)}</div>
                <div>Permission State: {voice.diagnostics.permissionState}</div>
                <div>
                  {languagePrefs.voiceInputLocale} / {languagePrefs.voiceOutputLocale}
                </div>
                <div>Voices: {voice.diagnostics.availableVoicesCount}</div>
                {voice.diagnostics.lastErrorName && (
                  <div className="text-red-600 dark:text-[#F87171]">
                    {voice.diagnostics.lastErrorName} — {voice.diagnostics.lastErrorMessage}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Conversation Area */}
        <div className="flex-1 overflow-y-auto px-4 sm:px-5 py-4 space-y-4">
          {assistantMessages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                  msg.role === 'user'
                    ? 'bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 font-medium'
                    : msg.isError
                      ? 'border border-red-300 dark:border-red-800/70 bg-red-50 dark:bg-red-950/30 text-red-800 dark:text-red-200'
                      : 'border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#1E293B] text-slate-800 dark:text-[#F8FAFC]'
                }`}
              >
                {msg.content}
                {msg.role === 'assistant' && !msg.isError && (
                  <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                      {msg.detectedLanguage && (
                        <span>
                          {t('assistant:controls.detectedLanguage')}: {msg.detectedLanguage}
                        </span>
                      )}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        if (voice.speakingMessageId === msg.id && voice.status === 'speaking') {
                          voice.stopSpeaking();
                        } else {
                          void voice.speakText(msg.content, undefined, {
                            forceSpeak: true,
                            messageId: msg.id,
                          });
                        }
                      }}
                      className="inline-flex items-center gap-1 rounded-md border border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/60 px-2 py-1 text-[11px] font-medium text-slate-700 dark:text-slate-200 hover:border-teal-500 hover:text-teal-600 dark:hover:text-[#22D3EE] transition-colors"
                    >
                      {voice.speakingMessageId === msg.id && voice.status === 'speaking' ? (
                        <>
                          <Square className="w-3 h-3 text-cyan-500" />
                          <span>{t('assistant:controls.stopAudio')}</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3 h-3 text-teal-500" />
                          <span>{t('assistant:controls.readAloud')}</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-slate-200/70 dark:border-slate-700/70 space-y-1">
                    <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                      {t('assistant:controls.groundedSources')}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {msg.sources.map((src) => (
                        <a
                          key={src.uri}
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900/60 px-2 py-1 text-[11px] text-teal-600 dark:text-[#22D3EE] hover:underline"
                        >
                          <span className="truncate max-w-[180px]">{src.title}</span>
                          <span aria-hidden="true">↗</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
                {msg.suggestedRoute && isAuthenticated && (
                  <div className="mt-2.5 pt-2 border-t border-slate-200/70 dark:border-slate-700/70">
                    <button
                      type="button"
                      onClick={() => {
                        navigate(msg.suggestedRoute!);
                        minimizeAssistant();
                      }}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-600 dark:text-[#22D3EE] hover:underline"
                    >
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>{t('assistant:controls.openRoute', { route: msg.suggestedRoute })}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))}

          {voice.interimTranscript && (
            <div className="flex justify-end">
              <div className="max-w-[85%] rounded-2xl px-4 py-2.5 text-xs italic border border-teal-500/40 bg-teal-500/5 text-teal-700 dark:text-[#22D3EE]">
                {voice.interimTranscript}...
              </div>
            </div>
          )}

          {assistantBusy && (
            <div className="flex justify-start">
              <div className="rounded-2xl px-4 py-3 text-xs border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#1E293B] text-slate-500 dark:text-[#94A3B8]">
                {t('assistant:status.processing')}
              </div>
            </div>
          )}

          {(voice.errorMessage || assistantError) && (
            <div className="flex items-start gap-2.5 p-3 rounded-xl border border-amber-300 dark:border-amber-800/70 bg-amber-50 dark:bg-amber-950/30 text-xs text-amber-900 dark:text-amber-200">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <div className="space-y-1">
                {voice.errorMessage && <p>{voice.errorMessage}</p>}
                {assistantError && !voice.errorMessage && <p>{assistantError}</p>}
              </div>
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        {/* Suggested Prompts */}
        {Array.isArray(suggestedQuestions) && suggestedQuestions.length > 0 && (
          <div className="px-4 sm:px-5 py-2 border-t border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#172235]/60 flex items-center gap-2 overflow-x-auto">
            {suggestedQuestions.map((q) => (
              <button
                key={q}
                type="button"
                onClick={() => handleSuggestionClick(q)}
                disabled={assistantBusy}
                className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] text-slate-700 dark:text-[#F8FAFC] hover:border-teal-500 whitespace-nowrap shrink-0 transition-colors disabled:opacity-50"
              >
                {q}
              </button>
            ))}
          </div>
        )}

        {/* Voice Controls + Text Input Footer */}
        <div className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#172235] space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              {!voice.sessionActive && !voice.isHdRecording ? (
                <button
                  type="button"
                  onClick={voice.startVoiceSession}
                  className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 hover:bg-teal-700 dark:hover:bg-[#22D3EE] transition-colors whitespace-nowrap"
                >
                  <Mic className="w-4 h-4" />
                  <span>{t('assistant:controls.startVoice')}</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={voice.isHdRecording ? voice.stopHdRecording : voice.endVoiceSession}
                  className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg bg-red-600 text-white hover:bg-red-700 transition-colors whitespace-nowrap"
                >
                  <MicOff className="w-4 h-4" />
                  <span>
                    {voice.isHdRecording
                      ? t('assistant:controls.sendHdAudio')
                      : t('assistant:controls.stopListening')}
                  </span>
                </button>
              )}

              {!voice.sessionActive && (
                <button
                  type="button"
                  onClick={voice.isHdRecording ? voice.stopHdRecording : voice.startHdRecording}
                  title={t('assistant:controls.hdVoiceCapture')}
                  className={`inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border transition-colors whitespace-nowrap ${
                    voice.isHdRecording
                      ? 'border-rose-500 bg-rose-500/15 text-rose-600 dark:text-rose-300'
                      : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-[#F8FAFC] hover:border-teal-500'
                  }`}
                >
                  <AudioWaveform className="w-3.5 h-3.5 text-teal-500" />
                  <span>
                    {voice.isHdRecording
                      ? t('assistant:controls.stopTranscribe')
                      : t('assistant:controls.hdVoiceCapture')}
                  </span>
                </button>
              )}

              {voice.status === 'speaking' && (
                <>
                  <button
                    type="button"
                    onClick={voice.isPaused ? voice.resumeSpeaking : voice.pauseSpeaking}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-teal-500/40 bg-teal-500/10 text-teal-700 dark:text-[#14B8A6] whitespace-nowrap"
                  >
                    {voice.isPaused ? <Play className="w-3.5 h-3.5" /> : <Pause className="w-3.5 h-3.5" />}
                    <span>
                      {voice.isPaused
                        ? t('assistant:controls.resumeSpeaking')
                        : t('assistant:controls.pauseSpeaking')}
                    </span>
                  </button>
                  <button
                    type="button"
                    onClick={voice.stopSpeaking}
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-cyan-500/50 bg-cyan-500/10 text-cyan-700 dark:text-[#22D3EE] whitespace-nowrap"
                  >
                    <Square className="w-3.5 h-3.5" />
                    <span>
                      {t('assistant:controls.stopSpeaking')}
                      {voice.activeTtsEngine === 'neural' ? ' (HD)' : ''}
                    </span>
                  </button>
                </>
              )}

              <button
                type="button"
                onClick={() => voice.setIsMuted(!voice.isMuted)}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-[#F8FAFC] hover:bg-slate-100 dark:hover:bg-[#1E293B] whitespace-nowrap"
              >
                {voice.isMuted ? (
                  <>
                    <VolumeX className="w-3.5 h-3.5 text-amber-500" />
                    <span>{t('assistant:controls.unmute')}</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5 text-teal-600 dark:text-[#14B8A6]" />
                    <span>{t('assistant:controls.mute')}</span>
                  </>
                )}
              </button>

              <span className="hidden md:inline-flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                <Sparkles className="w-3 h-3 text-teal-500" />
                <span>{languagePrefs.neuralVoiceName || 'Kore'}</span>
              </span>
            </div>

            {!isAuthenticated && (
              <button
                type="button"
                onClick={() => {
                  closeAssistant();
                  navigate('login');
                }}
                className="text-xs font-semibold text-teal-600 dark:text-[#14B8A6] hover:underline whitespace-nowrap"
              >
                {t('common:actions.login')}
              </button>
            )}
          </div>

          <form onSubmit={handleSendText} className="flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={t('assistant:controls.inputPlaceholder')}
              className="flex-1 min-w-0 px-3.5 sm:px-4 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || assistantBusy}
              className="inline-flex items-center gap-1.5 px-3.5 sm:px-4 py-2.5 text-sm font-semibold rounded-xl bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 hover:bg-teal-700 dark:hover:bg-[#22D3EE] disabled:opacity-40 transition-colors whitespace-nowrap shrink-0"
            >
              <Send className="w-4 h-4" />
              <span>{t('assistant:controls.send')}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
