import { useCallback, useEffect, useRef, useState } from 'react';
import i18n from '../i18n';
import { aiAssistantService } from '../services/aiAssistantService';
import {
  formatMicrophoneErrorGuidance,
  getSpeechRecognitionConstructor,
  inspectSpeechLanguageSupport,
  inspectVoiceDiagnostics,
  SpeechRecognitionErrorEventLike,
  SpeechRecognitionEventLike,
  SpeechRecognitionInstance,
} from '../services/voiceService';
import { NeuralVoiceName, VoiceDiagnosticInfo, VoiceStatus } from '../types/finx';

interface UseVoiceAssistantOptions {
  voiceInputLocale: string;
  voiceOutputLocale: string;
  voiceOutputVoiceURI: string;
  autoSpeakResponses: boolean;
  speechRate: number;
  neuralVoiceName?: NeuralVoiceName;
  preferNeuralVoice?: boolean;
  handsFreeLoop?: boolean;
  onFinalTranscript: (transcript: string) => Promise<string | null>;
}

const IDLE_LEVELS = [0.18, 0.24, 0.3, 0.24, 0.18, 0.22, 0.16];

function base64ToWavBlob(base64: string, mimeType = 'audio/wav'): Blob {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new Blob([bytes], { type: mimeType });
}

function blobToBase64(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = typeof reader.result === 'string' ? reader.result : '';
      const commaIdx = result.indexOf(',');
      resolve(commaIdx >= 0 ? result.slice(commaIdx + 1) : result);
    };
    reader.onerror = () => reject(new Error('Failed to encode recorded audio.'));
    reader.readAsDataURL(blob);
  });
}

export function useVoiceAssistant(options: UseVoiceAssistantOptions) {
  const [status, setStatus] = useState<VoiceStatus>('idle');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [sessionActive, setSessionActive] = useState(false);
  const [diagnostics, setDiagnostics] = useState<VoiceDiagnosticInfo | null>(null);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [micTestResult, setMicTestResult] = useState<string | null>(null);
  const [audioLevels, setAudioLevels] = useState<number[]>(IDLE_LEVELS);
  const [isHdRecording, setIsHdRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [activeTtsEngine, setActiveTtsEngine] = useState<'neural' | 'browser' | null>(null);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);
  const activeStreamRef = useRef<MediaStream | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRafRef = useRef<number | null>(null);
  const neuralAudioRef = useRef<HTMLAudioElement | null>(null);
  const neuralObjectUrlRef = useRef<string | null>(null);
  const ttsAbortRef = useRef<AbortController | null>(null);
  const transcribeAbortRef = useRef<AbortController | null>(null);
  const speakingPulseTimerRef = useRef<number | null>(null);

  const sessionActiveRef = useRef(false);
  const isSpeakingRef = useRef(false);
  const isMutedRef = useRef(false);
  const isStartingRef = useRef(false);
  const noSpeechRetriesRef = useRef(0);
  const micGrantedInSessionRef = useRef(false);
  const lastSpokenHashRef = useRef<string>('');
  const playbackGenRef = useRef(0);
  const prevInputLocaleRef = useRef(options.voiceInputLocale);
  const lastErrorRef = useRef<{ name: string | null; message: string | null }>({
    name: null,
    message: null,
  });

  const optionsRef = useRef(options);
  optionsRef.current = options;

  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  const stopAudioMeter = useCallback(() => {
    if (analyserRafRef.current !== null) {
      cancelAnimationFrame(analyserRafRef.current);
      analyserRafRef.current = null;
    }
    if (speakingPulseTimerRef.current !== null) {
      window.clearInterval(speakingPulseTimerRef.current);
      speakingPulseTimerRef.current = null;
    }
    if (audioCtxRef.current) {
      audioCtxRef.current.close().catch(() => {});
      audioCtxRef.current = null;
    }
    setAudioLevels(IDLE_LEVELS);
  }, []);

  const startSpeakingMeter = useCallback(() => {
    if (speakingPulseTimerRef.current !== null) {
      window.clearInterval(speakingPulseTimerRef.current);
    }
    let phase = 0;
    speakingPulseTimerRef.current = window.setInterval(() => {
      phase += 0.45;
      setAudioLevels(
        IDLE_LEVELS.map((_, idx) => {
          const wave = 0.48 + 0.44 * Math.abs(Math.sin(phase + idx * 0.72));
          return Math.min(1, Math.max(0.18, wave));
        })
      );
    }, 95);
  }, []);

  const startMicMeter = useCallback(
    (stream: MediaStream) => {
      stopAudioMeter();
      try {
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
        if (!AudioCtx) return;

        const ctx = new AudioCtx();
        audioCtxRef.current = ctx;
        const source = ctx.createMediaStreamSource(stream);
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 64;
        analyser.smoothingTimeConstant = 0.72;
        source.connect(analyser);

        const data = new Uint8Array(analyser.frequencyBinCount);
        const tick = () => {
          if (!audioCtxRef.current) return;
          analyser.getByteFrequencyData(data);
          const next = [0, 1, 2, 3, 4, 5, 6].map((idx) => {
            const sample = data[Math.min(data.length - 1, idx * 2 + 1)] || 0;
            return Math.min(1, Math.max(0.16, sample / 170));
          });
          setAudioLevels(next);
          analyserRafRef.current = requestAnimationFrame(tick);
        };
        analyserRafRef.current = requestAnimationFrame(tick);
      } catch {
        // Ignore AudioContext restriction in restricted environments
      }
    },
    [stopAudioMeter]
  );

  const refreshDiagnostics = useCallback(async () => {
    const info = await inspectVoiceDiagnostics(
      lastErrorRef.current,
      optionsRef.current.voiceInputLocale,
      optionsRef.current.voiceOutputLocale
    );
    setDiagnostics(info);
    return info;
  }, []);

  useEffect(() => {
    const loadVoices = () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        setAvailableVoices(window.speechSynthesis.getVoices());
      }
      refreshDiagnostics();
    };
    loadVoices();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = loadVoices;
    }
    return () => {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.onvoiceschanged = null;
      }
    };
  }, [refreshDiagnostics]);

  const releaseMicTracks = useCallback(() => {
    stopAudioMeter();
    if (activeStreamRef.current) {
      activeStreamRef.current.getTracks().forEach((track) => track.stop());
      activeStreamRef.current = null;
    }
  }, [stopAudioMeter]);

  const stopRecognitionInstance = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onstart = null;
        recognitionRef.current.onresult = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.onend = null;
        recognitionRef.current.abort();
      } catch {
        // ignore abort errors
      }
      recognitionRef.current = null;
    }
    isStartingRef.current = false;
  }, []);

  const stopNeuralAudio = useCallback(() => {
    if (ttsAbortRef.current) {
      ttsAbortRef.current.abort();
      ttsAbortRef.current = null;
    }
    if (neuralAudioRef.current) {
      try {
        neuralAudioRef.current.pause();
        neuralAudioRef.current.onended = null;
        neuralAudioRef.current.onerror = null;
        neuralAudioRef.current.src = '';
      } catch {
        // ignore audio teardown issues
      }
      neuralAudioRef.current = null;
    }
    if (neuralObjectUrlRef.current) {
      URL.revokeObjectURL(neuralObjectUrlRef.current);
      neuralObjectUrlRef.current = null;
    }
  }, []);

  const stopSpeaking = useCallback(() => {
    playbackGenRef.current += 1;
    stopNeuralAudio();
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    stopAudioMeter();
    isSpeakingRef.current = false;
    setIsPaused(false);
    setActiveTtsEngine(null);
    setSpeakingMessageId(null);
    setStatus((prev) => (prev === 'speaking' ? 'idle' : prev));
  }, [stopAudioMeter, stopNeuralAudio]);

  const pauseSpeaking = useCallback(() => {
    if (!isSpeakingRef.current) return;
    if (neuralAudioRef.current && !neuralAudioRef.current.paused) {
      neuralAudioRef.current.pause();
      setIsPaused(true);
      stopAudioMeter();
      return;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.speaking) {
      window.speechSynthesis.pause();
      setIsPaused(true);
      stopAudioMeter();
    }
  }, [stopAudioMeter]);

  const resumeSpeaking = useCallback(() => {
    if (!isSpeakingRef.current) return;
    if (neuralAudioRef.current && neuralAudioRef.current.paused) {
      neuralAudioRef.current.play().catch(() => {});
      setIsPaused(false);
      startSpeakingMeter();
      return;
    }
    if (typeof window !== 'undefined' && 'speechSynthesis' in window && window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
      setIsPaused(false);
      startSpeakingMeter();
    }
  }, [startSpeakingMeter]);

  const speakWithBrowserFallback = useCallback(
    (cleanText: string, onDone?: () => void) => {
      if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
        isSpeakingRef.current = false;
        setIsPaused(false);
        setActiveTtsEngine(null);
        setSpeakingMessageId(null);
        setStatus('idle');
        onDone?.();
        return;
      }

      const support = inspectSpeechLanguageSupport(
        optionsRef.current.voiceInputLocale,
        optionsRef.current.voiceOutputLocale,
        optionsRef.current.voiceOutputVoiceURI
      );

      if (!support.ttsSupported) {
        isSpeakingRef.current = false;
        setIsPaused(false);
        setActiveTtsEngine(null);
        setSpeakingMessageId(null);
        setStatus('idle');
        onDone?.();
        return;
      }

      const myGen = playbackGenRef.current;
      window.speechSynthesis.cancel();
      const rawChunks = cleanText.match(/[^.!?।\n]+[.!?।\n]*/g) || [cleanText];
      const chunks = rawChunks.map((c) => c.trim()).filter(Boolean);
      if (chunks.length === 0) {
        onDone?.();
        return;
      }

      isSpeakingRef.current = true;
      setIsPaused(false);
      setActiveTtsEngine('browser');
      setStatus('speaking');
      startSpeakingMeter();

      let idx = 0;
      const speakNextChunk = () => {
        if (playbackGenRef.current !== myGen || !isSpeakingRef.current) {
          return;
        }
        if (idx >= chunks.length) {
          isSpeakingRef.current = false;
          setIsPaused(false);
          setActiveTtsEngine(null);
          setSpeakingMessageId(null);
          stopAudioMeter();
          setStatus('idle');
          onDone?.();
          return;
        }

        const utterance = new SpeechSynthesisUtterance(chunks[idx]);
        utterance.lang = optionsRef.current.voiceOutputLocale;
        utterance.rate = Math.min(1.5, Math.max(0.7, optionsRef.current.speechRate || 1.0));
        if (support.chosenVoice) {
          utterance.voice = support.chosenVoice;
        }

        utterance.onend = () => {
          idx += 1;
          speakNextChunk();
        };

        utterance.onerror = (ev) => {
          isSpeakingRef.current = false;
          setIsPaused(false);
          setActiveTtsEngine(null);
          setSpeakingMessageId(null);
          stopAudioMeter();
          if (ev.error !== 'interrupted' && ev.error !== 'canceled') {
            lastErrorRef.current = { name: ev.error, message: 'Speech synthesis error' };
            refreshDiagnostics();
          }
          setStatus('idle');
          onDone?.();
        };

        window.speechSynthesis.speak(utterance);
      };

      speakNextChunk();
    },
    [refreshDiagnostics, startSpeakingMeter, stopAudioMeter]
  );

  const speakText = useCallback(
    async (
      text: string,
      onDone?: () => void,
      speakOptions?: { forceSpeak?: boolean; messageId?: string }
    ) => {
      const forceSpeak = Boolean(speakOptions?.forceSpeak);
      if (isMutedRef.current || (!forceSpeak && !optionsRef.current.autoSpeakResponses)) {
        onDone?.();
        return;
      }

      const cleanText = text
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/[*_`#>]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      if (!cleanText) {
        onDone?.();
        return;
      }

      const dedupKey = `${optionsRef.current.voiceOutputLocale}:${optionsRef.current.neuralVoiceName || 'Kore'}:${cleanText}`;
      if (!forceSpeak && isSpeakingRef.current && lastSpokenHashRef.current === dedupKey) {
        return;
      }
      lastSpokenHashRef.current = dedupKey;

      // Pause active speech recognition and cancel prior playback for clean barge-in
      playbackGenRef.current += 1;
      setIsPaused(false);
      stopRecognitionInstance();
      stopNeuralAudio();
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }

      const useNeural = optionsRef.current.preferNeuralVoice !== false;
      setSpeakingMessageId(speakOptions?.messageId || null);

      if (useNeural) {
        const controller = new AbortController();
        ttsAbortRef.current = controller;
        isSpeakingRef.current = true;
        setActiveTtsEngine('neural');
        setStatus('speaking');

        try {
          const payload = await aiAssistantService.synthesizeSpeech({
            text: cleanText,
            voiceName: optionsRef.current.neuralVoiceName || 'Kore',
            languageLabel: optionsRef.current.voiceOutputLocale,
            signal: controller.signal,
          });

          if (controller.signal.aborted) {
            return;
          }

          const wavBlob = base64ToWavBlob(payload.audioBase64, payload.mimeType || 'audio/wav');
          const url = URL.createObjectURL(wavBlob);
          neuralObjectUrlRef.current = url;

          const audio = new Audio(url);
          audio.playbackRate = Math.min(1.5, Math.max(0.7, optionsRef.current.speechRate || 1.0));
          neuralAudioRef.current = audio;
          startSpeakingMeter();

          audio.onended = () => {
            stopNeuralAudio();
            stopAudioMeter();
            isSpeakingRef.current = false;
            setActiveTtsEngine(null);
            setSpeakingMessageId(null);
            setStatus('idle');
            onDone?.();
          };

          audio.onerror = () => {
            stopNeuralAudio();
            stopAudioMeter();
            speakWithBrowserFallback(cleanText, onDone);
          };

          await audio.play();
          return;
        } catch (err) {
          if (controller.signal.aborted) {
            isSpeakingRef.current = false;
            setActiveTtsEngine(null);
            setSpeakingMessageId(null);
            stopAudioMeter();
            return;
          }
          // Graceful fallback to browser speechSynthesis when neural endpoint throttles or autoplay blocks
          console.warn('[FinX Neural TTS fallback]', (err as Error)?.message || err);
        }
      }

      speakWithBrowserFallback(cleanText, onDone);
    },
    [speakWithBrowserFallback, startSpeakingMeter, stopAudioMeter, stopNeuralAudio, stopRecognitionInstance]
  );

  const previewSelectedVoice = useCallback(
    (sampleText: string) => {
      void speakText(sampleText, undefined, { forceSpeak: true });
    },
    [speakText]
  );

  const ensureMicrophoneAccessOnce = useCallback(
    async (keepStream = false): Promise<MediaStream | boolean> => {
      if (typeof window !== 'undefined' && !window.isSecureContext) {
        const msg = i18n.t('assistant:diagnosticsLabels.micInsecure');
        lastErrorRef.current = { name: 'InsecureContext', message: msg };
        setErrorMessage(msg);
        setStatus('error');
        refreshDiagnostics();
        return false;
      }

      if (!keepStream) {
        let permState: 'granted' | 'denied' | 'prompt' | 'unsupported' = 'unsupported';
        if (typeof navigator !== 'undefined' && navigator.permissions?.query) {
          try {
            const res = await navigator.permissions.query({
              name: 'microphone' as PermissionName,
            });
            permState = res.state;
          } catch {
            permState = 'unsupported';
          }
        }

        if (permState === 'granted' || (permState === 'unsupported' && micGrantedInSessionRef.current)) {
          micGrantedInSessionRef.current = true;
          return true;
        }

        if (permState === 'denied') {
          micGrantedInSessionRef.current = false;
          const msg = formatMicrophoneErrorGuidance('NotAllowedError');
          lastErrorRef.current = { name: 'NotAllowedError', message: 'Permission state is denied' };
          setErrorMessage(msg);
          setStatus('error');
          refreshDiagnostics();
          return false;
        }
      }

      if (!navigator.mediaDevices || typeof navigator.mediaDevices.getUserMedia !== 'function') {
        const msg = 'Browser mediaDevices API is unavailable. Use text input below.';
        lastErrorRef.current = { name: 'UnsupportedMediaDevices', message: msg };
        setErrorMessage(msg);
        setStatus('error');
        refreshDiagnostics();
        return false;
      }

      try {
        setStatus('requesting-permission');
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        micGrantedInSessionRef.current = true;
        if (keepStream) {
          activeStreamRef.current = stream;
          return stream;
        }
        stream.getTracks().forEach((track) => track.stop());
        return true;
      } catch (err: unknown) {
        releaseMicTracks();
        const e = err as Error;
        lastErrorRef.current = { name: e.name || 'PermissionError', message: e.message };
        setErrorMessage(formatMicrophoneErrorGuidance(e.name || 'NotAllowedError', e.message));
        setStatus('error');
        refreshDiagnostics();
        return false;
      }
    },
    [refreshDiagnostics, releaseMicTracks]
  );

  const handleResolvedTranscript = useCallback(
    async (transcriptText: string, resumeFn?: () => void) => {
      const cleaned = transcriptText.trim();
      if (!cleaned) {
        setStatus('idle');
        return;
      }
      setStatus('processing');
      const reply = await optionsRef.current.onFinalTranscript(cleaned);
      if (!reply) {
        if (sessionActiveRef.current) {
          sessionActiveRef.current = false;
          setSessionActive(false);
        }
        setStatus('idle');
        return;
      }

      const shouldLoop = optionsRef.current.handsFreeLoop !== false && sessionActiveRef.current;
      if (!isMutedRef.current && optionsRef.current.autoSpeakResponses) {
        await speakText(reply, () => {
          if (shouldLoop && !isSpeakingRef.current && resumeFn) {
            setTimeout(() => {
              if (sessionActiveRef.current && !isSpeakingRef.current) {
                resumeFn();
              }
            }, 350);
          }
        });
      } else if (shouldLoop && resumeFn) {
        setTimeout(() => {
          if (sessionActiveRef.current && !isSpeakingRef.current) {
            resumeFn();
          }
        }, 300);
      } else {
        setStatus('idle');
      }
    },
    [speakText]
  );

  // HD Record & Transcribe mode via MediaRecorder + gemini-3.5-transcribe
  const stopHdRecording = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.stop();
      } catch {
        setIsHdRecording(false);
        releaseMicTracks();
      }
    } else {
      setIsHdRecording(false);
      releaseMicTracks();
    }
  }, [releaseMicTracks]);

  const startHdRecording = useCallback(async () => {
    setErrorMessage(null);
    stopSpeaking();
    stopRecognitionInstance();

    if (typeof MediaRecorder === 'undefined') {
      const msg = 'Audio recording is unavailable in this browser. Please type your message below.';
      setErrorMessage(msg);
      setStatus('error');
      return;
    }

    const streamOrBool = await ensureMicrophoneAccessOnce(true);
    if (!streamOrBool || typeof streamOrBool === 'boolean') {
      return;
    }

    const stream = streamOrBool;
    startMicMeter(stream);

    const preferredMime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'].find((m) =>
      MediaRecorder.isTypeSupported(m)
    );

    try {
      recordedChunksRef.current = [];
      const recorder = preferredMime
        ? new MediaRecorder(stream, { mimeType: preferredMime })
        : new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;

      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) {
          recordedChunksRef.current.push(ev.data);
        }
      };

      recorder.onstop = async () => {
        setIsHdRecording(false);
        mediaRecorderRef.current = null;
        releaseMicTracks();

        const blob = new Blob(recordedChunksRef.current, {
          type: preferredMime || 'audio/webm',
        });
        recordedChunksRef.current = [];

        if (blob.size < 400) {
          setStatus('idle');
          return;
        }

        setStatus('processing');
        setInterimTranscript(i18n.t('assistant:diagnosticsLabels.transcribingHd'));
        const controller = new AbortController();
        transcribeAbortRef.current = controller;

        try {
          const base64 = await blobToBase64(blob);
          const result = await aiAssistantService.transcribeAudio({
            audioBase64: base64,
            mimeType: blob.type || 'audio/webm',
            languageHint: optionsRef.current.voiceInputLocale,
            signal: controller.signal,
          });
          setInterimTranscript('');

          if (result.transcript && result.transcript.trim()) {
            await handleResolvedTranscript(result.transcript.trim());
          } else {
            setErrorMessage(i18n.t('assistant:diagnosticsLabels.noClearSpeech'));
            setStatus('idle');
          }
        } catch (err) {
          setInterimTranscript('');
          if (!controller.signal.aborted) {
            setErrorMessage((err as Error)?.message || 'HD transcription failed.');
            setStatus('error');
          }
        } finally {
          transcribeAbortRef.current = null;
        }
      };

      recorder.start(250);
      setIsHdRecording(true);
      setStatus('listening');
    } catch (err) {
      releaseMicTracks();
      setIsHdRecording(false);
      setErrorMessage((err as Error)?.message || 'Failed to start HD audio capture.');
      setStatus('error');
    }
  }, [
    ensureMicrophoneAccessOnce,
    handleResolvedTranscript,
    releaseMicTracks,
    startMicMeter,
    stopRecognitionInstance,
    stopSpeaking,
  ]);

  const startRecognitionCycle = useCallback(() => {
    if (isStartingRef.current || recognitionRef.current || isSpeakingRef.current) {
      return;
    }

    const RecognitionCtor = getSpeechRecognitionConstructor();
    if (!RecognitionCtor) {
      // Seamless automatic upgrade to Gemini HD Voice Capture when SpeechRecognition API is missing!
      sessionActiveRef.current = false;
      setSessionActive(false);
      void startHdRecording();
      return;
    }

    isStartingRef.current = true;
    const recognition = new RecognitionCtor();
    recognition.lang = optionsRef.current.voiceInputLocale;
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognitionRef.current = recognition;

    recognition.onstart = () => {
      isStartingRef.current = false;
      setErrorMessage(null);
      setStatus('listening');
    };

    recognition.onresult = async (event: SpeechRecognitionEventLike) => {
      let interim = '';
      let finalChunk = '';
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const res = event.results[i];
        const txt = res[0]?.transcript || '';
        if (res.isFinal) {
          finalChunk += txt;
        } else {
          interim += txt;
        }
      }

      if (interim) {
        setInterimTranscript(interim);
        // Nudge meter softly on interim speech when Web Speech API owns mic
        setAudioLevels(
          IDLE_LEVELS.map((_, i) => 0.35 + ((interim.length + i * 3) % 5) * 0.13)
        );
      }

      if (finalChunk.trim()) {
        noSpeechRetriesRef.current = 0;
        setInterimTranscript('');
        setAudioLevels(IDLE_LEVELS);
        stopRecognitionInstance();
        await handleResolvedTranscript(finalChunk.trim(), startRecognitionCycle);
      }
    };

    recognition.onerror = (event: SpeechRecognitionErrorEventLike) => {
      isStartingRef.current = false;
      recognitionRef.current = null;
      setAudioLevels(IDLE_LEVELS);
      if (event.error === 'aborted') return;

      lastErrorRef.current = {
        name: event.error,
        message: event.message || event.error,
      };
      refreshDiagnostics();

      if (event.error === 'no-speech' && sessionActiveRef.current) {
        if (optionsRef.current.handsFreeLoop !== false && noSpeechRetriesRef.current < 1) {
          noSpeechRetriesRef.current += 1;
          setTimeout(() => {
            if (sessionActiveRef.current && !isSpeakingRef.current) {
              startRecognitionCycle();
            }
          }, 220);
          return;
        }
        noSpeechRetriesRef.current = 0;
        setStatus('idle');
        setErrorMessage(formatMicrophoneErrorGuidance('no-speech'));
        sessionActiveRef.current = false;
        setSessionActive(false);
        return;
      }

      if (event.error === 'network' || event.error === 'language-not-supported') {
        sessionActiveRef.current = false;
        setSessionActive(false);
        setErrorMessage(i18n.t('assistant:diagnosticsLabels.switchingToHd'));
        void startHdRecording();
        return;
      }

      setErrorMessage(formatMicrophoneErrorGuidance(event.error, event.message));
      setStatus('error');
      sessionActiveRef.current = false;
      setSessionActive(false);
    };

    recognition.onend = () => {
      isStartingRef.current = false;
      recognitionRef.current = null;
      setInterimTranscript('');
      setAudioLevels(IDLE_LEVELS);
      setStatus((prev) => (prev === 'listening' ? 'idle' : prev));
    };

    try {
      recognition.start();
    } catch (err: unknown) {
      isStartingRef.current = false;
      recognitionRef.current = null;
      const e = err as Error;
      lastErrorRef.current = { name: e.name || 'StartError', message: e.message };
      setErrorMessage(formatMicrophoneErrorGuidance(e.name || 'StartError', e.message));
      setStatus('error');
      sessionActiveRef.current = false;
      setSessionActive(false);
      refreshDiagnostics();
    }
  }, [handleResolvedTranscript, refreshDiagnostics, startHdRecording, stopRecognitionInstance]);

  const startVoiceSession = useCallback(async () => {
    setErrorMessage(null);
    noSpeechRetriesRef.current = 0;
    stopSpeaking();

    if (isHdRecording) {
      stopHdRecording();
      return;
    }

    if (sessionActiveRef.current && recognitionRef.current) {
      return;
    }

    const RecognitionCtor = getSpeechRecognitionConstructor();
    if (!RecognitionCtor) {
      await startHdRecording();
      return;
    }

    const granted = await ensureMicrophoneAccessOnce(false);
    if (!granted) {
      sessionActiveRef.current = false;
      setSessionActive(false);
      return;
    }
    sessionActiveRef.current = true;
    setSessionActive(true);
    startRecognitionCycle();
  }, [ensureMicrophoneAccessOnce, isHdRecording, startHdRecording, startRecognitionCycle, stopHdRecording, stopSpeaking]);

  const endVoiceSession = useCallback(() => {
    sessionActiveRef.current = false;
    noSpeechRetriesRef.current = 0;
    setSessionActive(false);
    setInterimTranscript('');
    if (transcribeAbortRef.current) {
      transcribeAbortRef.current.abort();
      transcribeAbortRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      try {
        mediaRecorderRef.current.onstop = null;
        mediaRecorderRef.current.stop();
      } catch {
        // ignore
      }
      mediaRecorderRef.current = null;
    }
    setIsHdRecording(false);
    stopRecognitionInstance();
    stopSpeaking();
    releaseMicTracks();
    setStatus('idle');
  }, [releaseMicTracks, stopRecognitionInstance, stopSpeaking]);

  useEffect(() => {
    if (prevInputLocaleRef.current === options.voiceInputLocale) return;
    prevInputLocaleRef.current = options.voiceInputLocale;
    refreshDiagnostics();
    if (sessionActiveRef.current && !isSpeakingRef.current && recognitionRef.current) {
      stopRecognitionInstance();
      setTimeout(() => {
        if (sessionActiveRef.current && !isSpeakingRef.current) {
          startRecognitionCycle();
        }
      }, 150);
    }
  }, [options.voiceInputLocale, refreshDiagnostics, startRecognitionCycle, stopRecognitionInstance]);

  const testMicrophone = useCallback(async () => {
    setMicTestResult(null);
    const ok = await ensureMicrophoneAccessOnce(false);
    await refreshDiagnostics();
    if (ok) {
      setMicTestResult(i18n.t('assistant:diagnosticsLabels.micReady'));
      setStatus('idle');
    } else {
      setMicTestResult(i18n.t('assistant:diagnosticsLabels.micCheckFailed'));
    }
  }, [ensureMicrophoneAccessOnce, refreshDiagnostics]);

  useEffect(() => {
    return () => {
      sessionActiveRef.current = false;
      if (transcribeAbortRef.current) transcribeAbortRef.current.abort();
      stopRecognitionInstance();
      stopNeuralAudio();
      releaseMicTracks();
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, [releaseMicTracks, stopNeuralAudio, stopRecognitionInstance]);

  return {
    status,
    interimTranscript,
    errorMessage,
    setErrorMessage,
    isMuted,
    setIsMuted,
    sessionActive,
    diagnostics,
    availableVoices,
    micTestResult,
    audioLevels,
    isHdRecording,
    isPaused,
    activeTtsEngine,
    speakingMessageId,
    refreshDiagnostics,
    startVoiceSession,
    endVoiceSession,
    startHdRecording,
    stopHdRecording,
    stopSpeaking,
    pauseSpeaking,
    resumeSpeaking,
    speakText,
    previewSelectedVoice,
    testMicrophone,
  };
}
