import React, { useState } from 'react';
import { CheckCircle2, FileText, Info, Plus, Upload } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useFinX } from '../context/FinXContext';
import { UploadedDocument } from '../types/finx';
import { formatCurrency, formatDateTime } from '../utils/formatters';

export const DocumentAnalyzerPage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const { documents, uploadDocumentDemo, addTransaction, languagePrefs } = useFinX();
  const cur = languagePrefs.displayCurrency;

  const [selectedDocId, setSelectedDocId] = useState(documents[0]?.id || '');
  const [docCategory, setDocCategory] = useState<UploadedDocument['documentCategory']>('Invoice');
  const [uploading, setUploading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [importedNotice, setImportedNotice] = useState<string | null>(null);

  const activeDoc = documents.find((d) => d.id === selectedDocId) || documents[0] || null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setErrorMsg(null);
    setImportedNotice(null);

    if (file.size > 10 * 1024 * 1024) {
      setErrorMsg(t('business:extraPages.docTooLarge'));
      return;
    }

    try {
      setUploading(true);
      const created = await uploadDocumentDemo(file, docCategory);
      setSelectedDocId(created.id);
    } catch (err: unknown) {
      setErrorMsg((err as Error)?.message || t('business:extraPages.docInspectFailed'));
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-2xl">{t('common:nav.documents')}</h2>
        <p className="text-sm text-slate-600 dark:text-[#94A3B8] mt-1">
          {t('business:extraPages.documentsSubtitle')}
        </p>
      </div>

      <div className="p-3.5 rounded-xl border border-amber-400/40 bg-amber-500/5 text-xs text-amber-800 dark:text-amber-200 flex items-start gap-2.5">
        <Info className="w-4 h-4 shrink-0 mt-0.5" />
        <span>{t('business:extraPages.docNotice')}</span>
      </div>

      {/* Upload Bar */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <select
            value={docCategory}
            onChange={(e) => setDocCategory(e.target.value as UploadedDocument['documentCategory'])}
            className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
          >
            {(['Invoice', 'Receipt', 'Financial Statement', 'Expense Record', 'Business Report'] as const).map(
              (cat) => (
                <option key={cat} value={cat}>
                  {t(`business:extraPages.docCategories.${cat}`, { defaultValue: cat })}
                </option>
              )
            )}
          </select>

          <label className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 cursor-pointer hover:bg-teal-700">
            <Upload className="w-4 h-4" />
            <span>{uploading ? t('business:extraPages.docInspecting') : t('business:extraPages.docSelectFile')}</span>
            <input
              type="file"
              accept=".pdf,.csv,.txt,.json,.png,.jpg,.jpeg"
              onChange={handleFileChange}
              className="sr-only"
            />
          </label>
        </div>

        <span className="text-xs text-slate-500 dark:text-[#94A3B8]">
          {t('business:extraPages.docSupported')}
        </span>
      </div>

      {errorMsg && (
        <div className="p-3 rounded-lg border border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-[#F87171]">
          {errorMsg}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden">
          {documents.length === 0 ? (
            <div className="p-6 text-center text-xs text-slate-500">
              {t('business:extraPages.docEmpty')}
            </div>
          ) : (
            documents.map((doc) => (
              <button
                key={doc.id}
                type="button"
                onClick={() => {
                  setSelectedDocId(doc.id);
                  setImportedNotice(null);
                }}
                className={`w-full p-4 text-start transition-colors flex items-start gap-3 ${
                  activeDoc?.id === doc.id
                    ? 'bg-teal-500/10'
                    : 'hover:bg-slate-50 dark:hover:bg-[#172235]'
                }`}
              >
                <FileText className="w-4 h-4 text-teal-600 dark:text-[#14B8A6] shrink-0 mt-0.5" />
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-semibold truncate">{doc.fileName}</div>
                  <div className="text-[11px] text-slate-500 dark:text-[#94A3B8] mt-0.5">
                    {t(`business:extraPages.docCategories.${doc.documentCategory}`, { defaultValue: doc.documentCategory })} · {doc.fileSizeKb} KB · {doc.status}
                  </div>
                </div>
              </button>
            ))
          )}
        </div>

        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6">
          {activeDoc ? (
            <div className="space-y-5">
              <div className="pb-4 border-b border-slate-200 dark:border-slate-800">
                <div className="text-xs text-teal-600 dark:text-[#14B8A6] font-medium">
                  {t(`business:extraPages.docCategories.${activeDoc.documentCategory}`, { defaultValue: activeDoc.documentCategory })} · {activeDoc.status}
                </div>
                <h3 className="font-display font-bold text-lg mt-1">{activeDoc.fileName}</h3>
                <div className="text-xs text-slate-500 font-mono-nums mt-1">
                  {t('business:extraPages.docUploaded')} {formatDateTime(activeDoc.uploadedAt)} · {activeDoc.fileSizeKb} KB
                </div>
              </div>

              <p className="text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                {activeDoc.extractedSummary}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#172235]">
                  <div className="text-slate-500">{t('business:extraPages.docEntity')}</div>
                  <div className="font-semibold mt-1">{activeDoc.extractedFields.vendorOrEntity || '—'}</div>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#172235]">
                  <div className="text-slate-500">{t('business:extraPages.docAmount')}</div>
                  <div className="font-mono-nums font-bold mt-1">
                    {typeof activeDoc.extractedFields.detectedAmount === 'number'
                      ? formatCurrency(activeDoc.extractedFields.detectedAmount, cur)
                      : '—'}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#172235]">
                  <div className="text-slate-500">{t('business:extraPages.docDate')}</div>
                  <div className="font-mono-nums font-semibold mt-1">
                    {activeDoc.extractedFields.documentDate || '—'}
                  </div>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-[#172235]">
                  <div className="text-slate-500">{t('business:extraPages.docCategory')}</div>
                  <div className="font-semibold mt-1">
                    {activeDoc.extractedFields.suggestedCategory || '—'}
                  </div>
                </div>
              </div>

              {importedNotice ? (
                <div className="inline-flex items-center gap-2 text-xs font-medium text-emerald-600 dark:text-[#34D399]">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{importedNotice}</span>
                </div>
              ) : (
                typeof activeDoc.extractedFields.detectedAmount === 'number' && (
                  <button
                    type="button"
                    onClick={() => {
                      addTransaction({
                        amount: activeDoc.extractedFields.detectedAmount || 0,
                        description: activeDoc.extractedFields.vendorOrEntity || activeDoc.fileName,
                        category: activeDoc.extractedFields.suggestedCategory || 'Food & Dining',
                        date: activeDoc.extractedFields.documentDate || new Date().toISOString().slice(0, 10),
                        paymentMethod: 'Bank Transfer',
                        type: 'expense',
                        notes: `Document Analyzer (${activeDoc.extractedFields.referenceNumber || activeDoc.fileName})`,
                      });
                      setImportedNotice(t('business:extraPages.docImportedSuccess'));
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:border-teal-500"
                  >
                    <Plus className="w-3.5 h-3.5 text-teal-600 dark:text-[#14B8A6]" />
                    <span>{t('business:extraPages.docLogExpense')}</span>
                  </button>
                )
              )}
            </div>
          ) : (
            <div className="py-12 text-center text-xs text-slate-500">{t('business:extraPages.docEmpty')}</div>
          )}
        </div>
      </div>
    </div>
  );
};
