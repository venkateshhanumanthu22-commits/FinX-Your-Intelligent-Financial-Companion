import React from 'react';
import { History, Lock, LogOut, ShieldCheck } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { UserAvatar } from '../components/UserAvatar';
import { useFinX } from '../context/FinXContext';
import { formatDateTime } from '../utils/formatters';

export const PrivacySecurityPage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const { session, logout, extensions, navigate, auditLogs, activeWorkspace } = useFinX();

  const isCloud = session?.authMode !== 'demo-local';
  const rulesRaw = t('business:extraPages.secRules', { returnObjects: true });
  const privacyRules = Array.isArray(rulesRaw) ? (rulesRaw as string[]) : [];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-2xl">{t('common:nav.security')}</h2>
        <p className="text-sm text-slate-600 dark:text-[#94A3B8] mt-1">
          {t('business:extraPages.securitySubtitle')}
        </p>
      </div>

      {/* Security Architecture Statement */}
      <div
        className={`p-4 rounded-xl border flex items-start gap-3 text-xs ${
          isCloud
            ? 'border-emerald-400/40 bg-emerald-500/5 text-emerald-800 dark:text-emerald-200'
            : 'border-amber-400/40 bg-amber-500/5 text-amber-800 dark:text-amber-200'
        }`}
      >
        <Lock className="w-4 h-4 shrink-0 mt-0.5" />
        <span>
          {isCloud
            ? t('business:extraPages.secCloudNotice')
            : t('business:extraPages.secDemoNotice')}
        </span>
      </div>

      {/* Session Control Card */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <UserAvatar user={session?.user} size="lg" />
          <div className="space-y-1 min-w-0">
            <div className="text-xs text-teal-600 dark:text-[#14B8A6] font-semibold">
              {isCloud ? t('business:extraPages.secVerifiedCloud') : t('business:extraPages.secLocalDemo')} ·{' '}
              {activeWorkspace?.name || session?.user.businessName}
            </div>
            <div className="font-display font-bold text-lg truncate">{session?.user.name}</div>
            <div className="text-xs text-slate-500 dark:text-[#94A3B8] break-all">
              {session?.user.email} · {t('business:extraPages.secStarted')}{' '}
              {session ? formatDateTime(session.sessionStartedAt) : '—'}
            </div>
          </div>
        </div>
        <button
          type="button"
          onClick={logout}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg border border-red-300 dark:border-red-800 text-red-600 dark:text-[#F87171] hover:bg-red-50 dark:hover:bg-red-950/30"
        >
          <LogOut className="w-4 h-4" />
          <span>{t('business:extraPages.secEndSession')}</span>
        </button>
      </div>

      {/* Data Access Matrix + Extension Permissions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3">
          <h3 className="font-display font-semibold text-sm flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-teal-600 dark:text-[#14B8A6]" />
            <span>{t('business:extraPages.secRulesTitle')}</span>
          </h3>
          <ul className="space-y-2 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
            {privacyRules.map((rule, i) => (
              <li key={i}>• {rule}</li>
            ))}
          </ul>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h3 className="font-display font-semibold text-sm">{t('business:extraPages.secExtPermTitle')}</h3>
            <button
              type="button"
              onClick={() => navigate('extensions')}
              className="text-xs text-teal-600 dark:text-[#14B8A6] hover:underline shrink-0"
            >
              {t('business:extraPages.secManageExt')}
            </button>
          </div>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {extensions
              .filter((e) => e.status === 'Installed')
              .map((ext) => (
                <div key={ext.id} className="py-2.5">
                  <div className="font-semibold">{ext.name}</div>
                  <div className="font-mono-nums text-[11px] text-slate-500 mt-0.5 break-all">
                    {ext.permissions.join(', ')}
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>

      {/* Firestore Security & Activity Audit Log */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-teal-600 dark:text-[#22D3EE]" />
          <h3 className="font-display font-semibold text-sm">{t('business:extraPages.secAuditTitle')}</h3>
        </div>
        {auditLogs.length === 0 ? (
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {isCloud
              ? t('business:extraPages.secNoAuditCloud')
              : t('business:extraPages.secNoAuditDemo')}
          </p>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {auditLogs.map((log) => (
              <div key={log.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="font-mono-nums font-semibold text-teal-600 dark:text-[#22D3EE]">
                    {log.action}
                  </span>
                  <span className="mx-2 text-slate-400">·</span>
                  <span>{log.summary}</span>
                </div>
                <span className="text-[11px] font-mono-nums text-slate-500 dark:text-slate-400">
                  {formatDateTime(log.createdAt)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
