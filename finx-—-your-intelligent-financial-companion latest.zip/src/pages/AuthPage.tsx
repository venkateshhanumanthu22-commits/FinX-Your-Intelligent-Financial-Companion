import React, { useMemo, useRef, useState } from 'react';
import {
  ArrowLeft,
  Camera,
  CheckCircle2,
  Eye,
  EyeOff,
  ShieldCheck,
  Sparkles,
  Trash2,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { FinXLogo } from '../components/FinXLogo';
import { SearchableLanguageSelector } from '../components/SearchableLanguageSelector';
import { ThemeToggle } from '../components/ThemeToggle';
import { UserAvatar } from '../components/UserAvatar';
import { getLocalizedDomainTheme } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import {
  AVATAR_PRESETS,
  compressAvatarImageFile,
  getDefaultPresetForCategory,
} from '../services/avatarCatalog';
import { ALL_DOMAIN_IDS } from '../services/firestoreRepository';
import { AvatarCategory, DomainId, UserProfile } from '../types/finx';
import { validateEmail, validatePassword } from '../utils/validators';

interface AuthPageProps {
  mode: 'login' | 'register';
}

function getPasswordStrength(pw: string): { score: number; labelKey: 'weak' | 'fair' | 'good' | 'strong'; colorClass: string } {
  let score = 0;
  if (pw.length >= 8) score += 1;
  if (pw.length >= 12) score += 1;
  if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) score += 1;
  if (/\d/.test(pw) && /[^A-Za-z0-9]/.test(pw)) score += 1;
  if (score <= 1) return { score: Math.max(1, score), labelKey: 'weak', colorClass: 'bg-rose-500' };
  if (score === 2) return { score: 2, labelKey: 'fair', colorClass: 'bg-amber-500' };
  if (score === 3) return { score: 3, labelKey: 'good', colorClass: 'bg-cyan-500' };
  return { score: 4, labelKey: 'strong', colorClass: 'bg-emerald-500' };
}

export const AuthPage: React.FC<AuthPageProps> = ({ mode }) => {
  const { t } = useTranslation('common');
  const {
    navigate,
    signInWithGoogle,
    signInWithEmailFirebase,
    registerWithEmailFirebase,
    loginOneClickDemo,
    languagePrefs,
    setUnifiedLanguage,
  } = useFinX();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [role, setRole] = useState<UserProfile['role']>('Individual & Entrepreneur');
  const [businessName, setBusinessName] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Explicit user-chosen avatar presentation (default Neutral; NEVER inferred from name)
  const [avatarCategory, setAvatarCategory] = useState<AvatarCategory>('neutral');
  const [avatarPresetId, setAvatarPresetId] = useState<string>('neutral-compass');
  const [customPhotoDataUrl, setCustomPhotoDataUrl] = useState<string | undefined>(undefined);
  const [enabledDomains, setEnabledDomains] = useState<DomainId[]>([...ALL_DOMAIN_IDS]);

  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<{
    name?: string;
    email?: string;
    password?: string;
    confirmPassword?: string;
  }>({});
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const categoryPresets = useMemo(
    () => AVATAR_PRESETS.filter((p) => p.category === avatarCategory),
    [avatarCategory]
  );

  const roleDisplayLabel = (r: UserProfile['role']) => {
    if (r === 'Product Business Owner') return t('roles.productOwner');
    if (r === 'Consultant') return t('roles.consultant');
    if (r === 'Individual') return t('roles.individual');
    return t('roles.dual');
  };

  const strength = useMemo(() => getPasswordStrength(password), [password]);

  const handleCategoryChange = (cat: AvatarCategory) => {
    setAvatarCategory(cat);
    const def = getDefaultPresetForCategory(cat);
    setAvatarPresetId(def.id);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressAvatarImageFile(file);
      setCustomPhotoDataUrl(compressed);
      setErrorMsg(null);
    } catch (err) {
      setErrorMsg((err as Error)?.message || t('states.errorGeneric'));
    }
  };

  const toggleDomain = (id: DomainId) => {
    setEnabledDomains((prev) => {
      if (prev.includes(id)) {
        return prev.length > 1 ? prev.filter((d) => d !== id) : prev;
      }
      return [...prev, id];
    });
  };

  const onboardingOverrides = {
    name: name.trim() || undefined,
    role,
    businessName: businessName.trim() || undefined,
    avatarCategory,
    avatarPresetId,
    customPhotoDataUrl,
    enabledDomains,
    currency: languagePrefs.displayCurrency,
  };

  const handleGoogleSignIn = async () => {
    setErrorMsg(null);
    setSuccessMsg(null);
    setFieldErrors({});
    setBusy(true);
    const res = await signInWithGoogle(onboardingOverrides);
    setBusy(false);
    if (!res.ok && res.error) {
      setErrorMsg(res.error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const nextErrors: typeof fieldErrors = {};
    const emailErr = validateEmail(email);
    if (emailErr) nextErrors.email = emailErr;

    const pwErr = validatePassword(password, mode === 'register');
    if (pwErr) nextErrors.password = pwErr;

    if (mode === 'register') {
      if (!name.trim()) nextErrors.name = t('auth.enterDisplayName');
      if (password !== confirmPassword) nextErrors.confirmPassword = t('auth.passwordsMismatch');
    }

    if (Object.keys(nextErrors).length > 0) {
      setFieldErrors(nextErrors);
      setErrorMsg(Object.values(nextErrors)[0] || t('auth.enterEmailPassword'));
      return;
    }

    setFieldErrors({});
    setBusy(true);
    if (mode === 'login') {
      const res = await signInWithEmailFirebase(email, password);
      setBusy(false);
      if (!res.ok && res.error) {
        setErrorMsg(res.error);
      }
    } else {
      const res = await registerWithEmailFirebase({
        name: name.trim(),
        email: email.trim(),
        password,
        confirmPassword,
        role,
        businessName: businessName.trim() || `${name.trim()} ${t('header.finxWorkspace')}`,
        avatarCategory,
        avatarPresetId,
        customPhotoDataUrl,
        enabledDomains,
        currency: languagePrefs.displayCurrency,
      });
      setBusy(false);
      if (!res.ok) {
        setErrorMsg(res.error || t('states.errorGeneric'));
        return;
      }
      if (res.verificationSent) {
        setSuccessMsg(t('auth.verificationEmailSent'));
      }
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] flex flex-col justify-between p-3 sm:p-6">
      <div className="max-w-6xl w-full mx-auto flex flex-wrap items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => navigate('welcome')}
          className="inline-flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white whitespace-nowrap"
        >
          <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
          <span>{t('auth.backToWelcome')}</span>
        </button>

        <div className="flex items-center gap-2">
          <SearchableLanguageSelector
            value={languagePrefs.displayLanguage}
            onChange={setUnifiedLanguage}
            compact
          />
          <ThemeToggle compact />
        </div>
      </div>

      <div className="max-w-6xl w-full mx-auto my-6 sm:my-8 grid grid-cols-1 lg:grid-cols-12 gap-5 sm:gap-6 items-start">
        {/* Left Panel: Personalized Avatar & Domain Onboarding */}
        <div className="lg:col-span-5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-6 space-y-5">
          <div className="flex items-center gap-4">
            <UserAvatar
              size="xl"
              category={avatarCategory}
              presetId={avatarPresetId}
              customPhotoDataUrl={customPhotoDataUrl}
              name={name || t('brandName')}
            />
            <div className="min-w-0">
              <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wider text-teal-600 dark:text-[#22D3EE]">
                <Sparkles className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{t('auth.personalizedWorkspace')}</span>
              </span>
              <h2 className="font-display font-bold text-lg text-slate-900 dark:text-white mt-0.5 truncate">
                {name.trim() || (mode === 'login' ? t('auth.yourProfile') : t('auth.customizeIdentity'))}
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {businessName.trim() || roleDisplayLabel(role)}
              </p>
            </div>
          </div>

          {/* Explicit Avatar Presentation Selector */}
          <div className="space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                {t('avatars.title')}
              </label>
              <div className="flex items-center gap-1.5">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="inline-flex items-center gap-1 rounded-lg border border-slate-200 dark:border-slate-700 px-2.5 py-1 text-[11px] font-medium hover:border-teal-500 transition-colors"
                >
                  <Camera className="w-3 h-3" />
                  <span>{t('avatars.uploadPhoto')}</span>
                </button>
                {customPhotoDataUrl && (
                  <button
                    type="button"
                    onClick={() => setCustomPhotoDataUrl(undefined)}
                    title={t('avatars.removePhoto')}
                    className="p-1 rounded-lg text-rose-500 hover:bg-rose-500/10"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {t('avatars.helper')}
            </p>

            <div className="grid grid-cols-3 gap-2">
              {(['male', 'female', 'neutral'] as AvatarCategory[]).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => handleCategoryChange(cat)}
                  className={`py-2 px-2 rounded-lg border text-xs font-medium transition-colors ${
                    avatarCategory === cat
                      ? 'border-teal-500 bg-teal-500/10 text-teal-700 dark:text-[#22D3EE]'
                      : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-400'
                  }`}
                >
                  {cat === 'male'
                    ? t('avatars.male')
                    : cat === 'female'
                      ? t('avatars.female')
                      : t('avatars.neutral')}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-1">
              {categoryPresets.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setAvatarPresetId(preset.id);
                    setCustomPhotoDataUrl(undefined);
                  }}
                  title={preset.label}
                  className={`p-1 rounded-xl border transition-all ${
                    !customPhotoDataUrl && avatarPresetId === preset.id
                      ? 'border-teal-500 ring-2 ring-teal-500/30'
                      : 'border-slate-200 dark:border-slate-700 opacity-80 hover:opacity-100'
                  }`}
                >
                  <UserAvatar size="sm" category={preset.category} presetId={preset.id} />
                </button>
              ))}
            </div>
          </div>

          {/* Domain Onboarding Selection */}
          <div className="space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                {t('auth.activeDomainsCount', { count: enabledDomains.length })}
              </span>
              <span className="text-[11px] text-slate-500 dark:text-slate-400">
                {t('auth.customizableAnytime')}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2">
              {ALL_DOMAIN_IDS.map((id) => {
                const theme = getLocalizedDomainTheme(id);
                const checked = enabledDomains.includes(id);
                return (
                  <button
                    key={id}
                    type="button"
                    onClick={() => toggleDomain(id)}
                    className={`flex items-center justify-between gap-2 px-3 py-2 rounded-lg border text-start transition-colors ${
                      checked
                        ? 'border-teal-500/60 bg-teal-500/5 dark:bg-teal-500/10'
                        : 'border-slate-200 dark:border-slate-800 opacity-65 hover:opacity-100'
                    }`}
                  >
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {theme.label}
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                        {theme.tagline}
                      </p>
                    </div>
                    <input
                      type="checkbox"
                      checked={checked}
                      readOnly
                      aria-label={theme.label}
                      className="rounded text-teal-600 pointer-events-none shrink-0"
                    />
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Panel: Cloud Auth + Email + Demo Fallback */}
        <div className="lg:col-span-7 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-8">
          <div className="mb-6">
            <FinXLogo size="md" />
            <h1 className="mt-4 font-display font-bold text-xl sm:text-2xl text-slate-900 dark:text-[#F8FAFC]">
              {mode === 'login' ? t('auth.welcomeBack') : t('auth.createWorkspace')}
            </h1>
            <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">
              {t('auth.cloudNotice')}
            </p>
          </div>

          {errorMsg && (
            <div className="mb-4 p-3 rounded-lg border border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/30 text-xs text-red-700 dark:text-[#F87171]">
              {errorMsg}
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 rounded-lg border border-emerald-300 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/30 text-xs text-emerald-700 dark:text-[#34D399] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Primary Google Sign-In */}
          <button
            type="button"
            onClick={handleGoogleSignIn}
            disabled={busy}
            className="w-full py-3 px-4 rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-semibold text-sm flex items-center justify-center gap-3 hover:border-teal-500 transition-colors disabled:opacity-50 shadow-xs"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 shrink-0" aria-hidden="true">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.11-6.72-4.96H1.29v3.14C3.26 21.3 7.31 24 12 24Z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.24c-.24-.72-.38-1.49-.38-2.24s.14-1.52.38-2.24V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.99-3.14Z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.99 3.14c.95-2.85 3.6-4.96 6.72-4.96Z"
              />
            </svg>
            <span>{t('auth.continueGoogle')}</span>
          </button>

          <div className="my-5 flex items-center gap-3 text-[11px] uppercase tracking-wider text-slate-400">
            <span className="h-px flex-1 bg-slate-200 dark:bg-slate-800" />
            <span>{t('auth.orEmailPassword')}</span>
            <span className="h-px flex-1 bg-slate-200 dark:bg-slate-800" />
          </div>

          <form onSubmit={handleSubmit} noValidate className="space-y-4">
            {mode === 'register' && (
              <>
                <div>
                  <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                    {t('auth.fullNameLabel')}
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => {
                      setName(e.target.value);
                      if (fieldErrors.name) setFieldErrors((p) => ({ ...p, name: undefined }));
                    }}
                    placeholder={t('auth.namePlaceholder')}
                    className={`w-full px-3.5 py-2.5 text-sm rounded-lg border bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                      fieldErrors.name ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                    }`}
                  />
                  {fieldErrors.name && (
                    <p className="mt-1 text-[11px] text-rose-500">{fieldErrors.name}</p>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                      {t('auth.roleLabel')}
                    </label>
                    <select
                      value={role}
                      onChange={(e) => setRole(e.target.value as UserProfile['role'])}
                      className="w-full px-3 py-2.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC]"
                    >
                      <option value="Individual & Entrepreneur">{t('roles.dual')}</option>
                      <option value="Product Business Owner">{t('roles.productOwner')}</option>
                      <option value="Consultant">{t('roles.consultant')}</option>
                      <option value="Individual">{t('roles.individual')}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                      {t('auth.businessNameLabel')}
                    </label>
                    <input
                      type="text"
                      value={businessName}
                      onChange={(e) => setBusinessName(e.target.value)}
                      placeholder={t('auth.businessPlaceholder')}
                      className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                {t('auth.emailLabel')}
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (fieldErrors.email) setFieldErrors((p) => ({ ...p, email: undefined }));
                }}
                placeholder={t('auth.emailPlaceholder')}
                className={`w-full px-3.5 py-2.5 text-sm rounded-lg border bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                  fieldErrors.email ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                }`}
              />
              {fieldErrors.email && (
                <p className="mt-1 text-[11px] text-rose-500">{fieldErrors.email}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                {t('auth.passwordLabel')}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (fieldErrors.password) setFieldErrors((p) => ({ ...p, password: undefined }));
                  }}
                  placeholder="••••••••"
                  className={`w-full pe-10 ps-3.5 py-2.5 text-sm rounded-lg border bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    fieldErrors.password ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  aria-label={showPassword ? t('auth.hidePassword') : t('auth.showPassword')}
                  className="absolute end-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              {fieldErrors.password && (
                <p className="mt-1 text-[11px] text-rose-500">{fieldErrors.password}</p>
              )}
              {mode === 'register' && (
                <div className="mt-2 space-y-1">
                  {password.length > 0 && (
                    <div className="flex items-center gap-2">
                      <div className="flex-1 grid grid-cols-4 gap-1 h-1.5">
                        {[1, 2, 3, 4].map((step) => (
                          <span
                            key={step}
                            className={`rounded-full ${
                              step <= strength.score
                                ? strength.colorClass
                                : 'bg-slate-200 dark:bg-slate-700'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                        {t('auth.passwordStrength.label')}:{' '}
                        {t(`auth.passwordStrength.${strength.labelKey}`)}
                      </span>
                    </div>
                  )}
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    {t('auth.passwordHint')}
                  </p>
                </div>
              )}
            </div>

            {mode === 'register' && (
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
                  {t('auth.confirmPasswordLabel')}
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => {
                    setConfirmPassword(e.target.value);
                    if (fieldErrors.confirmPassword) {
                      setFieldErrors((p) => ({ ...p, confirmPassword: undefined }));
                    }
                  }}
                  placeholder="••••••••"
                  className={`w-full px-3.5 py-2.5 text-sm rounded-lg border bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] focus:outline-none focus:ring-2 focus:ring-teal-500 ${
                    fieldErrors.confirmPassword ? 'border-rose-500' : 'border-slate-200 dark:border-slate-700'
                  }`}
                />
                {fieldErrors.confirmPassword && (
                  <p className="mt-1 text-[11px] text-rose-500">{fieldErrors.confirmPassword}</p>
                )}
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="w-full py-2.5 px-4 text-sm font-semibold rounded-xl bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 hover:bg-teal-700 dark:hover:bg-[#22D3EE] transition-colors disabled:opacity-50"
            >
              {busy
                ? t('auth.authenticating')
                : mode === 'login'
                  ? t('auth.signInButton')
                  : t('auth.registerButton')}
            </button>
          </form>

          <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <button
              type="button"
              onClick={() => loginOneClickDemo(onboardingOverrides)}
              className="w-full py-2.5 px-4 text-xs font-semibold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-[#172235] text-slate-800 dark:text-[#F8FAFC] hover:border-teal-500 transition-colors"
            >
              {t('auth.quickDemoSignIn')} {t('auth.quickDemoSuffix')}
            </button>

            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <button
                type="button"
                onClick={() => navigate(mode === 'login' ? 'register' : 'login')}
                className="font-medium text-teal-600 dark:text-[#14B8A6] hover:underline"
              >
                {mode === 'login' ? t('auth.switchToRegister') : t('auth.switchToLogin')}
              </button>
              <span className="inline-flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-teal-500" />
                <span>{t('auth.verifiedSecurity')}</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="text-center text-xs text-slate-500 dark:text-[#94A3B8]">
        {t('brandName')} · {t('tagline')}
      </div>
    </div>
  );
};
