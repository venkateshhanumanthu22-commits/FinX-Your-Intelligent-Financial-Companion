import React, { useState } from 'react';
import { CalendarClock, Plus, Trash2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useFinX } from '../context/FinXContext';
import { FinancialPlanItem } from '../types/finx';
import { formatCurrency, formatDateShort } from '../utils/formatters';

export const SmartPlannerPage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const { plans, addPlan, updatePlan, deletePlan, metrics, languagePrefs } = useFinX();
  const cur = languagePrefs.displayCurrency;

  const defaultDueIso = new Date(Date.now() + 90 * 86400_000).toISOString().slice(0, 10);

  const [title, setTitle] = useState('');
  const [planType, setPlanType] = useState<FinancialPlanItem['planType']>('Savings Goal');
  const [targetAmount, setTargetAmount] = useState('');
  const [allocatedAmount, setAllocatedAmount] = useState('');
  const [dueDate] = useState(defaultDueIso);
  const [notes, setNotes] = useState('');
  const [planError, setPlanError] = useState<string | null>(null);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setPlanError(null);
    if (!title.trim()) {
      setPlanError(t('business:extraPages.plannerTitleErr'));
      return;
    }
    const target = Number(targetAmount);
    if (!Number.isFinite(target) || target <= 0) {
      setPlanError(t('business:extraPages.plannerTargetErr'));
      return;
    }
    const alloc = Math.max(0, Number(allocatedAmount) || 0);
    addPlan({
      title: title.trim(),
      planType,
      targetAmount: target,
      allocatedAmount: alloc,
      dueDate,
      status: alloc >= target ? 'Completed' : alloc >= target * 0.6 ? 'On Track' : 'Attention Needed',
      notes: notes.trim() || t('business:extraPages.plannerDefaultNote'),
    });
    setTitle('');
    setTargetAmount('');
    setAllocatedAmount('');
    setNotes('');
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-2xl">{t('common:nav.planner')}</h2>
        <p className="text-sm text-slate-600 dark:text-[#94A3B8] mt-1">
          {t('business:extraPages.plannerSubtitle')}
        </p>
      </div>

      {/* Data-grounded Recommendation Banner */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="text-xs font-semibold text-teal-600 dark:text-[#14B8A6]">
            {t('business:extraPages.plannerGuidanceLabel')}
          </div>
          <p className="text-sm text-slate-700 dark:text-[#F8FAFC]">
            {t('business:extraPages.plannerGuidanceBody', {
              surplus: formatCurrency(metrics.personalNetSavings, cur),
              receivables: formatCurrency(metrics.servicePendingReceivables, cur),
            })}
          </p>
        </div>
      </div>

      {/* Add Plan Form */}
      <form
        onSubmit={handleCreate}
        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end"
      >
        <div className="lg:col-span-2">
          <label className="block text-xs text-slate-500 mb-1">{t('business:extraPages.plannerTitleLabel')}</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder={t('business:extraPages.plannerTitlePlaceholder')}
            required
            className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">{t('business:extraPages.plannerTypeLabel')}</label>
          <select
            value={planType}
            onChange={(e) => setPlanType(e.target.value as FinancialPlanItem['planType'])}
            className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
          >
            <option value="Savings Goal">{t('business:extraPages.plannerTypes.Savings Goal')}</option>
            <option value="Monthly Budget">{t('business:extraPages.plannerTypes.Monthly Budget')}</option>
            <option value="Bill Reminder">{t('business:extraPages.plannerTypes.Bill Reminder')}</option>
            <option value="Business Cash-Flow">{t('business:extraPages.plannerTypes.Business Cash-Flow')}</option>
          </select>
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">{t('business:extraPages.plannerTargetLabel')}</label>
          <input
            type="number"
            value={targetAmount}
            onChange={(e) => setTargetAmount(e.target.value)}
            required
            className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
          />
        </div>
        <div>
          <label className="block text-xs text-slate-500 mb-1">{t('business:extraPages.plannerAllocatedLabel')}</label>
          <input
            type="number"
            value={allocatedAmount}
            onChange={(e) => setAllocatedAmount(e.target.value)}
            className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
          />
        </div>
        <button
          type="submit"
          className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950"
        >
          <Plus className="w-4 h-4" />
          <span>{t('business:extraPages.addPlan')}</span>
        </button>
      </form>

      {planError && (
        <p className="text-xs text-red-600 dark:text-[#F87171]">{planError}</p>
      )}

      {/* Plans Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {plans.map((p) => {
          const pct =
            p.targetAmount > 0
              ? Math.min(100, Math.round((p.allocatedAmount / p.targetAmount) * 100))
              : 0;
          return (
            <div
              key={p.id}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 flex flex-col justify-between space-y-4"
            >
              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-teal-600 dark:text-[#14B8A6] font-medium">
                    {t(`business:extraPages.plannerTypes.${p.planType}`, { defaultValue: p.planType })}
                  </span>
                  <span className="font-mono-nums text-slate-500">{formatDateShort(p.dueDate)}</span>
                </div>
                <h3 className="font-display font-semibold text-base mt-1">{p.title}</h3>
                <p className="text-xs text-slate-500 dark:text-[#94A3B8] mt-1">{p.notes}</p>

                <div className="mt-4 flex items-baseline justify-between text-xs font-mono-nums">
                  <span className="font-bold">{formatCurrency(p.allocatedAmount, cur)}</span>
                  <span className="text-slate-500">
                    / {formatCurrency(p.targetAmount, cur)} ({pct}%)
                  </span>
                </div>
                <div className="mt-1.5 h-2 rounded-full bg-slate-100 dark:bg-[#101827] overflow-hidden">
                  <div
                    style={{ width: `${pct}%` }}
                    className={`h-full rounded-full ${
                      p.status === 'Attention Needed'
                        ? 'bg-amber-500 dark:bg-[#FBBF24]'
                        : 'bg-teal-600 dark:bg-[#14B8A6]'
                    }`}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() =>
                    updatePlan({
                      ...p,
                      allocatedAmount: Math.min(p.targetAmount, p.allocatedAmount + 250),
                      status:
                        p.allocatedAmount + 250 >= p.targetAmount ? 'Completed' : 'On Track',
                    })
                  }
                  className="inline-flex items-center gap-1 text-xs font-semibold text-teal-600 dark:text-[#14B8A6] hover:underline"
                >
                  <CalendarClock className="w-3.5 h-3.5" />
                  <span>+ {formatCurrency(250, cur)}</span>
                </button>
                <button
                  type="button"
                  onClick={() => deletePlan(p.id)}
                  className="p-1.5 text-slate-400 hover:text-red-500"
                  aria-label={t('business:extraPages.plannerDeleteLabel')}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
