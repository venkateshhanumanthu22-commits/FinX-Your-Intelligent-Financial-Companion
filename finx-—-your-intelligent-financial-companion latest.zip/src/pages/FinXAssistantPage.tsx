import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight,
  AudioWaveform,
  Bot,
  HelpCircle,
  Mic,
  MicOff,
  Pause,
  Play,
  RotateCcw,
  Send,
  Square,
  Volume2,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { AssistantOrb } from '../assistant/AssistantOrb';
import { SearchableLanguageSelector } from '../components/SearchableLanguageSelector';
import { useFinX } from '../context/FinXContext';
import { useVoiceAssistant } from '../hooks/useVoiceAssistant';
import { NEURAL_VOICE_PERSONAS } from '../services/aiAssistantService';
import { AppRoute, NeuralVoiceName } from '../types/finx';

interface GuideWorkflowItem {
  id: string;
  question: string;
  steps: string[];
  route: AppRoute;
  actionLabel: string;
}

export const FinXAssistantPage: React.FC = () => {
  const { t } = useTranslation(['assistant', 'common']);
  const {
    assistantMode,
    setAssistantMode,
    assistantMessages,
    assistantBusy,
    assistantError,
    sendAssistantMessage,
    resetAssistantChat,
    openAssistant,
    navigate,
    languagePrefs,
    updateLanguagePrefs,
    settings,
    aiHealth,
  } = useFinX();

  const [input, setInput] = useState('');
  const endRef = useRef<HTMLDivElement | null>(null);

  const voice = useVoiceAssistant({
    voiceInputLocale: languagePrefs.voiceInputLocale,
    voiceOutputLocale: languagePrefs.voiceOutputLocale,
    voiceOutputVoiceURI: languagePrefs.voiceOutputVoiceURI,
    autoSpeakResponses: languagePrefs.autoSpeakResponses,
    speechRate: settings.voiceSpeechRate,
    neuralVoiceName: languagePrefs.neuralVoiceName || 'Kore',
    preferNeuralVoice: languagePrefs.preferNeuralVoice !== false,
    handsFreeLoop: languagePrefs.handsFreeLoop !== false,
    onFinalTranscript: async (spokenText) => {
      const res = await sendAssistantMessage(spokenText);
      return res?.replyText || null;
    },
  });

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [assistantMessages, assistantBusy, voice.interimTranscript]);

  const sendAndOptionallySpeak = async (text: string) => {
    const res = await sendAssistantMessage(text);
    if (res?.replyText && languagePrefs.autoSpeakResponses && !voice.isMuted) {
      void voice.speakText(res.replyText);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || assistantBusy) return;
    const text = input.trim();
    setInput('');
    await sendAndOptionallySpeak(text);
  };

  const suggested = t('assistant:suggestedPostLogin', { returnObjects: true }) as string[];
  const guideWorkflows = useMemo(() => {
    const raw = t('assistant:guideWorkflows', { returnObjects: true });
    return Array.isArray(raw) ? (raw as GuideWorkflowItem[]) : [];
  }, [t]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5 min-w-0">
          <AssistantOrb
            status={assistantBusy && voice.status === 'idle' ? 'processing' : voice.status}
            compact
            audioLevels={voice.audioLevels}
            reducedMotion={settings.reducedMotion}
          />
          <div className="min-w-0">
            <h2 className="font-display font-bold text-xl sm:text-2xl truncate">
              {t('common:nav.assistant')}
            </h2>
            <p className="text-xs text-slate-500 dark:text-[#94A3B8] mt-1">
              {aiHealth?.aiConfigured
                ? t('assistant:diagnosticsLabels.connectedAi', {
                    model: aiHealth.model,
                    voice: languagePrefs.neuralVoiceName || 'Kore',
                  })
                : t('assistant:diagnosticsLabels.connectingAi')}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <SearchableLanguageSelector
            value={languagePrefs.textAssistantLanguage}
            onChange={(code) =>
              updateLanguagePrefs({
                textAssistantLanguage: code,
                useSameLanguageEverywhere: false,
              })
            }
            compact
          />
          <select
            value={languagePrefs.neuralVoiceName || 'Kore'}
            onChange={(e) =>
              updateLanguagePrefs({ neuralVoiceName: e.target.value as NeuralVoiceName })
            }
            aria-label={t('assistant:controls.neuralVoiceLabel')}
            className="px-2.5 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B]"
          >
            {NEURAL_VOICE_PERSONAS.map((persona) => (
              <option key={persona.id} value={persona.id}>
                {persona.label}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => openAssistant(assistantMode)}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950"
          >
            <Mic className="w-4 h-4" />
            <span>{t('assistant:controls.openVoiceOverlay')}</span>
          </button>
          <button
            type="button"
            onClick={resetAssistantChat}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t('assistant:controls.resetChat')}</span>
          </button>
        </div>
      </div>

      {/* Mode Switch */}
      <div className="inline-flex p-1 rounded-xl bg-slate-200/70 dark:bg-[#172235] border border-slate-200 dark:border-slate-800">
        <button
          type="button"
          onClick={() => setAssistantMode('finance-assistant')}
          className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg ${
            assistantMode === 'finance-assistant'
              ? 'bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC] shadow-xs'
              : 'text-slate-600 dark:text-[#94A3B8]'
          }`}
        >
          <Bot className="w-4 h-4 text-teal-600 dark:text-[#14B8A6]" />
          <span>{t('assistant:modeFinance')}</span>
        </button>
        <button
          type="button"
          onClick={() => setAssistantMode('finx-guide')}
          className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-medium rounded-lg ${
            assistantMode === 'finx-guide'
              ? 'bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC] shadow-xs'
              : 'text-slate-600 dark:text-[#94A3B8]'
          }`}
        >
          <HelpCircle className="w-4 h-4 text-cyan-600 dark:text-[#22D3EE]" />
          <span>{t('assistant:modeGuide')}</span>
        </button>
      </div>

      {assistantMode === 'finx-guide' && guideWorkflows.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {guideWorkflows.map((guide) => (
            <div
              key={guide.id}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 flex flex-col justify-between space-y-4"
            >
              <div>
                <h3 className="font-display font-semibold text-sm">{guide.question}</h3>
                <ol className="mt-3 space-y-1.5 text-xs text-slate-600 dark:text-[#94A3B8] list-decimal list-inside">
                  {guide.steps.map((s, idx) => (
                    <li key={idx}>{s}</li>
                  ))}
                </ol>
              </div>
              <button
                type="button"
                onClick={() => navigate(guide.route)}
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-600 dark:text-[#14B8A6] hover:underline self-start"
              >
                <span>{guide.actionLabel}</span>
                <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Conversational Workspace */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] flex flex-col h-[520px] sm:h-[540px] overflow-hidden">
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {assistantMessages.map((m) => (
            <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[85%] sm:max-w-[80%] rounded-2xl px-4 py-3 text-sm whitespace-pre-wrap leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 font-medium'
                    : m.isError
                      ? 'border border-red-300 dark:border-red-800 bg-red-50 dark:bg-red-950/30 text-red-700 dark:text-red-200'
                      : 'border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#172235]'
                }`}
              >
                {m.content}
                {m.role === 'assistant' && !m.isError && (
                  <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2">
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      {m.detectedLanguage
                        ? `${t('assistant:controls.detectedLanguage')}: ${m.detectedLanguage}`
                        : ''}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        if (voice.speakingMessageId === m.id && voice.status === 'speaking') {
                          voice.stopSpeaking();
                        } else {
                          void voice.speakText(m.content, undefined, {
                            forceSpeak: true,
                            messageId: m.id,
                          });
                        }
                      }}
                      className="inline-flex items-center gap-1 rounded-md border border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/60 px-2 py-1 text-[11px] font-medium text-slate-700 dark:text-slate-200 hover:border-teal-500 hover:text-teal-600 dark:hover:text-[#22D3EE] transition-colors"
                    >
                      {voice.speakingMessageId === m.id && voice.status === 'speaking' ? (
                        <>
                          <Square className="w-3 h-3 text-cyan-500" />
                          <span>{t('assistant:controls.stopAudio')}</span>
                        </>
                      ) : (
                        <>
                          <Volume2 className="w-3 h-3 text-teal-500" />
                          <span>{t('assistant:controls.readAloud')}</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
                {m.sources && m.sources.length > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-slate-200/70 dark:border-slate-700/70 space-y-1">
                    <div className="text-[11px] font-semibold uppercase tracking-wide text-slate-500 dark:text-slate-400">
                      {t('assistant:controls.groundedSources')}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {m.sources.map((src) => (
                        <a
                          key={src.uri}
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 rounded-md border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900/60 px-2 py-1 text-[11px] text-teal-600 dark:text-[#22D3EE] hover:underline"
                        >
                          <span className="truncate max-w-[200px]">{src.title}</span>
                          <span aria-hidden="true">↗</span>
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
          {voice.interimTranscript && (
            <div className="flex justify-end">
              <div className="max-w-[80%] rounded-2xl px-4 py-2 text-xs italic border border-teal-500/40 bg-teal-500/5 text-teal-700 dark:text-[#22D3EE]">
                {voice.interimTranscript}...
              </div>
            </div>
          )}
          {assistantBusy && (
            <div className="text-xs text-slate-500 dark:text-[#94A3B8]">
              {t('assistant:status.processing')}
            </div>
          )}
          {(voice.errorMessage || assistantError) && (
            <div className="text-xs text-amber-600 dark:text-[#FBBF24]">
              {voice.errorMessage || assistantError}
            </div>
          )}
          <div ref={endRef} />
        </div>

        <div className="px-4 py-2 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-x-auto bg-slate-50 dark:bg-[#172235]">
          {Array.isArray(suggested) &&
            suggested.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => void sendAndOptionallySpeak(s)}
                disabled={assistantBusy}
                className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] whitespace-nowrap shrink-0 hover:border-teal-500"
              >
                {s}
              </button>
            ))}
        </div>

        <form onSubmit={handleSubmit} className="p-3 sm:p-4 border-t border-slate-200 dark:border-slate-800 flex flex-wrap sm:flex-nowrap gap-2">
          <button
            type="button"
            onClick={voice.sessionActive ? voice.endVoiceSession : voice.startVoiceSession}
            title={voice.sessionActive ? t('assistant:controls.stopMic') : t('assistant:controls.handsFree')}
            className={`inline-flex items-center gap-1.5 px-3 py-2.5 text-xs font-semibold rounded-xl border transition-colors whitespace-nowrap ${
              voice.sessionActive
                ? 'border-red-500 bg-red-600 text-white'
                : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] hover:border-teal-500'
            }`}
          >
            {voice.sessionActive ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4 text-teal-500" />}
            <span className="hidden md:inline">
              {voice.sessionActive ? t('assistant:controls.stopMic') : t('assistant:controls.handsFree')}
            </span>
          </button>

          <button
            type="button"
            onClick={voice.isHdRecording ? voice.stopHdRecording : voice.startHdRecording}
            title={t('assistant:controls.hdVoiceCapture')}
            className={`inline-flex items-center gap-1.5 px-3 py-2.5 text-xs font-semibold rounded-xl border transition-colors whitespace-nowrap ${
              voice.isHdRecording
                ? 'border-rose-500 bg-rose-500/15 text-rose-600 dark:text-rose-300'
                : 'border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] hover:border-teal-500'
            }`}
          >
            <AudioWaveform className="w-4 h-4 text-cyan-500" />
            <span className="hidden md:inline">
              {voice.isHdRecording ? t('assistant:controls.sendHdAudio') : t('assistant:controls.hdMic')}
            </span>
          </button>

          {voice.status === 'speaking' && (
            <>
              <button
                type="button"
                onClick={voice.isPaused ? voice.resumeSpeaking : voice.pauseSpeaking}
                title={voice.isPaused ? t('assistant:controls.resumeSpeaking') : t('assistant:controls.pauseSpeaking')}
                className="inline-flex items-center gap-1.5 px-3 py-2.5 text-xs font-semibold rounded-xl border border-teal-500/40 bg-teal-500/10 text-teal-700 dark:text-[#14B8A6] whitespace-nowrap"
              >
                {voice.isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
              </button>
              <button
                type="button"
                onClick={voice.stopSpeaking}
                title={t('assistant:controls.stopSpeaking')}
                className="inline-flex items-center gap-1.5 px-3 py-2.5 text-xs font-semibold rounded-xl border border-cyan-500/40 bg-cyan-500/10 text-cyan-700 dark:text-[#22D3EE] whitespace-nowrap"
              >
                <Square className="w-4 h-4" />
              </button>
            </>
          )}

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={t('assistant:controls.inputPlaceholder')}
            className="flex-1 min-w-[140px] px-3.5 sm:px-4 py-2.5 text-sm rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
          <button
            type="submit"
            disabled={!input.trim() || assistantBusy}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold rounded-xl bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 disabled:opacity-40"
          >
            <Send className="w-4 h-4" />
            <span>{t('assistant:controls.send')}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
