import React, { useMemo, useState } from 'react';
import { CheckCheck, Info, Mail, MailOpen, Search, Trash2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useFinX } from '../context/FinXContext';
import { NotificationType } from '../types/finx';
import { formatCurrency, formatDateTime } from '../utils/formatters';

export const FinXMessagesPage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const {
    messages,
    unreadCount,
    markMessageRead,
    markAllMessagesRead,
    deleteMessage,
    languagePrefs,
  } = useFinX();

  const cur = languagePrefs.displayCurrency;
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'ALL' | NotificationType>('ALL');
  const [selectedId, setSelectedId] = useState<string>(messages[0]?.id || '');

  const filtered = useMemo(() => {
    return messages.filter((m) => {
      if (typeFilter !== 'ALL' && m.type !== typeFilter) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          m.title.toLowerCase().includes(q) ||
          m.content.toLowerCase().includes(q) ||
          m.sender.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [messages, search, typeFilter]);

  const activeMessage =
    filtered.find((m) => m.id === selectedId) || filtered[0] || null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display font-bold text-2xl">{t('common:nav.messages')}</h2>
          <p className="text-xs text-slate-500 dark:text-[#94A3B8] mt-1">
            {t('business:extraPages.messagesUnread', { count: unreadCount })}
          </p>
        </div>
        <button
          type="button"
          onClick={markAllMessagesRead}
          className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 hover:border-teal-500"
        >
          <CheckCheck className="w-4 h-4 text-teal-600 dark:text-[#14B8A6]" />
          <span>{t('business:extraPages.markAllRead')}</span>
        </button>
      </div>

      {/* Explicit Internal vs Verified Bank Distinction */}
      <div className="p-3.5 rounded-xl border border-cyan-500/30 bg-cyan-500/5 text-xs text-slate-600 dark:text-[#94A3B8] flex items-start gap-2.5">
        <Info className="w-4 h-4 text-cyan-600 dark:text-[#22D3EE] shrink-0 mt-0.5" />
        <span>{t('business:extraPages.messagesNotice')}</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left List */}
        <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] overflow-hidden flex flex-col">
          <div className="p-3 border-b border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t('business:extraPages.messagesSearch')}
                className="w-full ps-9 pe-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as 'ALL' | NotificationType)}
              className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              <option value="ALL">{t('business:extraPages.allCategories')}</option>
              <option value="business_payment_confirmation">{t('business:extraPages.msgTypes.business_payment_confirmation')}</option>
              <option value="payment_received">{t('business:extraPages.msgTypes.payment_received')}</option>
              <option value="payment_sent">{t('business:extraPages.msgTypes.payment_sent')}</option>
              <option value="payment_pending">{t('business:extraPages.msgTypes.payment_pending')}</option>
              <option value="low_inventory">{t('business:extraPages.msgTypes.low_inventory')}</option>
              <option value="budget_warning">{t('business:extraPages.msgTypes.budget_warning')}</option>
              <option value="financial_reminder">{t('business:extraPages.msgTypes.financial_reminder')}</option>
            </select>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[460px] overflow-y-auto">
            {filtered.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500">
                {t('business:extraPages.noMessages')}
              </div>
            ) : (
              filtered.map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => {
                    setSelectedId(m.id);
                    markMessageRead(m.id, true);
                  }}
                  className={`w-full p-3.5 text-start transition-colors ${
                    activeMessage?.id === m.id
                      ? 'bg-teal-500/10'
                      : 'hover:bg-slate-50 dark:hover:bg-[#172235]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-[#94A3B8]">
                    <span className="font-semibold text-slate-700 dark:text-slate-200">{m.sender}</span>
                    <span className="font-mono-nums">{formatDateTime(m.timestamp)}</span>
                  </div>
                  <div className="mt-1 flex items-center justify-between gap-2">
                    <span className={`text-xs truncate ${!m.read ? 'font-bold' : 'font-medium'}`}>
                      {m.title}
                    </span>
                    {!m.read && (
                      <span className="text-[10px] font-semibold text-teal-600 dark:text-[#22D3EE] shrink-0">
                        {t('business:extraPages.msgNew')}
                      </span>
                    )}
                  </div>
                  <p className="mt-1 text-[11px] text-slate-500 dark:text-[#94A3B8] line-clamp-1">
                    {m.content}
                  </p>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Right Detail Pane */}
        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6">
          {activeMessage ? (
            <div className="space-y-5">
              <div className="flex flex-wrap items-start justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <div className="text-xs text-teal-600 dark:text-[#14B8A6] font-medium">
                    {activeMessage.sourceDomain} · {activeMessage.sender}
                  </div>
                  <h3 className="font-display font-bold text-lg mt-1">{activeMessage.title}</h3>
                  <div className="text-xs font-mono-nums text-slate-500 mt-1">
                    {formatDateTime(activeMessage.timestamp)}
                    {activeMessage.referenceId ? ` · ${t('business:extraPages.msgRef')}: ${activeMessage.referenceId}` : ''}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => markMessageRead(activeMessage.id, !activeMessage.read)}
                    className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-[#94A3B8]"
                    title={activeMessage.read ? t('business:extraPages.msgMarkUnread') : t('business:extraPages.msgMarkRead')}
                    aria-label={activeMessage.read ? t('business:extraPages.msgMarkUnread') : t('business:extraPages.msgMarkRead')}
                  >
                    {activeMessage.read ? <Mail className="w-4 h-4" /> : <MailOpen className="w-4 h-4" />}
                  </button>
                  <button
                    type="button"
                    onClick={() => deleteMessage(activeMessage.id)}
                    className="p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 hover:text-red-500"
                    title={t('business:extraPages.msgDelete')}
                    aria-label={t('business:extraPages.msgDelete')}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {typeof activeMessage.amount === 'number' && (
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#172235] border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-xs text-slate-500 dark:text-[#94A3B8]">{t('business:extraPages.msgRecordedAmount')}</span>
                  <span className="font-mono-nums text-xl font-bold text-slate-900 dark:text-[#F8FAFC]">
                    {formatCurrency(activeMessage.amount, cur)}
                  </span>
                </div>
              )}

              <p className="text-sm leading-relaxed text-slate-700 dark:text-[#F8FAFC]">
                {activeMessage.content}
              </p>

              <p className="text-xs text-slate-500 dark:text-[#94A3B8] pt-3 border-t border-slate-100 dark:border-slate-800">
                {t('business:extraPages.msgOrigin')}
              </p>
            </div>
          ) : (
            <div className="py-16 text-center text-xs text-slate-500">
              {t('business:extraPages.msgSelectPrompt')}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
