import React, { useEffect, useMemo, useState } from 'react';
import {
  PackagePlus,
  Plus,
  RotateCcw,
  Search,
  ShoppingBag,
  Trash2,
  TrendingUp,
  Truck,
  Users,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { DomainBrand3D } from '../components/DomainBrand3D';
import { StatCard } from '../components/StatCard';
import { DOMAIN_THEMES } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import { formatCurrency, formatDateShort } from '../utils/formatters';

const DRAFT_KEY = 'product-add';

export const ProductBusinessPage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const {
    activeWorkspace,
    settings,
    products,
    addProduct,
    deleteProduct,
    suppliers,
    addSupplier,
    customers,
    addCustomer,
    sales,
    recordSale,
    purchases,
    restockProduct,
    businessExpenses,
    addBusinessExpense,
    metrics,
    languagePrefs,
    drafts,
    setDraft,
    clearDraft,
  } = useFinX();

  const domainTheme = DOMAIN_THEMES['product-business'];
  const cur = languagePrefs.displayCurrency;
  const [activeTab, setActiveTab] = useState<'inventory' | 'suppliers' | 'customers' | 'forecast'>('inventory');
  const [search, setSearch] = useState('');
  const [stockFilter, setStockFilter] = useState<'all' | 'low'>('all');
  const [deleteProdId, setDeleteProdId] = useState<string | null>(null);

  const savedDraft = drafts[DRAFT_KEY] as
    | {
        pCode?: string;
        pName?: string;
        pCategory?: string;
        pCost?: string;
        pPrice?: string;
        pQty?: string;
        pReorder?: string;
      }
    | undefined;

  const [showAddProd, setShowAddProd] = useState(Boolean(savedDraft?.pCode || savedDraft?.pName));
  const [pCode, setPCode] = useState(savedDraft?.pCode || '');
  const [pName, setPName] = useState(savedDraft?.pName || '');
  const [pCategory, setPCategory] = useState(savedDraft?.pCategory || 'Hardware Accessories');
  const [pCost, setPCost] = useState(savedDraft?.pCost || '');
  const [pPrice, setPPrice] = useState(savedDraft?.pPrice || '');
  const [pQty, setPQty] = useState(savedDraft?.pQty || '');
  const [pReorder, setPReorder] = useState(savedDraft?.pReorder || '10');

  useEffect(() => {
    if (!showAddProd) return;
    if (pCode || pName || pCost || pPrice || pQty) {
      setDraft(DRAFT_KEY, { pCode, pName, pCategory, pCost, pPrice, pQty, pReorder });
    }
  }, [pCategory, pCode, pCost, pName, pPrice, pQty, pReorder, setDraft, showAddProd]);

  // Sale Form
  const [saleProdId, setSaleProdId] = useState(products[0]?.id || '');
  const [saleQty, setSaleQty] = useState('1');
  const [saleCustomer, setSaleCustomer] = useState('');
  const [saleError, setSaleError] = useState<string | null>(null);

  // Restock Form
  const [restockProdId, setRestockProdId] = useState(products[0]?.id || '');
  const [restockQty, setRestockQty] = useState('10');
  const [restockSupplier, setRestockSupplier] = useState('');

  // Business Expense Form
  const [expDesc, setExpDesc] = useState('');
  const [expAmt, setExpAmt] = useState('');

  // Supplier Form
  const [supName, setSupName] = useState('');
  const [supContact, setSupContact] = useState('');
  const [supCat, setSupCat] = useState('Hardware');
  const [supLead, setSupLead] = useState('7');

  // Customer Form
  const [custName, setCustName] = useState('');
  const [custContact, setCustContact] = useState('');

  const effectiveSaleProdId = products.some((p) => p.id === saleProdId)
    ? saleProdId
    : products[0]?.id || '';
  const effectiveRestockProdId = products.some((p) => p.id === restockProdId)
    ? restockProdId
    : products[0]?.id || '';

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (stockFilter === 'low' && p.availableQuantity > p.reorderLevel) return false;
      if (search.trim()) {
        const q = search.toLowerCase();
        return (
          p.name.toLowerCase().includes(q) ||
          p.productCode.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [products, search, stockFilter]);

  const bestSellingChart = useMemo(
    () =>
      [...products]
        .sort((a, b) => b.unitsSold - a.unitsSold)
        .slice(0, 5)
        .map((p) => ({ name: p.productCode, units: p.unitsSold, revenue: p.unitsSold * p.sellingPrice })),
    [products]
  );

  const forecastData = useMemo(() => {
    const baseRev = Math.max(500, sales.reduce((s, x) => s + x.totalAmount, 0));
    const avgMargin =
      products.length > 0
        ? products.reduce((s, p) => s + (p.sellingPrice > 0 ? (p.sellingPrice - p.purchaseCost) / p.sellingPrice : 0.3), 0) /
          products.length
        : 0.35;
    const rows = [];
    const now = new Date();
    for (let i = 1; i <= 4; i += 1) {
      const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
      const projectedRevenue = Math.round(baseRev * Math.pow(1.06, i));
      const projectedProfit = Math.round(projectedRevenue * avgMargin);
      rows.push({
        month: d.toISOString().slice(0, 7),
        projectedRevenue,
        projectedProfit,
      });
    }
    return rows;
  }, [products, sales]);

  const productExpenses = businessExpenses.filter((e) => e.domain === 'product');
  const lowStockCount = products.filter((p) => p.availableQuantity <= p.reorderLevel).length;

  return (
    <div className="space-y-6">
      <DomainBrand3D
        domain="product-business"
        workspaceName={activeWorkspace?.name}
        reducedMotion={settings.reducedMotion}
        rightSlot={
          <button
            type="button"
            onClick={() => setShowAddProd((s) => !s)}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl whitespace-nowrap ${domainTheme.buttonBgClass}`}
          >
            <Plus className="w-4 h-4" />
            <span>{t('business:product.addProduct')}</span>
          </button>
        }
      />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard label={t('business:product.salesRevenueKpi')} value={formatCurrency(metrics.productRevenue, cur)} tone="positive" />
        <StatCard
          label={t('business:product.netProfitKpi')}
          value={formatCurrency(metrics.productNetProfit, cur)}
          tone={metrics.productNetProfit >= 0 ? 'positive' : 'negative'}
        />
        <StatCard
          label={t('business:product.inventoryValue')}
          value={formatCurrency(metrics.inventoryValuationAtCost, cur)}
        />
        <StatCard
          label={t('business:product.lowStockAlert')}
          value={String(lowStockCount)}
          helperText={t('business:product.lowStockHelper')}
          tone={lowStockCount > 0 ? 'warning' : 'positive'}
        />
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#172235] border border-slate-200 dark:border-slate-800 overflow-x-auto">
        {(
          [
            { id: 'inventory', label: t('business:product.tabInventory'), icon: ShoppingBag },
            { id: 'suppliers', label: t('business:product.tabSuppliers', { count: suppliers.length }), icon: Truck },
            { id: 'customers', label: t('business:product.tabCustomers', { count: customers.length }), icon: Users },
            { id: 'forecast', label: t('business:product.tabForecast'), icon: TrendingUp },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-white dark:bg-[#1E293B] text-orange-700 dark:text-orange-300 shadow-xs'
                  : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5 text-orange-600 dark:text-orange-400" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Add Product Panel */}
      {showAddProd && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!pName.trim() || !pCode.trim() || Number(pPrice) <= 0) return;
            addProduct({
              productCode: pCode.trim().toUpperCase(),
              name: pName.trim(),
              category: pCategory,
              purchaseCost: Number(pCost) || 0,
              sellingPrice: Number(pPrice),
              availableQuantity: Number(pQty) || 0,
              reorderLevel: Number(pReorder) || 10,
            });
            clearDraft(DRAFT_KEY);
            setPCode('');
            setPName('');
            setPCost('');
            setPPrice('');
            setPQty('');
            setShowAddProd(false);
          }}
          className="rounded-xl border border-orange-300/60 dark:border-orange-500/35 bg-white dark:bg-[#1E293B] p-5 space-y-3"
        >
          <div className="flex items-center justify-between text-xs">
            <span className="font-display font-semibold">{t('business:product.addSkuTitle')}</span>
            {(pCode || pName) && (
              <button
                type="button"
                onClick={() => {
                  clearDraft(DRAFT_KEY);
                  setPCode('');
                  setPName('');
                  setPCost('');
                  setPPrice('');
                  setPQty('');
                }}
                className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-orange-600"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{t('business:product.clearDraft')}</span>
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-3 items-end">
            <div>
              <label className="block text-xs text-slate-500 mb-1">{t('business:product.skuCode')}</label>
              <input
                type="text"
                value={pCode}
                onChange={(e) => setPCode(e.target.value)}
                placeholder="FX-NEW-101"
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                required
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs text-slate-500 mb-1">{t('business:product.productName')}</label>
              <input
                type="text"
                value={pName}
                onChange={(e) => setPName(e.target.value)}
                placeholder="Desk Aluminum Stand"
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                required
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">{t('business:product.purchaseCost')}</label>
              <input
                type="number"
                value={pCost}
                onChange={(e) => setPCost(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
                required
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">{t('business:product.sellingPrice')}</label>
              <input
                type="number"
                value={pPrice}
                onChange={(e) => setPPrice(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
                required
              />
            </div>
            <div className="flex gap-2">
              <div className="flex-1">
                <label className="block text-xs text-slate-500 mb-1">{t('business:product.qtyShort')}</label>
                <input
                  type="number"
                  value={pQty}
                  onChange={(e) => setPQty(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
                  required
                />
              </div>
              <button
                type="submit"
                className={`self-end px-4 py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}
              >
                {t('common:actions.save')}
              </button>
            </div>
          </div>
        </form>
      )}

      {activeTab === 'inventory' && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSaleError(null);
                const res = recordSale({
                  productId: effectiveSaleProdId,
                  quantity: Number(saleQty),
                  customerName: saleCustomer,
                });
                if (!res.ok) setSaleError(res.error || t('business:product.saleErrorDefault'));
                else {
                  setSaleQty('1');
                  setSaleCustomer('');
                }
              }}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3"
            >
              <div className="flex items-center gap-2 font-display font-semibold text-sm">
                <ShoppingBag className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                <span>{t('business:product.recordSale')}</span>
              </div>
              {saleError && (
                <p className="text-xs text-red-600 dark:text-[#F87171]">{saleError}</p>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <select
                  value={effectiveSaleProdId}
                  onChange={(e) => setSaleProdId(e.target.value)}
                  className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.availableQuantity} {t('business:product.leftSuffix')})
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  min={1}
                  value={saleQty}
                  onChange={(e) => setSaleQty(e.target.value)}
                  placeholder={t('business:product.qtyShort')}
                  className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
                />
                <input
                  type="text"
                  value={saleCustomer}
                  onChange={(e) => setSaleCustomer(e.target.value)}
                  placeholder={t('business:product.customerName')}
                  className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                />
              </div>
              <button
                type="submit"
                className={`px-4 py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}
              >
                {t('business:product.recordSale')}
              </button>
            </form>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                restockProduct({
                  productId: effectiveRestockProdId,
                  quantity: Number(restockQty),
                  supplier: restockSupplier,
                });
                setRestockQty('10');
                setRestockSupplier('');
              }}
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3"
            >
              <div className="flex items-center gap-2 font-display font-semibold text-sm">
                <PackagePlus className="w-4 h-4 text-blue-700 dark:text-blue-400" />
                <span>{t('business:product.updateStock')}</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <select
                  value={effectiveRestockProdId}
                  onChange={(e) => setRestockProdId(e.target.value)}
                  className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  min={1}
                  value={restockQty}
                  onChange={(e) => setRestockQty(e.target.value)}
                  placeholder={t('business:product.qtyShort')}
                  className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
                />
                <input
                  type="text"
                  value={restockSupplier}
                  onChange={(e) => setRestockSupplier(e.target.value)}
                  placeholder={t('business:product.supplierName')}
                  className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                />
              </div>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:border-orange-500"
              >
                {t('business:product.addStockButton')}
              </button>
            </form>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3">
              <div className="relative flex-1 min-w-[180px] max-w-sm">
                <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={t('business:product.searchPlaceholder')}
                  className="w-full ps-9 pe-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                />
              </div>
              <div className="inline-flex p-1 rounded-lg bg-slate-100 dark:bg-[#172235]">
                <button
                  type="button"
                  onClick={() => setStockFilter('all')}
                  className={`px-3 py-1 text-xs rounded-md ${
                    stockFilter === 'all' ? 'bg-white dark:bg-[#1E293B] font-medium shadow-xs' : 'text-slate-500'
                  }`}
                >
                  {t('business:product.allSkus', { count: products.length })}
                </button>
                <button
                  type="button"
                  onClick={() => setStockFilter('low')}
                  className={`px-3 py-1 text-xs rounded-md ${
                    stockFilter === 'low' ? 'bg-white dark:bg-[#1E293B] font-medium shadow-xs' : 'text-slate-500'
                  }`}
                >
                  {t('business:product.lowStockFilter', { count: lowStockCount })}
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead className="bg-slate-50 dark:bg-[#172235] text-slate-500 dark:text-[#94A3B8] border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="text-start px-4 py-3 font-medium">{t('business:product.skuCode')}</th>
                    <th className="text-start px-4 py-3 font-medium">{t('business:product.productName')}</th>
                    <th className="text-end px-4 py-3 font-medium">{t('business:product.purchaseCost')}</th>
                    <th className="text-end px-4 py-3 font-medium">{t('business:product.sellingPrice')}</th>
                    <th className="text-end px-4 py-3 font-medium">{t('business:product.margin')}</th>
                    <th className="text-end px-4 py-3 font-medium">{t('business:product.availableQty')}</th>
                    <th className="text-end px-4 py-3 font-medium">{t('business:product.unitsSold')}</th>
                    <th className="text-end px-4 py-3 font-medium">{t('common:actions.delete')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredProducts.map((p) => {
                    const marginPct =
                      p.sellingPrice > 0
                        ? Math.round(((p.sellingPrice - p.purchaseCost) / p.sellingPrice) * 100)
                        : 0;
                    const isLow = p.availableQuantity <= p.reorderLevel;
                    return (
                      <tr key={p.id}>
                        <td className="px-4 py-3 font-mono-nums text-slate-500">{p.productCode}</td>
                        <td className="px-4 py-3">
                          <div className="font-medium">{p.name}</div>
                          <div className="text-[11px] text-slate-500">{p.category}</div>
                        </td>
                        <td className="px-4 py-3 text-end font-mono-nums">{formatCurrency(p.purchaseCost, cur)}</td>
                        <td className="px-4 py-3 text-end font-mono-nums">{formatCurrency(p.sellingPrice, cur)}</td>
                        <td className="px-4 py-3 text-end font-mono-nums text-emerald-600 dark:text-[#34D399]">
                          {marginPct}%
                        </td>
                        <td className="px-4 py-3 text-end font-mono-nums">
                          <span className={isLow ? 'text-amber-600 dark:text-[#FBBF24] font-semibold' : ''}>
                            {p.availableQuantity}{' '}
                            {isLow ? `(${t('business:product.reorderAt', { level: p.reorderLevel })})` : ''}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-end font-mono-nums">{p.unitsSold}</td>
                        <td className="px-4 py-3 text-end">
                          <button
                            type="button"
                            onClick={() => setDeleteProdId(p.id)}
                            aria-label={t('common:actions.delete')}
                            className="p-1.5 text-slate-400 hover:text-red-600 dark:hover:text-[#F87171]"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5">
              <h3 className="font-display font-semibold text-sm mb-4">{t('business:product.bestSellingTitle')}</h3>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={bestSellingChart}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                    <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#172235',
                        borderColor: '#334155',
                        borderRadius: 8,
                        color: '#F8FAFC',
                        fontSize: 12,
                      }}
                    />
                    <Bar dataKey="units" fill="#EA580C" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-4">
              <h3 className="font-display font-semibold text-sm">{t('business:product.recentActivityTitle')}</h3>
              <div className="space-y-2 max-h-36 overflow-y-auto">
                {sales.slice(0, 4).map((s) => (
                  <div key={s.id} className="flex items-center justify-between gap-2 text-xs py-1 border-b border-slate-100 dark:border-slate-800">
                    <span className="truncate">
                      {s.productName} × {s.quantity} · {s.customerName} ({formatDateShort(s.date)})
                    </span>
                    <span className="font-mono-nums font-semibold text-emerald-600 dark:text-[#34D399] shrink-0">
                      +{formatCurrency(s.totalAmount, cur)}
                    </span>
                  </div>
                ))}
                {purchases.slice(0, 2).map((pur) => (
                  <div key={pur.id} className="flex items-center justify-between gap-2 text-xs py-1 border-b border-slate-100 dark:border-slate-800 text-slate-500">
                    <span className="truncate">
                      {t('business:product.restockPrefix')}: {pur.productName} × {pur.quantity} ({pur.supplier})
                    </span>
                    <span className="font-mono-nums shrink-0">-{formatCurrency(pur.totalCost, cur)}</span>
                  </div>
                ))}
                {productExpenses.map((e) => (
                  <div key={e.id} className="flex items-center justify-between gap-2 text-xs py-1 border-b border-slate-100 dark:border-slate-800 text-slate-500">
                    <span className="truncate">
                      {t('business:product.opExPrefix')}: {e.description}
                    </span>
                    <span className="font-mono-nums shrink-0">-{formatCurrency(e.amount, cur)}</span>
                  </div>
                ))}
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!expDesc.trim() || Number(expAmt) <= 0) return;
                  addBusinessExpense({
                    domain: 'product',
                    category: 'Operations',
                    description: expDesc.trim(),
                    amount: Number(expAmt),
                    date: new Date().toISOString().slice(0, 10),
                  });
                  setExpDesc('');
                  setExpAmt('');
                }}
                className="flex flex-wrap gap-2 pt-1"
              >
                <input
                  type="text"
                  value={expDesc}
                  onChange={(e) => setExpDesc(e.target.value)}
                  placeholder={t('business:product.logOpExPlaceholder')}
                  className="flex-1 min-w-[160px] px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                />
                <input
                  type="number"
                  value={expAmt}
                  onChange={(e) => setExpAmt(e.target.value)}
                  placeholder={t('finance:form.amount', { defaultValue: 'Amount' })}
                  className="w-24 px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
                />
                <button
                  type="submit"
                  className="px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:border-orange-500"
                >
                  {t('common:actions.add')}
                </button>
              </form>
            </div>
          </div>
        </>
      )}

      {activeTab === 'suppliers' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 dark:bg-[#172235] text-slate-500 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="text-start px-4 py-3">{t('business:product.supplierName')}</th>
                  <th className="text-start px-4 py-3">{t('business:product.category')}</th>
                  <th className="text-start px-4 py-3">{t('business:product.contact')}</th>
                  <th className="text-end px-4 py-3">{t('business:product.leadTime')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {suppliers.length === 0 ? (
                  <tr>
                    <td colSpan={4} className="px-4 py-8 text-center text-slate-500">
                      {t('business:product.noSuppliers')}
                    </td>
                  </tr>
                ) : (
                  suppliers.map((sup) => (
                    <tr key={sup.id}>
                      <td className="px-4 py-3 font-semibold">{sup.name}</td>
                      <td className="px-4 py-3 text-slate-500">{sup.category}</td>
                      <td className="px-4 py-3 text-slate-500">{sup.contact}</td>
                      <td className="px-4 py-3 text-end font-mono-nums">
                        {t('business:product.leadDays', { days: sup.leadTimeDays })}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!supName.trim()) return;
              addSupplier({
                name: supName.trim(),
                contact: supContact.trim() || 'supply@vendor.example',
                category: supCat.trim() || 'General',
                leadTimeDays: Math.max(1, Number(supLead) || 7),
              });
              setSupName('');
              setSupContact('');
            }}
            className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3"
          >
            <h3 className="font-display font-semibold text-sm">{t('business:product.addVendorTitle')}</h3>
            <input
              type="text"
              value={supName}
              onChange={(e) => setSupName(e.target.value)}
              placeholder={t('business:product.supplierName')}
              required
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            />
            <input
              type="text"
              value={supContact}
              onChange={(e) => setSupContact(e.target.value)}
              placeholder={t('business:product.contactPlaceholder')}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                value={supCat}
                onChange={(e) => setSupCat(e.target.value)}
                placeholder={t('business:product.category')}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
              <input
                type="number"
                min={1}
                value={supLead}
                onChange={(e) => setSupLead(e.target.value)}
                placeholder={t('business:product.leadDaysPlaceholder')}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
              />
            </div>
            <button type="submit" className={`w-full py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}>
              {t('business:product.saveSupplier')}
            </button>
          </form>
        </div>
      )}

      {activeTab === 'customers' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 dark:bg-[#172235] text-slate-500 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="text-start px-4 py-3">{t('business:product.customerName')}</th>
                  <th className="text-start px-4 py-3">{t('business:product.contact')}</th>
                  <th className="text-end px-4 py-3">{t('business:product.orders')}</th>
                  <th className="text-end px-4 py-3">{t('business:product.totalSpent')}</th>
                  <th className="text-start px-4 py-3">{t('business:product.lastOrder')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {customers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-8 text-center text-slate-500">
                      {t('business:product.noCustomers')}
                    </td>
                  </tr>
                ) : (
                  customers.map((c) => (
                    <tr key={c.id}>
                      <td className="px-4 py-3 font-semibold">{c.name}</td>
                      <td className="px-4 py-3 text-slate-500">{c.contact}</td>
                      <td className="px-4 py-3 text-end font-mono-nums">{c.totalOrders}</td>
                      <td className="px-4 py-3 text-end font-mono-nums font-semibold text-emerald-600 dark:text-[#34D399]">
                        {formatCurrency(c.totalSpent, cur)}
                      </td>
                      <td className="px-4 py-3 font-mono-nums text-slate-500">{formatDateShort(c.lastOrderDate)}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!custName.trim()) return;
              addCustomer({
                name: custName.trim(),
                contact: custContact.trim() || 'buyer@customer.example',
                totalOrders: 0,
                totalSpent: 0,
                lastOrderDate: new Date().toISOString().slice(0, 10),
              });
              setCustName('');
              setCustContact('');
            }}
            className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3"
          >
            <h3 className="font-display font-semibold text-sm">{t('business:product.addCustomer')}</h3>
            <input
              type="text"
              value={custName}
              onChange={(e) => setCustName(e.target.value)}
              placeholder={t('business:product.customerPlaceholder')}
              required
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            />
            <input
              type="text"
              value={custContact}
              onChange={(e) => setCustContact(e.target.value)}
              placeholder={t('business:product.contactPlaceholder')}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            />
            <button type="submit" className={`w-full py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}>
              {t('business:product.saveCustomer')}
            </button>
          </form>
        </div>
      )}

      {activeTab === 'forecast' && (
        <div className="space-y-6">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5">
            <h3 className="font-display font-semibold text-sm mb-1">
              {t('business:product.forecastTitle')}
            </h3>
            <p className="text-xs text-slate-500 dark:text-[#94A3B8] mb-4">
              {t('business:product.forecastSubtitle')}
            </p>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={forecastData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#172235',
                      borderColor: '#334155',
                      borderRadius: 8,
                      color: '#F8FAFC',
                      fontSize: 12,
                    }}
                  />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="projectedRevenue"
                    name={t('business:product.projectedRevenue')}
                    stroke="#EA580C"
                    fill="#EA580C"
                    fillOpacity={0.2}
                  />
                  <Area
                    type="monotone"
                    dataKey="projectedProfit"
                    name={t('business:product.projectedMargin')}
                    stroke="#1E3A8A"
                    fill="#1E3A8A"
                    fillOpacity={0.18}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(deleteProdId)}
        title={t('business:product.deleteTitle')}
        message={t('business:product.deleteConfirm')}
        onCancel={() => setDeleteProdId(null)}
        onConfirm={() => {
          if (deleteProdId) deleteProduct(deleteProdId);
          setDeleteProdId(null);
        }}
      />
    </div>
  );
};
