import React, { useMemo, useState } from 'react';
import { BookOpen, Search } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { LEARNING_ARTICLES } from '../data/mockRepository';

export const LearningCenterPage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState(LEARNING_ARTICLES[0].id);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return LEARNING_ARTICLES;
    return LEARNING_ARTICLES.filter(
      (a) =>
        a.topic.toLowerCase().includes(q) ||
        a.category.toLowerCase().includes(q) ||
        a.summary.toLowerCase().includes(q)
    );
  }, [search]);

  const activeArticle =
    filtered.find((a) => a.id === selectedId) || filtered[0] || null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display font-bold text-2xl">{t('common:nav.learning')}</h2>
          <p className="text-sm text-slate-600 dark:text-[#94A3B8] mt-1">
            {t('business:extraPages.learningSubtitle')}
          </p>
        </div>
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t('business:extraPages.learningSearch')}
            className="w-full ps-9 pe-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B]"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 space-y-2 max-h-[600px] overflow-y-auto">
          {filtered.map((art) => (
            <button
              key={art.id}
              type="button"
              onClick={() => setSelectedId(art.id)}
              className={`w-full p-4 rounded-xl border text-start transition-colors ${
                activeArticle?.id === art.id
                  ? 'border-teal-500 bg-teal-500/5 dark:bg-[#1E293B]'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className="text-[11px] text-teal-600 dark:text-[#14B8A6] font-medium">
                {art.category} · {art.level} · {art.readTime}
              </div>
              <div className="font-display font-semibold text-sm mt-1">{art.topic}</div>
            </button>
          ))}
        </div>

        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6">
          {activeArticle ? (
            <article className="space-y-5">
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-[#94A3B8]">
                <BookOpen className="w-4 h-4 text-teal-600 dark:text-[#14B8A6]" />
                <span>
                  {activeArticle.category} · {activeArticle.level} · {activeArticle.readTime}
                </span>
              </div>
              <h3 className="font-display font-bold text-2xl">{activeArticle.topic}</h3>
              <p className="text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                {activeArticle.summary}
              </p>
              <div className="space-y-4 pt-2">
                {activeArticle.sections.map((sec, idx) => (
                  <div key={idx} className="space-y-1.5">
                    <h4 className="font-display font-semibold text-base">{sec.heading}</h4>
                    <p className="text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                      {sec.body}
                    </p>
                  </div>
                ))}
              </div>
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-[#172235] border border-slate-200 dark:border-slate-800 text-xs">
                <span className="font-semibold text-teal-600 dark:text-[#14B8A6]">
                  {t('business:extraPages.learningTakeaway')}:{' '}
                </span>
                <span>{activeArticle.keyTakeaway}</span>
              </div>
            </article>
          ) : (
            <div className="py-12 text-center text-xs text-slate-500">
              {t('business:extraPages.learningNoMatch')}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
