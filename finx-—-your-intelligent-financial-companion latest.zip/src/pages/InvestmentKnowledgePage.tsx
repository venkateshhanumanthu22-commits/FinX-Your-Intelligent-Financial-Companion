import React, { useMemo, useState } from 'react';
import { AlertCircle, Calculator, GraduationCap, LineChart as LineIcon, PieChart as PieIcon } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import {
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { DomainBrand3D } from '../components/DomainBrand3D';
import { DOMAIN_THEMES } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import { DEMO_HISTORICAL_MARKET_DATA, INVESTMENT_TOPICS } from '../data/mockRepository';
import { formatCurrency } from '../utils/formatters';

const ALLOCATION_COLORS = ['#059669', '#D97706', '#0284C7', '#14B8A6'];

export const InvestmentKnowledgePage: React.FC = () => {
  const { t } = useTranslation('business');
  const { paperTrades, addPaperTrade, languagePrefs, settings } = useFinX();
  const domainTheme = DOMAIN_THEMES['investment-knowledge'];
  const cur = languagePrefs.displayCurrency;

  const [selectedTopicId, setSelectedTopicId] = useState(INVESTMENT_TOPICS[0].id);

  // Educational Compound Growth Calculator
  const [monthlyContribution, setMonthlyContribution] = useState(500);
  const [years, setYears] = useState(10);
  const [assumedAnnualRate, setAssumedAnnualRate] = useState(7);

  // Paper Trade Form
  const [simAsset, setSimAsset] = useState<'SIM-IDX500' | 'SIM-BOND10' | 'SIM-BAL60'>('SIM-IDX500');
  const [simShares, setSimShares] = useState('5');

  const sipProjection = useMemo(() => {
    const r = assumedAnnualRate / 100 / 12;
    const n = years * 12;
    const invested = monthlyContribution * n;
    const fv =
      r > 0
        ? monthlyContribution * ((Math.pow(1 + r, n) - 1) / r) * (1 + r)
        : invested;
    return { invested, projectedValue: Math.round(fv), growth: Math.round(fv - invested) };
  }, [assumedAnnualRate, monthlyContribution, years]);

  const allocationData = useMemo(() => {
    const totals: Record<string, number> = {};
    paperTrades.forEach((pt) => {
      const val = pt.shares * pt.historicalReferencePrice;
      totals[pt.assetClass] = (totals[pt.assetClass] || 0) + val;
    });
    const grandTotal = Object.values(totals).reduce((s, v) => s + v, 0);
    return Object.entries(totals).map(([name, value]) => ({
      name,
      value,
      percent: grandTotal > 0 ? Math.round((value / grandTotal) * 100) : 0,
    }));
  }, [paperTrades]);

  const activeTopic = INVESTMENT_TOPICS.find((tItem) => tItem.id === selectedTopicId) || INVESTMENT_TOPICS[0];

  const simAssetsCatalog = {
    'SIM-IDX500': { name: t('investment.simAssets.idx'), assetClass: 'Index Fund' as const, price: 446 },
    'SIM-BOND10': { name: t('investment.simAssets.bond'), assetClass: 'Bond ETF' as const, price: 101 },
    'SIM-BAL60': { name: t('investment.simAssets.bal'), assetClass: 'Equity' as const, price: 218 },
  };

  return (
    <div className="space-y-6">
      <DomainBrand3D
        domain="investment-knowledge"
        workspaceName={t('investment.academyTitle')}
        reducedMotion={settings.reducedMotion}
      />

      {/* Mandatory Educational Disclaimer */}
      <div className="p-4 rounded-xl border border-amber-400/40 bg-amber-500/5 flex items-start gap-3 text-xs text-amber-800 dark:text-amber-200">
        <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
        <span>{t('investment.disclaimer')}</span>
      </div>

      {/* Learning Modules */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 space-y-2">
          {INVESTMENT_TOPICS.map((topic) => (
            <button
              key={topic.id}
              type="button"
              onClick={() => setSelectedTopicId(topic.id)}
              className={`w-full p-4 rounded-xl border text-start transition-colors ${
                topic.id === activeTopic.id
                  ? 'border-emerald-500 bg-emerald-500/5 dark:bg-[#1E293B]'
                  : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] hover:border-slate-300 dark:hover:border-slate-700'
              }`}
            >
              <div className={`text-[11px] font-medium ${domainTheme.accentTextClass}`}>
                {topic.category} · {t('investment.riskFocus')}: {topic.riskLevel}
              </div>
              <div className="font-display font-semibold text-sm mt-1">{topic.title}</div>
            </button>
          ))}
        </div>

        <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6 space-y-4">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-[#94A3B8]">
            <GraduationCap className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{activeTopic.category}</span>
          </div>
          <h3 className="font-display font-bold text-xl">{activeTopic.title}</h3>
          <p className="text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
            {activeTopic.summary}
          </p>
          <ul className="space-y-2 pt-2">
            {activeTopic.keyPoints.map((pt, i) => (
              <li key={i} className="text-sm text-slate-700 dark:text-[#F8FAFC] flex items-start gap-2.5">
                <span className="font-mono-nums text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-0.5">
                  0{i + 1}.
                </span>
                <span>{pt}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Historical Indexed Comparison + Educational Calculator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5">
          <div className="flex items-center justify-between gap-2 mb-4">
            <h3 className="font-display font-semibold text-sm flex items-center gap-2">
              <LineIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>{t('investment.histTitle')}</span>
            </h3>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={DEMO_HISTORICAL_MARKET_DATA}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                <XAxis dataKey="period" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#172235',
                    borderColor: '#334155',
                    borderRadius: 8,
                    color: '#F8FAFC',
                    fontSize: 12,
                  }}
                />
                <Legend />
                <Line type="monotone" dataKey="equityIndex" name={t('investment.equityHist')} stroke="#059669" strokeWidth={2} />
                <Line type="monotone" dataKey="balancedFund" name={t('investment.balancedHist')} stroke="#D97706" strokeWidth={2} />
                <Line type="monotone" dataKey="govtBondIndex" name={t('investment.bondHist')} stroke="#0284C7" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-4">
          <h3 className="font-display font-semibold text-sm flex items-center gap-2">
            <Calculator className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            <span>{t('investment.calcTitle')}</span>
          </h3>

          <div className="space-y-3 text-xs">
            <label className="block">
              <div className="flex justify-between mb-1">
                <span>{t('investment.monthlyContrib')}</span>
                <span className="font-mono-nums font-semibold">{formatCurrency(monthlyContribution, cur)}</span>
              </div>
              <input
                type="range"
                min={50}
                max={3000}
                step={50}
                value={monthlyContribution}
                onChange={(e) => setMonthlyContribution(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </label>

            <label className="block">
              <div className="flex justify-between mb-1">
                <span>{t('investment.timeHorizon')}</span>
                <span className="font-mono-nums font-semibold">{t('investment.yearsCount', { count: years })}</span>
              </div>
              <input
                type="range"
                min={1}
                max={30}
                value={years}
                onChange={(e) => setYears(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </label>

            <label className="block">
              <div className="flex justify-between mb-1">
                <span>{t('investment.annualRate')}</span>
                <span className="font-mono-nums font-semibold">{assumedAnnualRate}%</span>
              </div>
              <input
                type="range"
                min={2}
                max={12}
                step={0.5}
                value={assumedAnnualRate}
                onChange={(e) => setAssumedAnnualRate(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </label>
          </div>

          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-1.5 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-500">{t('investment.totalPrincipal')}</span>
              <span className="font-mono-nums font-semibold">{formatCurrency(sipProjection.invested, cur)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">{t('investment.compoundedValue')}</span>
              <span className="font-mono-nums font-bold text-emerald-600 dark:text-emerald-400">
                {formatCurrency(sipProjection.projectedValue, cur)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Simulated Portfolio Allocation Breakdown + Paper Trading Sandbox */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3">
          <h3 className="font-display font-semibold text-sm flex items-center gap-2">
            <PieIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{t('investment.allocTitle')}</span>
          </h3>
          {allocationData.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-[#94A3B8] py-8 text-center">
              {t('investment.allocEmpty')}
            </p>
          ) : (
            <>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={allocationData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={45}
                      outerRadius={72}
                      paddingAngle={3}
                    >
                      {allocationData.map((_, idx) => (
                        <Cell key={idx} fill={ALLOCATION_COLORS[idx % ALLOCATION_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#172235',
                        borderColor: '#334155',
                        borderRadius: 8,
                        color: '#F8FAFC',
                        fontSize: 12,
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="space-y-1.5">
                {allocationData.map((row, idx) => (
                  <div key={row.name} className="flex items-center justify-between text-xs">
                    <span className="inline-flex items-center gap-2">
                      <span
                        className="w-2.5 h-2.5 rounded-xs"
                        style={{ backgroundColor: ALLOCATION_COLORS[idx % ALLOCATION_COLORS.length] }}
                      />
                      <span>{row.name}</span>
                    </span>
                    <span className="font-mono-nums font-semibold">
                      {row.percent}% · {formatCurrency(row.value, cur)}
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>

        <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-display font-semibold text-sm">
                {t('investment.paperTitle')}
              </h3>
              <p className="text-xs text-slate-500 dark:text-[#94A3B8]">
                {t('investment.paperSubtitle')}
              </p>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                const qty = Number(simShares);
                if (qty <= 0) return;
                const info = simAssetsCatalog[simAsset];
                addPaperTrade({
                  symbol: simAsset,
                  name: info.name,
                  assetClass: info.assetClass,
                  shares: qty,
                  simulatedEntryPrice: info.price,
                  historicalReferencePrice: Math.round(info.price * 1.03),
                  purchaseDate: new Date().toISOString().slice(0, 10),
                });
              }}
              className="flex flex-wrap items-center gap-2"
            >
              <select
                value={simAsset}
                onChange={(e) => setSimAsset(e.target.value as 'SIM-IDX500' | 'SIM-BOND10' | 'SIM-BAL60')}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] max-w-full"
              >
                <option value="SIM-IDX500">
                  SIM-IDX500 ({formatCurrency(simAssetsCatalog['SIM-IDX500'].price, cur)} {t('investment.histRefSuffix')})
                </option>
                <option value="SIM-BOND10">
                  SIM-BOND10 ({formatCurrency(simAssetsCatalog['SIM-BOND10'].price, cur)} {t('investment.histRefSuffix')})
                </option>
                <option value="SIM-BAL60">
                  SIM-BAL60 ({formatCurrency(simAssetsCatalog['SIM-BAL60'].price, cur)} {t('investment.histRefSuffix')})
                </option>
              </select>
              <input
                type="number"
                min={1}
                value={simShares}
                onChange={(e) => setSimShares(e.target.value)}
                className="w-20 px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
              />
              <button
                type="submit"
                className={`px-4 py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}
              >
                {t('investment.simulateAllocation')}
              </button>
            </form>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 dark:bg-[#172235] text-slate-500 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="text-start px-3 py-2.5">{t('investment.simSymbol')}</th>
                  <th className="text-start px-3 py-2.5">{t('investment.assetClass')}</th>
                  <th className="text-end px-3 py-2.5">{t('investment.simShares')}</th>
                  <th className="text-end px-3 py-2.5">{t('investment.entryRef')}</th>
                  <th className="text-end px-3 py-2.5">{t('investment.histRef')}</th>
                  <th className="text-end px-3 py-2.5">{t('investment.simValue')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {paperTrades.map((pt) => (
                  <tr key={pt.id}>
                    <td className="px-3 py-2.5 font-medium">
                      {pt.symbol} · {pt.name}
                    </td>
                    <td className="px-3 py-2.5 text-slate-500">{pt.assetClass}</td>
                    <td className="px-3 py-2.5 text-end font-mono-nums">{pt.shares}</td>
                    <td className="px-3 py-2.5 text-end font-mono-nums">{formatCurrency(pt.simulatedEntryPrice, cur)}</td>
                    <td className="px-3 py-2.5 text-end font-mono-nums">{formatCurrency(pt.historicalReferencePrice, cur)}</td>
                    <td className="px-3 py-2.5 text-end font-mono-nums font-semibold">
                      {formatCurrency(pt.shares * pt.historicalReferencePrice, cur)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
