import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Briefcase, Camera, CheckCircle2, Globe, Layers, Plus, Trash2, Volume2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { SearchableLanguageSelector } from '../components/SearchableLanguageSelector';
import { ThemeToggle } from '../components/ThemeToggle';
import { UserAvatar } from '../components/UserAvatar';
import { getLocalizedDomainTheme } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import { getAllSpeechVariants, getLanguageDef, SUPPORTED_LANGUAGES } from '../i18n/languages';
import {
  AVATAR_PRESETS,
  compressAvatarImageFile,
  getDefaultPresetForCategory,
} from '../services/avatarCatalog';
import { ALL_DOMAIN_IDS } from '../services/firestoreRepository';
import { NEURAL_VOICE_PERSONAS } from '../services/aiAssistantService';
import { getVoicesForLocale, inspectSpeechLanguageSupport } from '../services/voiceService';
import { AvatarCategory, DisplayCurrency, DomainId, NeuralVoiceName, UserProfile } from '../types/finx';

export const SettingsPage: React.FC = () => {
  const { t } = useTranslation(['common', 'assistant']);
  const {
    session,
    updateUserProfile,
    languagePrefs,
    updateLanguagePrefs,
    settings,
    updateSettings,
    workspaces,
    activeWorkspace,
    switchWorkspace,
    createWorkspace,
    toggleEnabledDomain,
  } = useFinX();

  const [name, setName] = useState(session?.user.name || '');
  const [businessName, setBusinessName] = useState(session?.user.businessName || '');
  const [role, setRole] = useState<UserProfile['role']>(
    session?.user.role || 'Individual & Entrepreneur'
  );
  const [avatarCategory, setAvatarCategory] = useState<AvatarCategory>(
    session?.user.avatarCategory || 'neutral'
  );
  const [avatarPresetId, setAvatarPresetId] = useState<string>(
    session?.user.avatarPresetId || 'neutral-compass'
  );
  const [customPhotoDataUrl, setCustomPhotoDataUrl] = useState<string | undefined>(
    session?.user.customPhotoDataUrl
  );

  const [newWsName, setNewWsName] = useState('');
  const [newWsDomain, setNewWsDomain] = useState<DomainId>('product-business');
  const [savedBanner, setSavedBanner] = useState<string | null>(null);
  const [voiceTick, setVoiceTick] = useState(0);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setName(session?.user.name || '');
    setBusinessName(session?.user.businessName || '');
    setRole(session?.user.role || 'Individual & Entrepreneur');
    setAvatarCategory(session?.user.avatarCategory || 'neutral');
    setAvatarPresetId(session?.user.avatarPresetId || 'neutral-compass');
    setCustomPhotoDataUrl(session?.user.customPhotoDataUrl);
  }, [
    session?.user.id,
    session?.user.name,
    session?.user.businessName,
    session?.user.role,
    session?.user.avatarCategory,
    session?.user.avatarPresetId,
    session?.user.customPhotoDataUrl,
  ]);

  useEffect(() => {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    const handler = () => setVoiceTick((v) => v + 1);
    window.speechSynthesis.addEventListener?.('voiceschanged', handler);
    return () => {
      window.speechSynthesis.removeEventListener?.('voiceschanged', handler);
    };
  }, []);

  const speechVariants = useMemo(() => getAllSpeechVariants(), []);
  const matchingVoices = useMemo(
    () => getVoicesForLocale(languagePrefs.voiceOutputLocale),
    [languagePrefs.voiceOutputLocale, voiceTick]
  );

  const speechSupport = useMemo(
    () =>
      inspectSpeechLanguageSupport(
        languagePrefs.voiceInputLocale,
        languagePrefs.voiceOutputLocale,
        languagePrefs.voiceOutputVoiceURI
      ),
    [
      languagePrefs.voiceInputLocale,
      languagePrefs.voiceOutputLocale,
      languagePrefs.voiceOutputVoiceURI,
      voiceTick,
    ]
  );

  const categoryPresets = useMemo(
    () => AVATAR_PRESETS.filter((p) => p.category === avatarCategory),
    [avatarCategory]
  );

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressAvatarImageFile(file);
      setCustomPhotoDataUrl(compressed);
    } catch {
      // ignore invalid image
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateUserProfile({
      name: name.trim() || session?.user.name,
      businessName: businessName.trim() || session?.user.businessName,
      role,
      avatarCategory,
      avatarPresetId,
      customPhotoDataUrl: customPhotoDataUrl || '',
    });
    setSavedBanner(t('common:states.savedSuccess'));
    setTimeout(() => setSavedBanner(null), 3000);
  };

  const handleAddWorkspace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWsName.trim()) return;
    await createWorkspace({
      name: newWsName.trim(),
      domain: newWsDomain,
      currency: languagePrefs.displayCurrency,
    });
    setNewWsName('');
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h2 className="font-display font-bold text-xl sm:text-2xl">{t('common:nav.settings')}</h2>
        <p className="text-sm text-slate-600 dark:text-[#94A3B8] mt-1">
          {t('common:settings.subtitle')}
        </p>
      </div>

      {savedBanner && (
        <div className="p-3 rounded-xl border border-emerald-400/40 bg-emerald-500/10 text-xs text-emerald-700 dark:text-[#34D399] flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{savedBanner}</span>
        </div>
      )}

      {/* Profile & Avatar Presentation Settings */}
      <form
        onSubmit={handleSaveProfile}
        className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-6 space-y-5"
      >
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4 min-w-0">
            <UserAvatar
              size="lg"
              category={avatarCategory}
              presetId={avatarPresetId}
              customPhotoDataUrl={customPhotoDataUrl}
              name={name}
            />
            <div className="min-w-0">
              <h3 className="font-display font-semibold text-base">
                {t('common:settings.profileAvatarTitle')}
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {t('common:avatars.helper')}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 hover:border-teal-500"
            >
              <Camera className="w-3.5 h-3.5" />
              <span>{t('common:avatars.uploadPhoto')}</span>
            </button>
            {customPhotoDataUrl && (
              <button
                type="button"
                onClick={() => setCustomPhotoDataUrl(undefined)}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs text-rose-500 rounded-lg border border-rose-500/30 hover:bg-rose-500/10"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>{t('common:avatars.removePhoto')}</span>
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <span className="block text-xs text-slate-500">{t('common:avatars.title')}</span>
            <div className="grid grid-cols-3 gap-2">
              {(['male', 'female', 'neutral'] as AvatarCategory[]).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => {
                    setAvatarCategory(cat);
                    setAvatarPresetId(getDefaultPresetForCategory(cat).id);
                  }}
                  className={`py-2 rounded-lg border text-xs font-medium ${
                    avatarCategory === cat
                      ? 'border-teal-500 bg-teal-500/10 text-teal-600 dark:text-[#22D3EE]'
                      : 'border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {cat === 'male'
                    ? t('common:avatars.male')
                    : cat === 'female'
                      ? t('common:avatars.female')
                      : t('common:avatars.neutral')}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <span className="block text-xs text-slate-500">{t('common:settings.avatarPresetLabel')}</span>
            <div className="flex flex-wrap items-center gap-2.5">
              {categoryPresets.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => {
                    setAvatarPresetId(preset.id);
                    setCustomPhotoDataUrl(undefined);
                  }}
                  title={preset.label}
                  className={`p-1 rounded-xl border ${
                    !customPhotoDataUrl && avatarPresetId === preset.id
                      ? 'border-teal-500 ring-2 ring-teal-500/30'
                      : 'border-slate-200 dark:border-slate-700 opacity-75 hover:opacity-100'
                  }`}
                >
                  <UserAvatar size="sm" category={preset.category} presetId={preset.id} />
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {t('common:settings.displayNameLabel')}
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {t('common:settings.activeBusinessLabel')}
            </label>
            <input
              type="text"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            />
          </div>
          <div>
            <label className="block text-xs text-slate-500 mb-1">
              {t('common:settings.roleLabel')}
            </label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as UserProfile['role'])}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              <option value="Individual & Entrepreneur">{t('common:roles.dual')}</option>
              <option value="Product Business Owner">{t('common:roles.productOwner')}</option>
              <option value="Consultant">{t('common:roles.consultant')}</option>
              <option value="Individual">{t('common:roles.individual')}</option>
            </select>
          </div>
        </div>
        <button
          type="submit"
          className="px-4 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950"
        >
          {t('common:actions.save')}
        </button>
      </form>

      {/* Active Domains & Multi-Business Workspaces */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-teal-600 dark:text-[#14B8A6]" />
            <h3 className="font-display font-semibold text-base">
              {t('common:workspaces.enabledDomainsTitle')}
            </h3>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t('common:workspaces.enabledDomainsDesc')}
          </p>
          <div className="space-y-2">
            {ALL_DOMAIN_IDS.map((id) => {
              const theme = getLocalizedDomainTheme(id);
              const active = session?.user.enabledDomains.includes(id) ?? true;
              return (
                <label
                  key={id}
                  className="flex items-center justify-between gap-3 p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-[#172235] cursor-pointer"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                      {theme.label}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      {theme.tagline}
                    </div>
                  </div>
                  <input
                    type="checkbox"
                    checked={active}
                    onChange={() => toggleEnabledDomain(id)}
                    className="rounded text-teal-600 shrink-0"
                  />
                </label>
              );
            })}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-teal-600 dark:text-[#14B8A6]" />
            <h3 className="font-display font-semibold text-base">
              {t('common:workspaces.multiBusinessTitle')}
            </h3>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {t('common:workspaces.multiBusinessDesc')}
          </p>

          <div className="space-y-2 max-h-48 overflow-y-auto">
            {workspaces.map((ws) => {
              const isCurrent = ws.id === activeWorkspace?.id;
              return (
                <div
                  key={ws.id}
                  className={`flex items-center justify-between gap-2 px-3 py-2.5 rounded-lg border text-xs ${
                    isCurrent
                      ? 'border-teal-500 bg-teal-500/10'
                      : 'border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-[#172235]'
                  }`}
                >
                  <div className="min-w-0">
                    <p className="font-semibold truncate">{ws.name}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400">
                      {getLocalizedDomainTheme(ws.domain).label} · {ws.currency}
                    </p>
                  </div>
                  {isCurrent ? (
                    <span className="text-[11px] font-semibold text-teal-600 dark:text-[#22D3EE] shrink-0">
                      {t('common:workspaces.active')}
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={() => switchWorkspace(ws.id)}
                      className="px-2.5 py-1 rounded-md border border-slate-300 dark:border-slate-700 hover:border-teal-500 text-[11px] font-medium shrink-0"
                    >
                      {t('common:workspaces.switch')}
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          <form onSubmit={handleAddWorkspace} className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="text-xs font-semibold">{t('common:workspaces.createTitle')}</div>
            <div className="flex flex-wrap gap-2">
              <input
                type="text"
                value={newWsName}
                onChange={(e) => setNewWsName(e.target.value)}
                placeholder={t('common:workspaces.namePlaceholder')}
                className="flex-1 min-w-[140px] px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
              <select
                value={newWsDomain}
                onChange={(e) => setNewWsDomain(e.target.value as DomainId)}
                className="px-2.5 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              >
                {ALL_DOMAIN_IDS.map((d) => (
                  <option key={d} value={d}>
                    {getLocalizedDomainTheme(d).shortLabel}
                  </option>
                ))}
              </select>
              <button
                type="submit"
                className="inline-flex items-center gap-1 px-3 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t('common:actions.add')}</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Multilingual Language & Localization System */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-6 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Globe className="w-5 h-5 text-teal-600 dark:text-[#14B8A6]" />
            <h3 className="font-display font-semibold text-base">
              {t('common:settings.langCurrencyTitle')}
            </h3>
          </div>

          <label className="inline-flex items-center gap-2 text-xs font-medium cursor-pointer">
            <input
              type="checkbox"
              checked={languagePrefs.useSameLanguageEverywhere}
              onChange={(e) => {
                const checked = e.target.checked;
                const def = getLanguageDef(languagePrefs.displayLanguage);
                updateLanguagePrefs({
                  useSameLanguageEverywhere: checked,
                  ...(checked
                    ? {
                        textAssistantLanguage: def.code,
                        voiceInputLocale: def.defaultSpeechLocale,
                        voiceOutputLocale: def.defaultSpeechLocale,
                        voiceOutputVoiceURI: 'auto',
                      }
                    : {}),
                });
              }}
              className="rounded text-teal-600"
            />
            <span>{t('common:language.useSameEverywhere')}</span>
          </label>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <SearchableLanguageSelector
            label={t('common:language.websiteLanguage')}
            value={languagePrefs.displayLanguage}
            align="left"
            onChange={(code) => {
              const def = getLanguageDef(code);
              if (languagePrefs.useSameLanguageEverywhere) {
                updateLanguagePrefs({
                  displayLanguage: code,
                  textAssistantLanguage: code,
                  voiceInputLocale: def.defaultSpeechLocale,
                  voiceOutputLocale: def.defaultSpeechLocale,
                  voiceOutputVoiceURI: 'auto',
                });
              } else {
                updateLanguagePrefs({ displayLanguage: code });
              }
            }}
          />

          <SearchableLanguageSelector
            label={t('common:language.textAssistantLanguage')}
            value={languagePrefs.textAssistantLanguage}
            align="left"
            onChange={(code) =>
              updateLanguagePrefs({
                textAssistantLanguage: code,
                useSameLanguageEverywhere: false,
              })
            }
          />

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
              {t('common:language.voiceInputLanguage')}
            </label>
            <select
              value={languagePrefs.voiceInputLocale}
              onChange={(e) =>
                updateLanguagePrefs({
                  voiceInputLocale: e.target.value,
                  useSameLanguageEverywhere: false,
                })
              }
              className="w-full px-3 py-2.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              {speechVariants.map((v) => (
                <option key={v.locale} value={v.locale}>
                  {v.nativeName} · {v.label} ({v.locale})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
              {t('common:language.voiceOutputLanguage')}
            </label>
            <select
              value={languagePrefs.voiceOutputLocale}
              onChange={(e) =>
                updateLanguagePrefs({
                  voiceOutputLocale: e.target.value,
                  voiceOutputVoiceURI: 'auto',
                  useSameLanguageEverywhere: false,
                })
              }
              className="w-full px-3 py-2.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              {speechVariants.map((v) => (
                <option key={v.locale} value={v.locale}>
                  {v.nativeName} · {v.label} ({v.locale})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
              {t('common:settings.preferredBrowserVoice')}
            </label>
            <select
              value={languagePrefs.voiceOutputVoiceURI}
              onChange={(e) => updateLanguagePrefs({ voiceOutputVoiceURI: e.target.value })}
              className="w-full px-3 py-2.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              <option value="auto">
                {t('common:settings.automaticVoices', { count: matchingVoices.length })}
              </option>
              {matchingVoices.map((v) => (
                <option key={v.voiceURI} value={v.voiceURI}>
                  {v.name} ({v.lang})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
              {t('common:language.displayCurrency')}
            </label>
            <select
              value={languagePrefs.displayCurrency}
              onChange={(e) =>
                updateLanguagePrefs({ displayCurrency: e.target.value as DisplayCurrency })
              }
              className="w-full px-3 py-2.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              <option value="USD">USD ($)</option>
              <option value="INR">INR (₹)</option>
              <option value="EUR">EUR (€)</option>
              <option value="GBP">GBP (£)</option>
              <option value="AED">AED (د.إ)</option>
              <option value="JPY">JPY (¥)</option>
            </select>
            <p className="mt-1 text-[11px] text-slate-500">{t('common:language.currencyNote')}</p>
          </div>
        </div>

        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#172235] border border-slate-200 dark:border-slate-800 text-xs space-y-1 text-slate-600 dark:text-[#94A3B8]">
          <div>
            <span className="font-semibold text-slate-800 dark:text-[#F8FAFC]">
              {t('common:settings.sttLabel')}:{' '}
            </span>
            {speechSupport.sttNote}
          </div>
          <div>
            <span className="font-semibold text-slate-800 dark:text-[#F8FAFC]">
              {t('common:settings.ttsLabel')}:{' '}
            </span>
            {speechSupport.ttsNote}
          </div>
          <div>
            <span className="font-semibold text-slate-800 dark:text-[#F8FAFC]">
              {t('common:settings.registeredLanguages')}:{' '}
            </span>
            {t('common:settings.languagesSummary', {
              total: SUPPORTED_LANGUAGES.length,
              full: SUPPORTED_LANGUAGES.filter((l) => l.translationCoverage === 'complete').length,
            })}
          </div>
        </div>
      </div>

      {/* Theme, Voice, Notifications & Accessibility */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-6 space-y-4">
          <h3 className="font-display font-semibold text-base">
            {t('common:settings.appearanceTitle')}
          </h3>
          <div className="flex items-center justify-between text-xs">
            <span>{t('common:settings.interfaceTheme')}</span>
            <ThemeToggle />
          </div>
          <label className="flex items-center justify-between text-xs cursor-pointer">
            <span>{t('common:settings.reducedMotion')}</span>
            <input
              type="checkbox"
              checked={settings.reducedMotion}
              onChange={(e) => updateSettings({ reducedMotion: e.target.checked })}
              className="rounded text-teal-600"
            />
          </label>
          <label className="flex items-center justify-between text-xs cursor-pointer">
            <span>{t('common:settings.highContrastNumbers')}</span>
            <input
              type="checkbox"
              checked={settings.highContrastNumbers}
              onChange={(e) => updateSettings({ highContrastNumbers: e.target.checked })}
              className="rounded text-teal-600"
            />
          </label>
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-6 space-y-4">
          <h3 className="font-display font-semibold text-base flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-teal-600 dark:text-[#14B8A6]" />
            <span>{t('common:settings.voiceNotificationsTitle')}</span>
          </h3>
          <label className="flex items-center justify-between text-xs cursor-pointer">
            <span>{t('assistant:controls.autoSpeak')}</span>
            <input
              type="checkbox"
              checked={languagePrefs.autoSpeakResponses}
              onChange={(e) => updateLanguagePrefs({ autoSpeakResponses: e.target.checked })}
              className="rounded text-teal-600"
            />
          </label>
          <label className="flex items-center justify-between text-xs cursor-pointer">
            <span>{t('common:settings.neuralEngineToggle')}</span>
            <input
              type="checkbox"
              checked={languagePrefs.preferNeuralVoice !== false}
              onChange={(e) => updateLanguagePrefs({ preferNeuralVoice: e.target.checked })}
              className="rounded text-teal-600"
            />
          </label>
          <label className="flex items-center justify-between text-xs cursor-pointer">
            <span>{t('common:settings.handsFreeLoopToggle')}</span>
            <input
              type="checkbox"
              checked={languagePrefs.handsFreeLoop !== false}
              onChange={(e) => updateLanguagePrefs({ handsFreeLoop: e.target.checked })}
              className="rounded text-teal-600"
            />
          </label>
          <div>
            <label className="block text-xs text-slate-600 dark:text-[#94A3B8] mb-1">
              {t('common:settings.neuralPersonaLabel')}
            </label>
            <select
              value={languagePrefs.neuralVoiceName || 'Kore'}
              onChange={(e) =>
                updateLanguagePrefs({ neuralVoiceName: e.target.value as NeuralVoiceName })
              }
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              {NEURAL_VOICE_PERSONAS.map((persona) => (
                <option key={persona.id} value={persona.id}>
                  {persona.label} — {persona.tone}
                </option>
              ))}
            </select>
          </div>
          <label className="block text-xs">
            <div className="flex justify-between mb-1">
              <span>{t('common:settings.voiceSpeedLabel')}</span>
              <span className="font-mono-nums">{settings.voiceSpeechRate.toFixed(1)}x</span>
            </div>
            <input
              type="range"
              min={0.7}
              max={1.4}
              step={0.1}
              value={settings.voiceSpeechRate}
              onChange={(e) => updateSettings({ voiceSpeechRate: Number(e.target.value) })}
              className="w-full accent-teal-500"
            />
          </label>
          <label className="flex items-center justify-between text-xs cursor-pointer">
            <span>{t('common:settings.budgetAlerts')}</span>
            <input
              type="checkbox"
              checked={settings.budgetWarningNotifications}
              onChange={(e) => updateSettings({ budgetWarningNotifications: e.target.checked })}
              className="rounded text-teal-600"
            />
          </label>
          <label className="flex items-center justify-between text-xs cursor-pointer">
            <span>{t('common:settings.lowInventoryAlerts')}</span>
            <input
              type="checkbox"
              checked={settings.lowStockNotifications}
              onChange={(e) => updateSettings({ lowStockNotifications: e.target.checked })}
              className="rounded text-teal-600"
            />
          </label>
        </div>
      </div>

      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 text-xs text-slate-500 dark:text-[#94A3B8]">
        {t('common:settings.platformFooter')}
      </div>
    </div>
  );
};
