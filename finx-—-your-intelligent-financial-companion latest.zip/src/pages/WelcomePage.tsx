import React, { useState } from 'react';
import {
  ArrowRight,
  Mic,
  ShieldCheck,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { DomainLogoEmblem3D } from '../components/DomainBrand3D';
import { FinXLogo } from '../components/FinXLogo';
import { SearchableLanguageSelector } from '../components/SearchableLanguageSelector';
import { ThemeToggle } from '../components/ThemeToggle';
import { useFinX } from '../context/FinXContext';
import { DomainId } from '../types/finx';

export const WelcomePage: React.FC = () => {
  const { t } = useTranslation(['welcome', 'common']);
  const { navigate, openAssistant, languagePrefs, setUnifiedLanguage } = useFinX();
  const [heroImgFailed, setHeroImgFailed] = useState(false);

  const domains: Array<{
    key: DomainId;
    title: string;
    desc: string;
    span: string;
  }> = [
    {
      key: 'personal-finance',
      title: t('welcome:domains.personalTitle'),
      desc: t('welcome:domains.personalDesc'),
      span: 'lg:col-span-2',
    },
    {
      key: 'product-business',
      title: t('welcome:domains.productTitle'),
      desc: t('welcome:domains.productDesc'),
      span: 'lg:col-span-1',
    },
    {
      key: 'service-business',
      title: t('welcome:domains.serviceTitle'),
      desc: t('welcome:domains.serviceDesc'),
      span: 'lg:col-span-1',
    },
    {
      key: 'investment-knowledge',
      title: t('welcome:domains.investmentTitle'),
      desc: t('welcome:domains.investmentDesc'),
      span: 'lg:col-span-1',
    },
    {
      key: 'financial-intelligence',
      title: t('welcome:domains.intelligenceTitle'),
      desc: t('welcome:domains.intelligenceDesc'),
      span: 'lg:col-span-1',
    },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] flex flex-col">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-[#101827]/95 backdrop-blur-xs">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-8">
          <a
            href="#overview"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="whitespace-nowrap shrink-0"
          >
            <FinXLogo size="md" />
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-[#94A3B8]">
            <a
              href="#overview"
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              {t('welcome:navOverview')}
            </a>
            <a
              href="#domains"
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              {t('welcome:navDomains')}
            </a>
            <a
              href="#voice-ai"
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              {t('welcome:navVoice')}
            </a>
            <a
              href="#architecture"
              className="hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
            >
              {t('welcome:navSecurity')}
            </a>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => navigate('register')}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 hover:bg-teal-700 dark:hover:bg-[#22D3EE] transition-colors whitespace-nowrap shrink-0"
            >
              {t('common:actions.getStarted')}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1">
        <section id="overview" className="max-w-7xl mx-auto px-6 pt-8 pb-16">
          {/* Sub-header controls: Language selector + Theme toggle + Login */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-8 mb-8 border-b border-slate-200 dark:border-slate-800/80">
            <p className="text-xs font-medium text-slate-500 dark:text-[#94A3B8]">
              {t('common:tagline')} · {t('welcome:heroKicker')}
            </p>
            <div className="flex items-center gap-2.5">
              <SearchableLanguageSelector
                value={languagePrefs.displayLanguage}
                onChange={setUnifiedLanguage}
                compact
              />
              <ThemeToggle />
              <button
                type="button"
                onClick={() => navigate('login')}
                className="px-3.5 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#172235] text-slate-800 dark:text-[#F8FAFC] hover:border-teal-500/60 transition-colors whitespace-nowrap shrink-0"
              >
                {t('common:actions.login')}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center">
              <h1
                className="font-display font-extrabold tracking-tight text-slate-900 dark:text-[#F8FAFC] leading-[1.08]"
                style={{ fontSize: 'clamp(2.25rem, 4vw, 3.65rem)', textWrap: 'balance' }}
              >
                {t('welcome:heroHeadline')}
              </h1>

              <p className="mt-5 text-base sm:text-lg text-slate-600 dark:text-[#94A3B8] leading-relaxed max-w-xl">
                {t('welcome:heroDescription')}
              </p>

              <div className="mt-8 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => openAssistant('finance-assistant')}
                  className="inline-flex items-center gap-2.5 px-5 py-3 text-sm font-semibold rounded-xl bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 hover:bg-teal-700 dark:hover:bg-[#22D3EE] transition-colors whitespace-nowrap shrink-0"
                >
                  <Mic className="w-4 h-4 shrink-0" />
                  <span>{t('common:actions.talkToFinX')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => navigate('register')}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-semibold rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-[#172235] text-slate-900 dark:text-[#F8FAFC] hover:border-teal-500 transition-colors whitespace-nowrap shrink-0"
                >
                  <span>{t('common:actions.getStarted')}</span>
                  <ArrowRight className="w-4 h-4 shrink-0 rtl:rotate-180" />
                </button>

                <button
                  type="button"
                  onClick={() => navigate('login')}
                  className="inline-flex items-center gap-2 px-5 py-3 text-sm font-medium rounded-xl text-slate-700 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white transition-colors whitespace-nowrap shrink-0"
                >
                  {t('common:actions.login')}
                </button>
              </div>

              <p className="mt-4 text-xs text-slate-500 dark:text-[#94A3B8]">
                {t('welcome:talkToFinXHelper')}
              </p>
            </div>

            <div className="lg:col-span-6">
              <div className="h-full min-h-[260px] rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden bg-slate-200 dark:bg-[#172235]">
                {!heroImgFailed ? (
                  <img
                    src="/src/assets/images/finx_hero_workspace_1795112316127.jpg"
                    alt={t('common:tagline')}
                    referrerPolicy="no-referrer"
                    onError={() => setHeroImgFailed(true)}
                    className="w-full h-full object-cover lg:h-full"
                  />
                ) : (
                  <div className="w-full h-full min-h-[300px] flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br from-slate-800 to-slate-900 text-slate-200">
                    <FinXLogo size="lg" />
                    <p className="mt-3 text-sm text-slate-400">{t('common:tagline')}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Five Core Financial Domains */}
        <section
          id="domains"
          className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#172235]/60 py-14 sm:py-16"
        >
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="max-w-2xl">
              <h2
                className="font-display font-bold text-2xl sm:text-3xl text-slate-900 dark:text-[#F8FAFC]"
                style={{ textWrap: 'balance' }}
              >
                {t('welcome:domainsHeading')}
              </h2>
              <p className="mt-3 text-sm sm:text-base text-slate-600 dark:text-[#94A3B8]">
                {t('welcome:domainsSubheading')}
              </p>
            </div>

            <div className="mt-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {domains.map((domain) => (
                <div
                  key={domain.key}
                  className={`${domain.span} finx-3d-hover-tilt rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#1E293B] p-6`}
                >
                  <DomainLogoEmblem3D domain={domain.key} size="md" />
                  <h3 className="mt-4 font-display font-semibold text-base text-slate-900 dark:text-[#F8FAFC]">
                    {domain.title}
                  </h3>
                  <p className="mt-2 text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                    {domain.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Voice AI & Architecture */}
        <section id="voice-ai" className="max-w-7xl mx-auto px-4 sm:px-6 py-14 sm:py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6 sm:p-7 flex flex-col justify-between">
              <div>
                <Mic className="w-5 h-5 text-teal-600 dark:text-[#14B8A6]" />
                <h3 className="mt-4 font-display font-bold text-xl text-slate-900 dark:text-[#F8FAFC]">
                  {t('welcome:voiceHighlightTitle')}
                </h3>
                <p className="mt-2.5 text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                  {t('welcome:voiceHighlightDesc')}
                </p>
              </div>
              <div className="mt-6">
                <button
                  type="button"
                  onClick={() => openAssistant('finance-assistant')}
                  className="inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 hover:bg-teal-700 dark:hover:bg-[#22D3EE] transition-colors whitespace-nowrap"
                >
                  <Mic className="w-4 h-4" />
                  <span>{t('common:actions.talkToFinX')}</span>
                </button>
              </div>
            </div>

            <div
              id="architecture"
              className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6 sm:p-7 flex flex-col justify-between"
            >
              <div>
                <ShieldCheck className="w-5 h-5 text-cyan-600 dark:text-[#22D3EE]" />
                <h3 className="mt-4 font-display font-bold text-xl text-slate-900 dark:text-[#F8FAFC]">
                  {t('welcome:securityHeading')}
                </h3>
                <p className="mt-2.5 text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                  {t('welcome:securityDesc')}
                </p>
              </div>
              <div className="mt-6 flex items-center gap-4">
                <button
                  type="button"
                  onClick={() => navigate('login')}
                  className="text-xs font-semibold text-teal-600 dark:text-[#14B8A6] hover:underline whitespace-nowrap"
                >
                  {t('common:actions.login')}
                </button>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-[#101827] py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4 text-xs text-slate-500 dark:text-[#94A3B8]">
          <span>{t('welcome:footerNote')}</span>
          <span>{t('common:brandName')} · {t('common:tagline')}</span>
        </div>
      </footer>
    </div>
  );
};
