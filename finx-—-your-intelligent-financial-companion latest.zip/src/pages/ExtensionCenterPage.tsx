import React, { useMemo, useState } from 'react';
import { CheckCircle2, Puzzle, ShieldAlert, Sliders, X } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useFinX } from '../context/FinXContext';
import { ExtensionCategory, ExtensionDefinition } from '../types/finx';
import { formatDateTime } from '../utils/formatters';

const CATEGORIES: Array<'ALL' | ExtensionCategory> = [
  'ALL',
  'Finance',
  'Business',
  'AI Tools',
  'Analytics',
  'Documents',
  'Productivity',
  'Integrations',
];

export const ExtensionCenterPage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const {
    extensions,
    extensionLogs,
    toggleExtensionStatus,
    installOptionalExtension,
    uninstallOptionalExtension,
    updateExtensionConfig,
  } = useFinX();

  const [catFilter, setCatFilter] = useState<'ALL' | ExtensionCategory>('ALL');
  const [selectedExtId, setSelectedExtId] = useState<string | null>(null);

  const filtered = useMemo(
    () =>
      extensions.filter((ext) =>
        catFilter === 'ALL' ? true : ext.category === catFilter
      ),
    [catFilter, extensions]
  );

  const activeExt: ExtensionDefinition | null =
    extensions.find((e) => e.id === selectedExtId) || null;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-2xl">{t('common:nav.extensions')}</h2>
        <p className="text-sm text-slate-600 dark:text-[#94A3B8] mt-1">
          {t('business:extraPages.extensionsSubtitle')}
        </p>
      </div>

      {/* Category Filter */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#172235] border border-slate-200 dark:border-slate-800 overflow-x-auto">
        {CATEGORIES.map((cat) => (
          <button
            key={cat}
            type="button"
            onClick={() => setCatFilter(cat)}
            className={`px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap ${
              catFilter === cat
                ? 'bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC] shadow-xs'
                : 'text-slate-600 dark:text-[#94A3B8]'
            }`}
          >
            {cat === 'ALL' ? t('business:extraPages.allCategories') : cat}
          </button>
        ))}
      </div>

      {/* Extension Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filtered.map((ext) => (
          <div
            key={ext.id}
            className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 flex flex-col justify-between space-y-4"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <Puzzle className="w-5 h-5 text-teal-600 dark:text-[#14B8A6] shrink-0" />
                  <h3 className="font-display font-semibold text-base">{ext.name}</h3>
                </div>
                <span
                  className={`text-xs font-semibold whitespace-nowrap ${
                    ext.status === 'Installed'
                      ? 'text-emerald-600 dark:text-[#34D399]'
                      : ext.status === 'Disabled'
                        ? 'text-slate-400'
                        : ext.status === 'Coming Soon'
                          ? 'text-amber-600 dark:text-[#FBBF24]'
                          : 'text-cyan-600 dark:text-[#22D3EE]'
                  }`}
                >
                  {t(`business:extraPages.extStatuses.${ext.status}`, { defaultValue: ext.status })}
                </span>
              </div>

              <div className="mt-1.5 text-[11px] text-slate-500 dark:text-[#94A3B8]">
                {ext.category} · v{ext.version} ·{' '}
                {ext.compatible
                  ? t('business:extraPages.extCompatOk')
                  : t('business:extraPages.extCompatReq', { ver: ext.minPlatformVersion })}
              </div>

              <p className="mt-3 text-xs text-slate-600 dark:text-[#94A3B8] leading-relaxed">
                {ext.description}
              </p>
            </div>

            <div className="flex items-center justify-between gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setSelectedExtId(ext.id)}
                className="text-xs font-semibold text-teal-600 dark:text-[#14B8A6] hover:underline text-start"
              >
                {t('business:extraPages.extViewDetails')}
              </button>

              {ext.status === 'Available' && (
                <button
                  type="button"
                  onClick={() => installOptionalExtension(ext.id)}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 shrink-0"
                >
                  {t('business:extraPages.extInstall')}
                </button>
              )}
              {(ext.status === 'Installed' || ext.status === 'Disabled') && (
                <button
                  type="button"
                  onClick={() => toggleExtensionStatus(ext.id)}
                  className="px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 shrink-0"
                >
                  {ext.status === 'Installed'
                    ? t('business:extraPages.extDisable')
                    : t('business:extraPages.extEnable')}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Activity Logs */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3">
        <h3 className="font-display font-semibold text-sm">{t('business:extraPages.extAuditTitle')}</h3>
        <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
          {extensionLogs.slice(0, 6).map((log) => (
            <div key={log.id} className="py-2.5 flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="font-semibold">{log.extensionName}</span> — {log.action}
              </div>
              <div className="flex items-center gap-3 font-mono-nums text-[11px] text-slate-500">
                <span
                  className={
                    log.result === 'Success'
                      ? 'text-emerald-600 dark:text-[#34D399]'
                      : 'text-red-600 dark:text-[#F87171]'
                  }
                >
                  {log.result}
                </span>
                <span>{formatDateTime(log.timestamp)}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Details & Configuration Drawer Modal */}
      {activeExt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] p-6 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-xs text-teal-600 dark:text-[#14B8A6] font-medium">
                  {activeExt.category} · v{activeExt.version}
                </div>
                <h3 className="font-display font-bold text-xl mt-0.5">{activeExt.name}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedExtId(null)}
                aria-label={t('common:actions.close')}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-sm text-slate-600 dark:text-[#94A3B8]">{activeExt.description}</p>

            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-[#172235] space-y-2 text-xs">
              <div className="flex items-center gap-2 font-semibold">
                {activeExt.compatible ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                ) : (
                  <ShieldAlert className="w-4 h-4 text-amber-500" />
                )}
                <span>
                  {t('business:extraPages.extCompatibility')}:{' '}
                  {activeExt.compatible
                    ? t('business:extraPages.extVerifiedCore')
                    : t('business:extraPages.extRequiresPlatform', { ver: activeExt.minPlatformVersion })}
                </span>
              </div>
              <div>
                <span className="font-semibold">{t('business:extraPages.extPermissions')}:</span>{' '}
                <span className="font-mono-nums">{activeExt.permissions.join(', ')}</span>
              </div>
              <div>
                <span className="font-semibold">{t('business:extraPages.extDataBoundary')}:</span> {activeExt.dataBoundary}
              </div>
            </div>

            <div className="space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-semibold">
                <Sliders className="w-4 h-4 text-teal-600 dark:text-[#14B8A6]" />
                <span>{t('business:extraPages.extConfigTitle')}</span>
              </div>
              {Object.entries(activeExt.config).map(([k, val]) => (
                <div key={k} className="flex items-center justify-between gap-3 text-xs">
                  <span className="font-mono-nums text-slate-600 dark:text-[#94A3B8]">{k}</span>
                  {typeof val === 'boolean' ? (
                    <input
                      type="checkbox"
                      checked={val}
                      onChange={(e) =>
                        updateExtensionConfig(activeExt.id, {
                          ...activeExt.config,
                          [k]: e.target.checked,
                        })
                      }
                      className="rounded text-teal-600"
                    />
                  ) : (
                    <input
                      type="text"
                      value={String(val)}
                      onChange={(e) =>
                        updateExtensionConfig(activeExt.id, {
                          ...activeExt.config,
                          [k]: e.target.value,
                        })
                      }
                      className="px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
                    />
                  )}
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              {activeExt.optional && (activeExt.status === 'Installed' || activeExt.status === 'Disabled') && (
                <button
                  type="button"
                  onClick={() => {
                    uninstallOptionalExtension(activeExt.id);
                    setSelectedExtId(null);
                  }}
                  className="px-3.5 py-2 text-xs font-medium rounded-lg border border-red-300 dark:border-red-800 text-red-600 dark:text-[#F87171]"
                >
                  {t('business:extraPages.extUninstall')}
                </button>
              )}
              <button
                type="button"
                onClick={() => setSelectedExtId(null)}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950"
              >
                {t('business:extraPages.extDone')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
