import React, { useEffect, useMemo, useState } from 'react';
import { Check, Edit2, Plus, RotateCcw, Search, Trash2 } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Cell, Pie, PieChart, ResponsiveContainer, Tooltip } from 'recharts';
import { ConfirmDialog } from '../components/ConfirmDialog';
import { DomainBrand3D } from '../components/DomainBrand3D';
import { StatCard } from '../components/StatCard';
import { DOMAIN_THEMES } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import { PaymentMethod, PersonalTransaction, TransactionType } from '../types/finx';
import { formatCurrency, formatDateShort } from '../utils/formatters';
import { validatePositiveNumber, validateRequiredText } from '../utils/validators';

const CATEGORIES = [
  'Salary & Income',
  'Business Draw',
  'Side Income',
  'Housing',
  'Food & Dining',
  'Utilities',
  'Transportation',
  'Software & Tools',
  'Healthcare',
  'Education',
];

const CHART_COLORS = ['#0284C7', '#0D9488', '#38BDF8', '#34D399', '#FBBF24', '#F87171'];
const DRAFT_KEY = 'personal-tx';

export const PersonalFinancePage: React.FC = () => {
  const { t } = useTranslation(['finance', 'common']);
  const {
    activeWorkspace,
    settings,
    transactions,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    budgets,
    updateBudgetLimit,
    savingsGoals,
    addSavingsGoal,
    contributeToGoal,
    bills,
    toggleBillPaid,
    subscriptions,
    toggleSubscriptionActive,
    languagePrefs,
    drafts,
    setDraft,
    clearDraft,
  } = useFinX();

  const domainTheme = DOMAIN_THEMES['personal-finance'];
  const cur = languagePrefs.displayCurrency;
  const [activeTab, setActiveTab] = useState<'transactions' | 'budgets' | 'goals' | 'bills' | 'reports'>('transactions');
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('ALL');
  const [typeFilter, setTypeFilter] = useState<'ALL' | TransactionType>('ALL');
  const [sortBy, setSortBy] = useState<'date' | 'amount'>('date');

  const todayIso = new Date().toISOString().slice(0, 10);
  const oneYearAheadIso = new Date(Date.now() + 365 * 86400_000).toISOString().slice(0, 10);

  const activeMonthPrefix = useMemo(() => {
    const currentPrefix = todayIso.slice(0, 7);
    if (transactions.some((tx) => tx.date.startsWith(currentPrefix))) return currentPrefix;
    return transactions[0]?.date.slice(0, 7) || currentPrefix;
  }, [todayIso, transactions]);

  const savedDraft = drafts[DRAFT_KEY] as
    | {
        amount?: string;
        description?: string;
        category?: string;
        date?: string;
        paymentMethod?: PaymentMethod;
        txType?: TransactionType;
        notes?: string;
      }
    | undefined;

  // Transaction Form Modal State
  const [formOpen, setFormOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<PersonalTransaction | null>(null);
  const [amount, setAmount] = useState(savedDraft?.amount || '');
  const [description, setDescription] = useState(savedDraft?.description || '');
  const [category, setCategory] = useState(savedDraft?.category || 'Food & Dining');
  const [date, setDate] = useState(savedDraft?.date || todayIso);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(savedDraft?.paymentMethod || 'UPI');
  const [txType, setTxType] = useState<TransactionType>(savedDraft?.txType || 'expense');
  const [notes, setNotes] = useState(savedDraft?.notes || '');
  const [formError, setFormError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Goal Form
  const [goalTitle, setGoalTitle] = useState('');
  const [goalTarget, setGoalTarget] = useState('');
  const [goalDate, setGoalDate] = useState(oneYearAheadIso);
  const [goalError, setGoalError] = useState<string | null>(null);

  useEffect(() => {
    if (!formOpen || editingTx) return;
    if (amount || description || notes) {
      setDraft(DRAFT_KEY, {
        amount,
        description,
        category,
        date,
        paymentMethod,
        txType,
        notes,
      });
    }
  }, [amount, category, date, description, editingTx, formOpen, notes, paymentMethod, setDraft, txType]);

  const openAddForm = () => {
    setEditingTx(null);
    const d = drafts[DRAFT_KEY] as typeof savedDraft;
    setAmount(d?.amount || '');
    setDescription(d?.description || '');
    setCategory(d?.category || 'Food & Dining');
    setDate(d?.date || new Date().toISOString().slice(0, 10));
    setPaymentMethod(d?.paymentMethod || 'UPI');
    setTxType(d?.txType || 'expense');
    setNotes(d?.notes || '');
    setFormError(null);
    setFormOpen(true);
  };

  const openEditForm = (tx: PersonalTransaction) => {
    setEditingTx(tx);
    setAmount(String(tx.amount));
    setDescription(tx.description);
    setCategory(tx.category);
    setDate(tx.date);
    setPaymentMethod(tx.paymentMethod);
    setTxType(tx.type);
    setNotes(tx.notes || '');
    setFormError(null);
    setFormOpen(true);
  };

  const resetAddDraft = () => {
    clearDraft(DRAFT_KEY);
    setAmount('');
    setDescription('');
    setCategory('Food & Dining');
    setDate(new Date().toISOString().slice(0, 10));
    setPaymentMethod('UPI');
    setTxType('expense');
    setNotes('');
  };

  const handleSaveTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;
    const amtErr = validatePositiveNumber(amount, t('finance:form.amount'));
    if (amtErr) return setFormError(amtErr);
    const descErr = validateRequiredText(description, t('finance:form.description'));
    if (descErr) return setFormError(descErr);

    setSubmitting(true);
    const payload = {
      amount: Number(amount),
      description: description.trim(),
      category,
      date,
      paymentMethod,
      type: txType,
      notes: notes.trim() || undefined,
    };

    if (editingTx) {
      updateTransaction({ ...payload, id: editingTx.id });
    } else {
      addTransaction(payload);
      clearDraft(DRAFT_KEY);
    }
    setSubmitting(false);
    setFormOpen(false);
  };

  const filteredTransactions = useMemo(() => {
    return transactions
      .filter((tx) => {
        if (catFilter !== 'ALL' && tx.category !== catFilter) return false;
        if (typeFilter !== 'ALL' && tx.type !== typeFilter) return false;
        if (search.trim()) {
          const q = search.toLowerCase();
          return (
            tx.description.toLowerCase().includes(q) ||
            tx.category.toLowerCase().includes(q) ||
            (tx.notes || '').toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) =>
        sortBy === 'date' ? b.date.localeCompare(a.date) : b.amount - a.amount
      );
  }, [catFilter, search, sortBy, transactions, typeFilter]);

  const summary = useMemo(() => {
    const income = transactions.filter((tx) => tx.type === 'income').reduce((s, tx) => s + tx.amount, 0);
    const expense = transactions.filter((tx) => tx.type === 'expense').reduce((s, tx) => s + tx.amount, 0);
    const byCat: Record<string, number> = {};
    transactions
      .filter((tx) => tx.type === 'expense')
      .forEach((tx) => {
        byCat[tx.category] = (byCat[tx.category] || 0) + tx.amount;
      });
    const chartData = Object.entries(byCat).map(([name, value]) => ({ name, value }));
    return { income, expense, net: income - expense, chartData };
  }, [transactions]);

  return (
    <div className="space-y-6">
      <DomainBrand3D
        domain="personal-finance"
        workspaceName={activeWorkspace?.name}
        reducedMotion={settings.reducedMotion}
        rightSlot={
          <button
            type="button"
            onClick={openAddForm}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl transition-colors whitespace-nowrap ${domainTheme.buttonBgClass}`}
          >
            <Plus className="w-4 h-4" />
            <span>{t('finance:form.addTransaction')}</span>
          </button>
        }
      />

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard label={t('finance:kpi.totalIncome')} value={formatCurrency(summary.income, cur)} tone="positive" />
        <StatCard label={t('finance:kpi.totalExpenses')} value={formatCurrency(summary.expense, cur)} tone="neutral" />
        <StatCard
          label={t('finance:kpi.netSavings')}
          value={formatCurrency(summary.net, cur)}
          tone={summary.net >= 0 ? 'positive' : 'negative'}
        />
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#172235] border border-slate-200 dark:border-slate-800 overflow-x-auto">
        {(
          [
            { id: 'transactions', label: t('finance:tabs.transactions') },
            { id: 'budgets', label: t('finance:tabs.budgets') },
            { id: 'goals', label: t('finance:tabs.goals') },
            { id: 'bills', label: t('finance:tabs.bills') },
            { id: 'reports', label: t('finance:tabs.reports') },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
              activeTab === tab.id
                ? 'bg-white dark:bg-[#1E293B] text-sky-700 dark:text-sky-300 shadow-xs'
                : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === 'transactions' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] overflow-hidden">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[180px]">
              <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t('finance:searchPlaceholder')}
                className="w-full ps-9 pe-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>

            <select
              value={catFilter}
              onChange={(e) => setCatFilter(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              <option value="ALL">{t('finance:allCategories')}</option>
              {CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>

            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as 'ALL' | TransactionType)}
              className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              <option value="ALL">{t('finance:allTypes')}</option>
              <option value="income">{t('finance:form.income')}</option>
              <option value="expense">{t('finance:form.expense')}</option>
            </select>

            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'date' | 'amount')}
              className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              <option value="date">{t('finance:sortByDate')}</option>
              <option value="amount">{t('finance:sortByAmount')}</option>
            </select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 dark:bg-[#172235] text-slate-500 dark:text-[#94A3B8] border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="text-start px-4 py-3 font-medium">{t('finance:table.description')}</th>
                  <th className="text-start px-4 py-3 font-medium">{t('finance:table.category')}</th>
                  <th className="text-start px-4 py-3 font-medium">{t('finance:table.method')}</th>
                  <th className="text-start px-4 py-3 font-medium">{t('finance:table.date')}</th>
                  <th className="text-end px-4 py-3 font-medium">{t('finance:table.amount')}</th>
                  <th className="text-end px-4 py-3 font-medium">{t('finance:table.actions')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-slate-500 dark:text-[#94A3B8]">
                      {t('finance:noMatchingTx')}
                    </td>
                  </tr>
                ) : (
                  filteredTransactions.map((tx) => (
                    <tr key={tx.id} className="hover:bg-slate-50/70 dark:hover:bg-[#172235]/60">
                      <td className="px-4 py-3">
                        <div className="font-medium text-slate-900 dark:text-[#F8FAFC]">{tx.description}</div>
                        {tx.notes && (
                          <div className="text-[11px] text-slate-500 dark:text-[#94A3B8]">{tx.notes}</div>
                        )}
                      </td>
                      <td className="px-4 py-3 text-slate-600 dark:text-[#94A3B8]">{tx.category}</td>
                      <td className="px-4 py-3 text-slate-600 dark:text-[#94A3B8]">{tx.paymentMethod}</td>
                      <td className="px-4 py-3 font-mono-nums text-slate-600 dark:text-[#94A3B8]">
                        {formatDateShort(tx.date)}
                      </td>
                      <td
                        className={`px-4 py-3 text-end font-mono-nums font-semibold ${
                          tx.type === 'income'
                            ? 'text-emerald-600 dark:text-[#34D399]'
                            : 'text-slate-900 dark:text-[#F8FAFC]'
                        }`}
                      >
                        {tx.type === 'income' ? '+' : '-'}
                        {formatCurrency(tx.amount, cur)}
                      </td>
                      <td className="px-4 py-3 text-end">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openEditForm(tx)}
                            className="p-1.5 rounded-md text-slate-500 hover:text-sky-600 dark:hover:text-sky-400"
                            aria-label={t('common:actions.edit')}
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteId(tx.id)}
                            className="p-1.5 rounded-md text-slate-500 hover:text-red-600 dark:hover:text-[#F87171]"
                            aria-label={t('common:actions.delete')}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'budgets' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {budgets.length === 0 ? (
            <div className="md:col-span-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
              {t('finance:budgets.empty')}
            </div>
          ) : (
            budgets.map((b) => {
              const spent = transactions
                .filter(
                  (tx) =>
                    tx.type === 'expense' &&
                    tx.category === b.category &&
                    tx.date.startsWith(activeMonthPrefix)
                )
                .reduce((s, tx) => s + tx.amount, 0);
              const pct = b.monthlyLimit > 0 ? Math.round((spent / b.monthlyLimit) * 100) : 0;
              return (
                <div
                  key={b.id}
                  className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-display font-semibold text-sm">{b.category}</span>
                    <span
                      className={`font-mono-nums text-xs font-semibold ${
                        pct >= 100
                          ? 'text-red-600 dark:text-[#F87171]'
                          : pct >= b.alertThresholdPercent
                            ? 'text-amber-600 dark:text-[#FBBF24]'
                            : 'text-emerald-600 dark:text-[#34D399]'
                      }`}
                    >
                      {t('finance:budgets.usedPercent', { pct })}
                    </span>
                  </div>
                  <div className="h-2.5 rounded-full bg-slate-100 dark:bg-[#101827] overflow-hidden">
                    <div
                      style={{ width: `${Math.min(100, pct)}%` }}
                      className={`h-full rounded-full ${
                        pct >= 100
                          ? 'bg-red-500 dark:bg-[#F87171]'
                          : pct >= b.alertThresholdPercent
                            ? 'bg-amber-500 dark:bg-[#FBBF24]'
                            : 'bg-sky-600 dark:bg-sky-400'
                      }`}
                    />
                  </div>
                  <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 dark:text-[#94A3B8]">
                    <span className="font-mono-nums">
                      {t('finance:budgets.spent')}: {formatCurrency(spent, cur)}
                    </span>
                    <label className="inline-flex items-center gap-2">
                      <span>{t('finance:budgets.limit')}:</span>
                      <input
                        type="number"
                        min={1}
                        value={b.monthlyLimit}
                        onChange={(e) => updateBudgetLimit(b.id, Number(e.target.value))}
                        className="w-24 px-2 py-1 rounded border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums text-slate-900 dark:text-[#F8FAFC]"
                      />
                    </label>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {activeTab === 'goals' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {savingsGoals.length === 0 ? (
              <div className="md:col-span-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
                {t('finance:goals.empty')}
              </div>
            ) : (
              savingsGoals.map((g) => {
                const pct =
                  g.targetAmount > 0
                    ? Math.min(100, Math.round((g.currentAmount / g.targetAmount) * 100))
                    : 0;
                return (
                  <div
                    key={g.id}
                    className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 flex flex-col justify-between space-y-4"
                  >
                    <div>
                      <div className="text-xs text-slate-500 dark:text-[#94A3B8]">
                        {t('finance:goals.priority')}: {g.priority} · {t('finance:goals.targetDate')} {formatDateShort(g.targetDate)}
                      </div>
                      <h4 className="font-display font-semibold text-base mt-1">{g.title}</h4>
                      <div className="mt-3 flex items-baseline justify-between gap-2 font-mono-nums text-xs">
                        <span className="font-bold text-sky-600 dark:text-sky-400">
                          {formatCurrency(g.currentAmount, cur)}
                        </span>
                        <span className="text-slate-500 dark:text-[#94A3B8]">
                          {t('finance:goals.ofTarget', { amount: formatCurrency(g.targetAmount, cur), pct })}
                        </span>
                      </div>
                      <div className="mt-2 h-2 rounded-full bg-slate-100 dark:bg-[#101827] overflow-hidden">
                        <div
                          style={{ width: `${pct}%` }}
                          className="h-full bg-sky-600 dark:bg-sky-400 rounded-full"
                        />
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => contributeToGoal(g.id, 250)}
                      className="w-full py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 hover:border-sky-500 transition-colors"
                    >
                      {t('finance:goals.contributeAmount', { amount: formatCurrency(250, cur) })}
                    </button>
                  </div>
                );
              })
            )}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              setGoalError(null);
              if (!goalTitle.trim()) {
                setGoalError(t('finance:goals.titleError'));
                return;
              }
              if (!Number.isFinite(Number(goalTarget)) || Number(goalTarget) <= 0) {
                setGoalError(t('finance:goals.targetError'));
                return;
              }
              addSavingsGoal({
                title: goalTitle.trim(),
                targetAmount: Number(goalTarget),
                currentAmount: 0,
                targetDate: goalDate,
                priority: 'Medium',
              });
              setGoalTitle('');
              setGoalTarget('');
            }}
            className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3"
          >
            {goalError && (
              <p className="text-xs text-red-600 dark:text-[#F87171]">{goalError}</p>
            )}
            <div className="flex flex-wrap items-end gap-3">
              <div className="flex-1 min-w-[200px]">
                <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                  {t('finance:goals.newGoalLabel')}
                </label>
                <input
                  type="text"
                  value={goalTitle}
                  onChange={(e) => setGoalTitle(e.target.value)}
                  placeholder={t('finance:goals.goalPlaceholder')}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                />
              </div>
              <div className="w-full sm:w-36">
                <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                  {t('finance:goals.targetAmountLabel')}
                </label>
                <input
                  type="number"
                  value={goalTarget}
                  onChange={(e) => setGoalTarget(e.target.value)}
                  placeholder="5000"
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
                />
              </div>
              <div className="w-full sm:w-40">
                <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                  {t('finance:goals.targetDateLabel')}
                </label>
                <input
                  type="date"
                  value={goalDate}
                  onChange={(e) => setGoalDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                />
              </div>
              <button
                type="submit"
                className={`px-4 py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}
              >
                {t('finance:goals.createGoalButton')}
              </button>
            </div>
          </form>
        </div>
      )}

      {activeTab === 'bills' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3">
            <h3 className="font-display font-semibold text-sm">{t('finance:bills.upcomingBills')}</h3>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {bills.map((bill) => (
                <div key={bill.id} className="py-3 flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-xs font-semibold">{bill.title}</div>
                    <div className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                      {t('finance:bills.due')} {formatDateShort(bill.dueDate)} ·{' '}
                      {bill.autopay ? t('finance:bills.autopayOn') : t('finance:bills.manual')}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="font-mono-nums text-xs font-bold">
                      {formatCurrency(bill.amount, cur)}
                    </span>
                    <button
                      type="button"
                      onClick={() => toggleBillPaid(bill.id)}
                      className={`inline-flex items-center gap-1 px-2.5 py-1 text-xs rounded-md border ${
                        bill.status === 'Paid'
                          ? 'border-emerald-500/40 text-emerald-600 dark:text-[#34D399]'
                          : 'border-slate-300 dark:border-slate-700 text-slate-600 dark:text-[#94A3B8]'
                      }`}
                    >
                      <Check className="w-3 h-3" />
                      <span>
                        {bill.status === 'Paid'
                          ? t('finance:bills.paidStatus')
                          : t('finance:bills.pendingStatus')}
                      </span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3">
            <h3 className="font-display font-semibold text-sm">{t('finance:bills.recurringSubscriptions')}</h3>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {subscriptions.map((sub) => (
                <div key={sub.id} className="py-3 flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-xs font-semibold">{sub.name}</div>
                    <div className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                      {sub.billingCycle} · {t('finance:bills.next')}: {formatDateShort(sub.nextBillingDate)}
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0">
                    <span className="font-mono-nums text-xs font-bold">
                      {formatCurrency(sub.amount, cur)}
                    </span>
                    <button
                      type="button"
                      onClick={() => toggleSubscriptionActive(sub.id)}
                      className={`px-2.5 py-1 text-xs rounded-md border ${
                        sub.active
                          ? 'border-sky-500/40 text-sky-600 dark:text-sky-400'
                          : 'border-slate-300 dark:border-slate-700 text-slate-400'
                      }`}
                    >
                      {sub.active ? t('finance:bills.active') : t('finance:bills.paused')}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'reports' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5">
            <h3 className="font-display font-semibold text-sm mb-4">{t('finance:reports.spendingByCategory')}</h3>
            {summary.chartData.length === 0 ? (
              <p className="py-12 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
                {t('finance:reports.noExpenseData')}
              </p>
            ) : (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={summary.chartData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={55}
                      outerRadius={88}
                      paddingAngle={2}
                    >
                      {summary.chartData.map((_, i) => (
                        <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#172235',
                        borderColor: '#334155',
                        borderRadius: 8,
                        color: '#F8FAFC',
                        fontSize: 12,
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
          <div className="lg:col-span-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3">
            <h3 className="font-display font-semibold text-sm">{t('finance:reports.categoryTotals')}</h3>
            {summary.chartData.length === 0 ? (
              <p className="py-8 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
                {t('finance:reports.noExpenseData')}
              </p>
            ) : (
              summary.chartData.map((row, idx) => (
                <div
                  key={row.name}
                  className="flex items-center justify-between text-xs py-1.5 border-b border-slate-100 dark:border-slate-800 last:border-b-0"
                >
                  <span className="inline-flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-xs"
                      style={{ backgroundColor: CHART_COLORS[idx % CHART_COLORS.length] }}
                    />
                    <span>{row.name}</span>
                  </span>
                  <span className="font-mono-nums font-semibold">{formatCurrency(row.value, cur)}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Add / Edit Transaction Modal */}
      {formOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 p-4" role="dialog" aria-modal="true">
          <form
            onSubmit={handleSaveTransaction}
            className="w-full max-w-md rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] p-5 sm:p-6 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto"
          >
            <div className="flex items-center justify-between gap-2">
              <h3 className="font-display font-bold text-lg">
                {editingTx ? t('finance:form.editTransaction') : t('finance:form.addTransaction')}
              </h3>
              {!editingTx && (amount || description || notes) && (
                <button
                  type="button"
                  onClick={resetAddDraft}
                  className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-sky-600"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>{t('finance:form.resetDraft')}</span>
                </button>
              )}
            </div>

            {formError && (
              <div className="p-2.5 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-300 dark:border-red-800 text-xs text-red-700 dark:text-[#F87171]">
                {formError}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                  {t('finance:form.type')}
                </label>
                <select
                  value={txType}
                  onChange={(e) => setTxType(e.target.value as TransactionType)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                >
                  <option value="expense">{t('finance:form.expense')}</option>
                  <option value="income">{t('finance:form.income')}</option>
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                  {t('finance:form.amount')}
                </label>
                <input
                  type="number"
                  step="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                {t('finance:form.description')}
              </label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder={t('finance:form.descriptionPlaceholder')}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                  {t('finance:form.category')}
                </label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                  {t('finance:form.date')}
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                {t('finance:form.paymentMethod')}
              </label>
              <select
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value as PaymentMethod)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              >
                {(['UPI', 'Bank Transfer', 'Credit Card', 'Debit Card', 'Cash'] as const).map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 dark:text-[#94A3B8] mb-1">
                {t('finance:form.notes')}
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={t('finance:form.notesPlaceholder')}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setFormOpen(false)}
                className="px-4 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700"
              >
                {t('common:actions.cancel')}
              </button>
              <button
                type="submit"
                disabled={submitting}
                className={`px-4 py-2 text-xs font-semibold rounded-lg disabled:opacity-50 ${domainTheme.buttonBgClass}`}
              >
                {t('common:actions.save')}
              </button>
            </div>
          </form>
        </div>
      )}

      <ConfirmDialog
        open={Boolean(deleteId)}
        title={t('common:actions.delete')}
        message={t('finance:confirmDelete')}
        onCancel={() => setDeleteId(null)}
        onConfirm={() => {
          if (deleteId) deleteTransaction(deleteId);
          setDeleteId(null);
        }}
      />
    </div>
  );
};
