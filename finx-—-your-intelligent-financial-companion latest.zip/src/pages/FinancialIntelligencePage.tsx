import React, { useMemo, useState } from 'react';
import { AlertTriangle, Bot, Calculator, Cpu, Download, ShieldAlert } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { DomainBrand3D } from '../components/DomainBrand3D';
import { StatCard } from '../components/StatCard';
import { DOMAIN_THEMES, getLocalizedDomainTheme } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import { intelligenceService } from '../services/intelligenceService';
import { formatCurrency } from '../utils/formatters';

export const FinancialIntelligencePage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const {
    activeWorkspace,
    settings,
    transactions,
    budgets,
    products,
    clients,
    metrics,
    languagePrefs,
    openAssistant,
    pushToast,
  } = useFinX();

  const domainTheme = DOMAIN_THEMES['financial-intelligence'];
  const cur = languagePrefs.displayCurrency;
  const [activeLayer, setActiveLayer] = useState<'actual' | 'rules' | 'demo-ml' | 'ai-narrative'>('actual');

  // Interactive Scenario Modeling sliders
  const [inflowGrowthPct, setInflowGrowthPct] = useState(4);
  const [costReductionPct, setCostReductionPct] = useState(3);

  const ruleInsights = useMemo(
    () =>
      intelligenceService.generateRuleBasedInsights({
        transactions,
        budgets,
        products,
        clients,
        metrics,
      }),
    [budgets, clients, metrics, products, transactions]
  );

  const domainComparisonData = useMemo(
    () => [
      {
        domain: getLocalizedDomainTheme('personal-finance').shortLabel,
        inflow: Math.round(metrics.personalIncome),
        net: Math.round(metrics.personalIncome - metrics.personalExpenses),
      },
      {
        domain: getLocalizedDomainTheme('product-business').shortLabel,
        inflow: Math.round(metrics.productRevenue),
        net: Math.round(metrics.productNetProfit),
      },
      {
        domain: getLocalizedDomainTheme('service-business').shortLabel,
        inflow: Math.round(metrics.serviceCollectedRevenue),
        net: Math.round(metrics.serviceNetProfit),
      },
    ],
    [metrics]
  );

  const scenarioForecast = useMemo(() => {
    const baseInflow = Math.max(100, metrics.combinedGrossInflow / 3);
    const baseOutflow = Math.max(50, (metrics.combinedGrossInflow - metrics.combinedNetPosition) / 3);
    const rows = [];
    let curIn = baseInflow;
    let curOut = baseOutflow;
    const now = new Date();
    for (let i = 1; i <= 6; i += 1) {
      const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
      const label = d.toISOString().slice(0, 7);
      curIn = Math.round(curIn * (1 + inflowGrowthPct / 100));
      curOut = Math.round(curOut * (1 - costReductionPct / 100 / 3));
      rows.push({
        month: label,
        projectedIncome: curIn,
        projectedExpense: curOut,
        projectedNet: curIn - curOut,
      });
    }
    return rows;
  }, [costReductionPct, inflowGrowthPct, metrics.combinedGrossInflow, metrics.combinedNetPosition]);

  const exportIntelligenceCsv = () => {
    const rows = [
      ['Metric', 'Value', 'Methodology'],
      ['Combined Gross Inflow', String(metrics.combinedGrossInflow), 'Actual Ledger Arithmetic'],
      ['Combined Net Position', String(metrics.combinedNetPosition), 'Actual Ledger Arithmetic'],
      ['Personal Savings Rate %', String(metrics.savingsRatePercent), 'Actual Ledger Arithmetic'],
      ['Product Revenue', String(metrics.productRevenue), 'Actual Ledger Arithmetic'],
      ['Product Net Profit', String(metrics.productNetProfit), 'Actual Ledger Arithmetic'],
      ['Service Collected Revenue', String(metrics.serviceCollectedRevenue), 'Actual Ledger Arithmetic'],
      ['Service Pending Receivables', String(metrics.servicePendingReceivables), 'Actual Ledger Arithmetic'],
      ...ruleInsights.map((r) => [`Rule Insight: ${r.title}`, r.severity.toUpperCase(), r.explanation]),
    ];
    const csv = rows.map((r) => r.map((cell) => `"${String(cell).replaceAll('"', '""')}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `finx-intelligence-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    pushToast({ kind: 'success', title: t('business:intelligence.csvExported') });
  };

  const exportIntelligenceJson = () => {
    const payload = {
      generatedAt: new Date().toISOString(),
      workspace: activeWorkspace?.name || 'FinX Workspace',
      currency: cur,
      actualMetrics: metrics,
      ruleInsights,
      scenarioModel: {
        monthlyInflowGrowthPct: inflowGrowthPct,
        costOptimizationPct: costReductionPct,
        trajectory: scenarioForecast,
      },
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `finx-intelligence-report-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    pushToast({ kind: 'success', title: t('business:intelligence.jsonExported') });
  };

  return (
    <div className="space-y-6 min-w-0">
      <DomainBrand3D
        domain="financial-intelligence"
        workspaceName={activeWorkspace?.name}
        reducedMotion={settings.reducedMotion}
        rightSlot={
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={exportIntelligenceCsv}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 bg-white/80 dark:bg-[#101827]/70 hover:border-cyan-500"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('common:actions.exportCsv')}</span>
            </button>
            <button
              type="button"
              onClick={exportIntelligenceJson}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-700 bg-white/80 dark:bg-[#101827]/70 hover:border-cyan-500"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('common:actions.exportJson')}</span>
            </button>
            <button
              type="button"
              onClick={() => openAssistant('finance-assistant')}
              className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-xl ${domainTheme.buttonBgClass}`}
            >
              <Bot className="w-4 h-4" />
              <span>{t('business:intelligence.discussAi')}</span>
            </button>
          </div>
        }
      />

      {/* Explicit Layer Selector */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#172235] border border-slate-200 dark:border-slate-800 overflow-x-auto">
        {(
          [
            { id: 'actual', label: t('business:intelligence.actualTab'), icon: Calculator },
            { id: 'rules', label: t('business:intelligence.rulesTab'), icon: ShieldAlert },
            { id: 'demo-ml', label: t('business:intelligence.demoMlTab'), icon: Cpu },
            { id: 'ai-narrative', label: t('business:intelligence.aiNarrativeTab'), icon: Bot },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveLayer(tab.id)}
              className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                activeLayer === tab.id
                  ? 'bg-white dark:bg-[#1E293B] text-cyan-700 dark:text-cyan-300 shadow-xs'
                  : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5 text-cyan-600 dark:text-[#22D3EE]" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {activeLayer === 'actual' && (
        <div className="space-y-6">
          <p className="text-xs text-slate-500 dark:text-[#94A3B8]">
            {t('business:intelligence.actualMethodology')}
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
            <StatCard
              label={t('business:intelligence.combinedInflow')}
              value={formatCurrency(metrics.combinedGrossInflow, cur)}
              tone="positive"
            />
            <StatCard
              label={t('business:intelligence.combinedNet')}
              value={formatCurrency(metrics.combinedNetPosition, cur)}
              tone={metrics.combinedNetPosition >= 0 ? 'positive' : 'negative'}
            />
            <StatCard
              label={t('business:intelligence.savingsRate')}
              value={`${metrics.savingsRatePercent}%`}
              tone={metrics.savingsRatePercent >= 20 ? 'positive' : 'warning'}
            />
            <StatCard
              label={t('business:intelligence.pendingOverdue')}
              value={formatCurrency(metrics.servicePendingReceivables, cur)}
              tone="warning"
            />
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5">
            <h3 className="font-display font-semibold text-sm mb-4">
              {t('business:intelligence.comparisonTitle')}
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={domainComparisonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="domain" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#172235',
                      borderColor: '#334155',
                      borderRadius: 8,
                      color: '#F8FAFC',
                      fontSize: 12,
                    }}
                  />
                  <Legend />
                  <Bar dataKey="inflow" name={t('business:intelligence.grossInflowSeries')} fill="#0891B2" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="net" name={t('business:intelligence.netSurplusSeries')} fill="#2563EB" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {activeLayer === 'rules' && (
        <div className="space-y-4">
          <p className="text-xs text-slate-500 dark:text-[#94A3B8]">
            {t('business:intelligence.rulesMethodology')}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {ruleInsights.map((ins) => (
              <div
                key={ins.id}
                className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-2"
              >
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-cyan-600 dark:text-[#22D3EE]">{ins.domain}</span>
                  <span
                    className={`font-semibold ${
                      ins.severity === 'alert'
                        ? 'text-red-600 dark:text-[#F87171]'
                        : ins.severity === 'warning'
                          ? 'text-amber-600 dark:text-[#FBBF24]'
                          : 'text-cyan-600 dark:text-[#22D3EE]'
                    }`}
                  >
                    {ins.severity.toUpperCase()}
                  </span>
                </div>
                <h3 className="font-display font-semibold text-sm">{ins.title}</h3>
                <p className="text-xs text-slate-600 dark:text-[#94A3B8]">{ins.explanation}</p>
                <p className="text-[11px] font-mono-nums text-slate-500 pt-1 border-t border-slate-100 dark:border-slate-800">
                  {ins.ruleDefinition}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeLayer === 'demo-ml' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl border border-amber-400/40 bg-amber-500/5 flex items-start gap-3 text-xs text-amber-800 dark:text-amber-200">
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{t('business:intelligence.scenarioBanner')}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 text-xs">
            <label className="block space-y-1.5">
              <div className="flex justify-between font-medium">
                <span>{t('business:intelligence.inflowGrowthLabel')}</span>
                <span className="font-mono-nums text-cyan-600 dark:text-[#22D3EE] font-semibold">
                  {inflowGrowthPct >= 0 ? `+${inflowGrowthPct}%` : `${inflowGrowthPct}%`} {t('business:intelligence.perMonthSuffix')}
                </span>
              </div>
              <input
                type="range"
                min={-10}
                max={25}
                step={1}
                value={inflowGrowthPct}
                onChange={(e) => setInflowGrowthPct(Number(e.target.value))}
                className="w-full accent-cyan-600"
              />
            </label>

            <label className="block space-y-1.5">
              <div className="flex justify-between font-medium">
                <span>{t('business:intelligence.costOptLabel')}</span>
                <span className="font-mono-nums text-blue-600 dark:text-blue-400 font-semibold">
                  -{costReductionPct}% {t('business:intelligence.opExDriftSuffix')}
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={20}
                step={1}
                value={costReductionPct}
                onChange={(e) => setCostReductionPct(Number(e.target.value))}
                className="w-full accent-blue-600"
              />
            </label>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5">
            <h3 className="font-display font-semibold text-sm mb-4">
              {t('business:intelligence.scenarioChartTitle')}
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={scenarioForecast}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#94A3B8' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#94A3B8' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#172235',
                      borderColor: '#334155',
                      borderRadius: 8,
                      color: '#F8FAFC',
                      fontSize: 12,
                    }}
                  />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="projectedIncome"
                    name={t('business:intelligence.scenarioInflowSeries')}
                    stroke="#0891B2"
                    fill="#0891B2"
                    fillOpacity={0.2}
                  />
                  <Area
                    type="monotone"
                    dataKey="projectedExpense"
                    name={t('business:intelligence.scenarioOutflowSeries')}
                    stroke="#2563EB"
                    fill="#2563EB"
                    fillOpacity={0.14}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {activeLayer === 'ai-narrative' && (
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-6 space-y-4">
          <h3 className="font-display font-bold text-base">
            {t('business:intelligence.aiSummaryTitle')}
          </h3>
          <p className="text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
            {t('business:intelligence.aiSummaryBody', {
              personalIncome: formatCurrency(metrics.personalIncome, cur),
              personalExpenses: formatCurrency(metrics.personalExpenses, cur),
              savingsRate: metrics.savingsRatePercent,
              productRevenue: formatCurrency(metrics.productRevenue, cur),
              serviceRevenue: formatCurrency(metrics.serviceCollectedRevenue, cur),
              pendingReceivables: formatCurrency(metrics.servicePendingReceivables, cur),
            })}
          </p>
          <button
            type="button"
            onClick={() => openAssistant('finance-assistant')}
            className={`inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}
          >
            <Bot className="w-4 h-4" />
            <span>{t('business:intelligence.askAiDeeper')}</span>
          </button>
        </div>
      )}
    </div>
  );
};
