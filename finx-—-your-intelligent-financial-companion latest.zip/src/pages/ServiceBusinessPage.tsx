import React, { useEffect, useState } from 'react';
import {
  Briefcase,
  CheckCircle2,
  DollarSign,
  FileText,
  FolderKanban,
  Plus,
  Printer,
  RotateCcw,
  Users,
  X,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { DomainBrand3D } from '../components/DomainBrand3D';
import { StatCard } from '../components/StatCard';
import { DOMAIN_THEMES } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import { ServiceInvoice } from '../types/finx';
import { formatCurrency, formatDateShort } from '../utils/formatters';

const DRAFT_KEY = 'service-client';

export const ServiceBusinessPage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const {
    activeWorkspace,
    settings,
    clients,
    addClient,
    recordClientPayment,
    projects,
    addProject,
    invoices,
    createInvoice,
    markInvoicePaid,
    payroll,
    addPayrollRecord,
    togglePayrollStatus,
    businessExpenses,
    addBusinessExpense,
    metrics,
    languagePrefs,
    drafts,
    setDraft,
    clearDraft,
  } = useFinX();

  const domainTheme = DOMAIN_THEMES['service-business'];
  const cur = languagePrefs.displayCurrency;
  const [activeTab, setActiveTab] = useState<'clients' | 'projects' | 'invoices' | 'payroll'>('clients');

  const defaultDueIso = new Date(Date.now() + 30 * 86400_000).toISOString().slice(0, 10);

  const savedDraft = drafts[DRAFT_KEY] as
    | { cName?: string; cContact?: string; cService?: string; cProject?: string; cAgreed?: string; cDue?: string }
    | undefined;

  const [showAddClient, setShowAddClient] = useState(Boolean(savedDraft?.cName));
  const [cName, setCName] = useState(savedDraft?.cName || '');
  const [cContact, setCContact] = useState(savedDraft?.cContact || '');
  const [cService, setCService] = useState(savedDraft?.cService || '');
  const [cProject, setCProject] = useState(savedDraft?.cProject || '');
  const [cAgreed, setCAgreed] = useState(savedDraft?.cAgreed || '');
  const [cDue, setCDue] = useState(savedDraft?.cDue || defaultDueIso);

  useEffect(() => {
    if (!showAddClient) return;
    if (cName || cContact || cService || cAgreed) {
      setDraft(DRAFT_KEY, { cName, cContact, cService, cProject, cAgreed, cDue });
    }
  }, [cAgreed, cContact, cDue, cName, cProject, cService, setDraft, showAddClient]);

  const [payClientId, setPayClientId] = useState(clients[1]?.id || clients[0]?.id || '');
  const [payAmount, setPayAmount] = useState('');
  const [payError, setPayError] = useState<string | null>(null);

  // Add Project state
  const [prjClientId, setPrjClientId] = useState(clients[0]?.id || '');
  const [prjTitle, setPrjTitle] = useState('');
  const [prjMilestone, setPrjMilestone] = useState('');
  const [prjDirectCost, setPrjDirectCost] = useState('');

  // Create Invoice state
  const [invClientId, setInvClientId] = useState(clients[0]?.id || '');
  const [invDesc, setInvDesc] = useState('');
  const [invAmt, setInvAmt] = useState('');
  const [invDue, setInvDue] = useState(defaultDueIso);
  const [previewInvoice, setPreviewInvoice] = useState<ServiceInvoice | null>(null);

  // Payroll Add state
  const [memberName, setMemberName] = useState('');
  const [memberRole, setMemberRole] = useState('Associate Consultant');
  const [memberAmt, setMemberAmt] = useState('');

  // Operating expense
  const [expDesc, setExpDesc] = useState('');
  const [expAmt, setExpAmt] = useState('');

  const effectivePayClientId = clients.some((c) => c.id === payClientId)
    ? payClientId
    : clients[0]?.id || '';
  const effectivePrjClientId = clients.some((c) => c.id === prjClientId)
    ? prjClientId
    : clients[0]?.id || '';
  const effectiveInvClientId = clients.some((c) => c.id === invClientId)
    ? invClientId
    : clients[0]?.id || '';

  const serviceExpenses = businessExpenses.filter((e) => e.domain === 'service');

  const translateStatus = (status: string) => {
    if (status === 'Paid') return t('business:service.statusPaid');
    if (status === 'Overdue') return t('business:service.statusOverdue');
    if (status === 'Scheduled') return t('business:service.statusScheduled');
    if (status === 'Active') return t('business:service.statusActive');
    if (status === 'Pending') return t('business:service.statusPending');
    return status;
  };

  return (
    <div className="space-y-6">
      <DomainBrand3D
        domain="service-business"
        workspaceName={activeWorkspace?.name}
        reducedMotion={settings.reducedMotion}
        rightSlot={
          <button
            type="button"
            onClick={() => setShowAddClient((s) => !s)}
            className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-xl whitespace-nowrap ${domainTheme.buttonBgClass}`}
          >
            <Plus className="w-4 h-4" />
            <span>{t('business:service.addClient')}</span>
          </button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          label={t('business:service.collectedRevenueKpi')}
          value={formatCurrency(metrics.serviceCollectedRevenue, cur)}
          tone="positive"
        />
        <StatCard
          label={t('business:service.pendingReceivables')}
          value={formatCurrency(metrics.servicePendingReceivables, cur)}
          tone="warning"
        />
        <StatCard
          label={t('business:service.overdueAmount')}
          value={formatCurrency(metrics.serviceOverdueAmount, cur)}
          tone={metrics.serviceOverdueAmount > 0 ? 'negative' : 'positive'}
        />
        <StatCard
          label={t('business:service.netProfitKpi')}
          value={formatCurrency(metrics.serviceNetProfit, cur)}
          tone={metrics.serviceNetProfit >= 0 ? 'positive' : 'negative'}
        />
      </div>

      {/* Sub-navigation Tabs */}
      <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-200/70 dark:bg-[#172235] border border-slate-200 dark:border-slate-800 overflow-x-auto">
        {(
          [
            { id: 'clients', label: t('business:service.tabClients', { count: clients.length }), icon: Users },
            { id: 'projects', label: t('business:service.tabProjects', { count: projects.length }), icon: FolderKanban },
            { id: 'invoices', label: t('business:service.tabInvoices', { count: invoices.length }), icon: FileText },
            { id: 'payroll', label: t('business:service.tabPayroll', { count: payroll.length }), icon: Briefcase },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`inline-flex items-center gap-2 px-3.5 py-2 text-xs font-medium rounded-lg whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-white dark:bg-[#1E293B] text-violet-700 dark:text-violet-300 shadow-xs'
                  : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5 text-violet-600 dark:text-violet-400" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {showAddClient && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (!cName.trim() || Number(cAgreed) <= 0) return;
            addClient({
              name: cName.trim(),
              contact: cContact.trim() || 'billing@client.example',
              serviceProvided: cService.trim() || 'Financial Advisory',
              projectTitle: cProject.trim() || 'Retainer Engagement',
              agreedAmount: Number(cAgreed),
              paidAmount: 0,
              paymentStatus: 'Pending',
              dueDate: cDue,
            });
            clearDraft(DRAFT_KEY);
            setCName('');
            setCContact('');
            setCService('');
            setCProject('');
            setCAgreed('');
            setShowAddClient(false);
          }}
          className="rounded-xl border border-violet-300/60 dark:border-violet-500/35 bg-white dark:bg-[#1E293B] p-5 space-y-3"
        >
          <div className="flex items-center justify-between text-xs">
            <span className="font-display font-semibold">{t('business:service.addClientTitle')}</span>
            {(cName || cAgreed) && (
              <button
                type="button"
                onClick={() => {
                  clearDraft(DRAFT_KEY);
                  setCName('');
                  setCContact('');
                  setCService('');
                  setCProject('');
                  setCAgreed('');
                }}
                className="inline-flex items-center gap-1 text-[11px] text-slate-500 hover:text-violet-600"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{t('business:product.clearDraft')}</span>
              </button>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
            <div>
              <label className="block text-xs text-slate-500 mb-1">{t('business:service.clientName')}</label>
              <input
                type="text"
                value={cName}
                onChange={(e) => setCName(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">{t('business:service.contactLabel')}</label>
              <input
                type="text"
                value={cContact}
                onChange={(e) => setCContact(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">{t('business:service.serviceProvided')}</label>
              <input
                type="text"
                value={cService}
                onChange={(e) => setCService(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">{t('business:service.agreedAmount')}</label>
              <input
                type="number"
                value={cAgreed}
                onChange={(e) => setCAgreed(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-500 mb-1">{t('business:service.dueDate')}</label>
              <input
                type="date"
                value={cDue}
                onChange={(e) => setCDue(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>
            <button
              type="submit"
              className={`px-4 py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}
            >
              {t('business:service.saveClient')}
            </button>
          </div>
        </form>
      )}

      {activeTab === 'clients' && (
        <>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setPayError(null);
              if (!effectivePayClientId || !Number.isFinite(Number(payAmount)) || Number(payAmount) <= 0) {
                setPayError(t('business:service.invalidPayment'));
                return;
              }
              recordClientPayment(effectivePayClientId, Number(payAmount));
              setPayAmount('');
            }}
            className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 flex flex-wrap items-center gap-3"
          >
            <div className="flex items-center gap-2 text-xs font-semibold">
              <DollarSign className="w-4 h-4 text-violet-600 dark:text-violet-400" />
              <span>{t('business:service.recordPayment')}:</span>
            </div>
            <select
              value={effectivePayClientId}
              onChange={(e) => setPayClientId(e.target.value)}
              className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] max-w-full"
            >
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({t('business:service.pendingLabel')}: {formatCurrency(Math.max(0, c.agreedAmount - c.paidAmount), cur)})
                </option>
              ))}
            </select>
            <input
              type="number"
              min={1}
              value={payAmount}
              onChange={(e) => setPayAmount(e.target.value)}
              placeholder={t('business:service.paymentAmountPlaceholder')}
              className="w-36 px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
            />
            <button
              type="submit"
              className={`px-4 py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}
            >
              {t('business:service.recordPayment')}
            </button>
            {payError && (
              <span className="text-xs text-red-600 dark:text-[#F87171]">{payError}</span>
            )}
          </form>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 dark:bg-[#172235] text-slate-500 dark:text-[#94A3B8] border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="text-start px-4 py-3 font-medium">{t('business:service.clientContactCol')}</th>
                  <th className="text-start px-4 py-3 font-medium">{t('business:service.serviceProjectCol')}</th>
                  <th className="text-end px-4 py-3 font-medium">{t('business:service.agreedCol')}</th>
                  <th className="text-end px-4 py-3 font-medium">{t('business:service.paidCol')}</th>
                  <th className="text-end px-4 py-3 font-medium">{t('business:service.pendingCol')}</th>
                  <th className="text-start px-4 py-3 font-medium">{t('business:service.dueDate')}</th>
                  <th className="text-start px-4 py-3 font-medium">{t('business:service.paymentStatus')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {clients.map((c) => {
                  const pending = Math.max(0, c.agreedAmount - c.paidAmount);
                  return (
                    <tr key={c.id}>
                      <td className="px-4 py-3">
                        <div className="font-semibold">{c.name}</div>
                        <div className="text-[11px] text-slate-500">{c.contact}</div>
                      </td>
                      <td className="px-4 py-3">
                        <div>{c.serviceProvided}</div>
                        <div className="text-[11px] text-slate-500">{c.projectTitle}</div>
                      </td>
                      <td className="px-4 py-3 text-end font-mono-nums">{formatCurrency(c.agreedAmount, cur)}</td>
                      <td className="px-4 py-3 text-end font-mono-nums text-emerald-600 dark:text-[#34D399]">
                        {formatCurrency(c.paidAmount, cur)}
                      </td>
                      <td className="px-4 py-3 text-end font-mono-nums font-semibold">
                        {formatCurrency(pending, cur)}
                      </td>
                      <td className="px-4 py-3 font-mono-nums text-slate-500">{formatDateShort(c.dueDate)}</td>
                      <td
                        className={`px-4 py-3 font-semibold ${
                          c.paymentStatus === 'Paid'
                            ? 'text-emerald-600 dark:text-[#34D399]'
                            : c.paymentStatus === 'Overdue'
                              ? 'text-red-600 dark:text-[#F87171]'
                              : 'text-amber-600 dark:text-[#FBBF24]'
                        }`}
                      >
                        {translateStatus(c.paymentStatus)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}

      {activeTab === 'projects' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 dark:bg-[#172235] text-slate-500 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="text-start px-4 py-3">{t('business:service.projectTitle')}</th>
                  <th className="text-start px-4 py-3">{t('business:service.projectClientCol')}</th>
                  <th className="text-end px-4 py-3">{t('business:service.milestoneValue')}</th>
                  <th className="text-end px-4 py-3">{t('business:service.directCost')}</th>
                  <th className="text-end px-4 py-3">{t('business:service.estMargin')}</th>
                  <th className="text-start px-4 py-3">{t('business:service.paymentStatus')}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {projects.map((prj) => {
                  const direct = prj.directCost ?? Math.round(prj.milestoneValue * 0.25);
                  const marginPct =
                    prj.milestoneValue > 0
                      ? Math.round(((prj.milestoneValue - direct) / prj.milestoneValue) * 100)
                      : 0;
                  return (
                    <tr key={prj.id}>
                      <td className="px-4 py-3 font-semibold">{prj.title}</td>
                      <td className="px-4 py-3 text-slate-500">{prj.clientName}</td>
                      <td className="px-4 py-3 text-end font-mono-nums">{formatCurrency(prj.milestoneValue, cur)}</td>
                      <td className="px-4 py-3 text-end font-mono-nums text-slate-500">{formatCurrency(direct, cur)}</td>
                      <td className="px-4 py-3 text-end font-mono-nums font-semibold text-emerald-600 dark:text-[#34D399]">
                        {marginPct}%
                      </td>
                      <td className="px-4 py-3">{translateStatus(prj.status)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!prjTitle.trim() || Number(prjMilestone) <= 0) return;
              const cli = clients.find((c) => c.id === effectivePrjClientId);
              addProject({
                clientId: effectivePrjClientId || 'custom',
                clientName: cli?.name || 'Direct Retainer',
                title: prjTitle.trim(),
                status: 'Active',
                startDate: new Date().toISOString().slice(0, 10),
                milestoneValue: Number(prjMilestone),
                directCost: Number(prjDirectCost) || 0,
              });
              setPrjTitle('');
              setPrjMilestone('');
              setPrjDirectCost('');
            }}
            className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3"
          >
            <h3 className="font-display font-semibold text-sm">{t('business:service.addProjectTitle')}</h3>
            <select
              value={effectivePrjClientId}
              onChange={(e) => setPrjClientId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
            <input
              type="text"
              value={prjTitle}
              onChange={(e) => setPrjTitle(e.target.value)}
              placeholder={t('business:service.projectTitle')}
              required
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                value={prjMilestone}
                onChange={(e) => setPrjMilestone(e.target.value)}
                placeholder={t('business:service.feeValuePlaceholder')}
                required
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
              />
              <input
                type="number"
                value={prjDirectCost}
                onChange={(e) => setPrjDirectCost(e.target.value)}
                placeholder={t('business:service.directCostPlaceholder')}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
              />
            </div>
            <button type="submit" className={`w-full py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}>
              {t('business:service.createProject')}
            </button>
          </form>
        </div>
      )}

      {activeTab === 'invoices' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-slate-50 dark:bg-[#172235] text-slate-500 border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="text-start px-4 py-3">{t('business:service.invoiceNumber')}</th>
                  <th className="text-start px-4 py-3">{t('business:service.clientProjectCol')}</th>
                  <th className="text-end px-4 py-3">{t('finance:form.amount', { defaultValue: 'Amount' })}</th>
                  <th className="text-start px-4 py-3">{t('business:service.paymentStatus')}</th>
                  <th className="text-end px-4 py-3">{t('finance:table.actions', { defaultValue: 'Actions' })}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {invoices.map((inv) => (
                  <tr key={inv.id}>
                    <td className="px-4 py-3 font-mono-nums font-semibold">{inv.invoiceNumber}</td>
                    <td className="px-4 py-3">
                      <div className="font-medium">{inv.clientName}</div>
                      <div className="text-[11px] text-slate-500">
                        {inv.projectTitle} · {t('business:service.dueDate')}: {formatDateShort(inv.dueDate)}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-end font-mono-nums font-semibold">{formatCurrency(inv.amount, cur)}</td>
                    <td className="px-4 py-3">{translateStatus(inv.status)}</td>
                    <td className="px-4 py-3 text-end">
                      <div className="inline-flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setPreviewInvoice(inv)}
                          className="px-2.5 py-1 text-[11px] rounded border border-slate-300 dark:border-slate-700 hover:border-violet-500 whitespace-nowrap"
                        >
                          {t('business:service.viewReceipt')}
                        </button>
                        {inv.status !== 'Paid' && (
                          <button
                            type="button"
                            onClick={() => markInvoicePaid(inv.id)}
                            className="px-2.5 py-1 text-[11px] font-semibold rounded bg-emerald-600 text-white whitespace-nowrap"
                          >
                            {t('business:service.markPaid')}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!invDesc.trim() || Number(invAmt) <= 0) return;
              const cli = clients.find((c) => c.id === effectiveInvClientId);
              const val = Number(invAmt);
              createInvoice({
                invoiceNumber: `FX-INV-${new Date().getFullYear()}-${String(invoices.length + 101)}`,
                clientId: effectiveInvClientId || 'custom',
                clientName: cli?.name || 'Retainer Client',
                projectTitle: cli?.projectTitle || 'Advisory Milestone',
                issueDate: new Date().toISOString().slice(0, 10),
                dueDate: invDue,
                amount: val,
                paidAmount: 0,
                status: 'Pending',
                lineItems: [{ description: invDesc.trim(), amount: val }],
              });
              setInvDesc('');
              setInvAmt('');
            }}
            className="lg:col-span-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3"
          >
            <h3 className="font-display font-semibold text-sm">{t('business:service.generateInvoiceTitle')}</h3>
            <select
              value={effectiveInvClientId}
              onChange={(e) => setInvClientId(e.target.value)}
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            >
              {clients.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
            <input
              type="text"
              value={invDesc}
              onChange={(e) => setInvDesc(e.target.value)}
              placeholder={t('business:service.lineItemPlaceholder')}
              required
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="number"
                value={invAmt}
                onChange={(e) => setInvAmt(e.target.value)}
                placeholder={t('business:service.agreedAmount')}
                required
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
              />
              <input
                type="date"
                value={invDue}
                onChange={(e) => setInvDue(e.target.value)}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>
            <button type="submit" className={`w-full py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}>
              {t('business:service.issueInvoice')}
            </button>
          </form>
        </div>
      )}

      {activeTab === 'payroll' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-4">
            <h3 className="font-display font-semibold text-sm">{t('business:service.payrollLedgerTitle')}</h3>
            {payroll.map((p) => (
              <div key={p.id} className="flex flex-wrap items-center justify-between gap-2 text-xs py-2 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <div className="font-semibold">{p.memberName}</div>
                  <div className="text-[11px] text-slate-500">{p.role} · {p.period}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-mono-nums font-semibold">{formatCurrency(p.amount, cur)}</span>
                  <button
                    type="button"
                    onClick={() => togglePayrollStatus(p.id)}
                    className="inline-flex items-center gap-1 px-2.5 py-1 rounded border border-slate-200 dark:border-slate-700"
                  >
                    <CheckCircle2 className="w-3 h-3 text-violet-600 dark:text-violet-400" />
                    <span>{translateStatus(p.status)}</span>
                  </button>
                </div>
              </div>
            ))}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!memberName.trim() || Number(memberAmt) <= 0) return;
                addPayrollRecord({
                  memberName: memberName.trim(),
                  role: memberRole.trim() || 'Consultant',
                  amount: Number(memberAmt),
                  period: new Date().toISOString().slice(0, 7),
                  status: 'Scheduled',
                });
                setMemberName('');
                setMemberAmt('');
              }}
              className="grid grid-cols-1 sm:grid-cols-4 gap-2 pt-2"
            >
              <input
                type="text"
                value={memberName}
                onChange={(e) => setMemberName(e.target.value)}
                placeholder={t('business:service.memberPlaceholder')}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
              <input
                type="text"
                value={memberRole}
                onChange={(e) => setMemberRole(e.target.value)}
                placeholder={t('business:service.rolePlaceholder')}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
              <input
                type="number"
                value={memberAmt}
                onChange={(e) => setMemberAmt(e.target.value)}
                placeholder={t('business:service.payAmountPlaceholder')}
                className="px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
              />
              <button type="submit" className={`px-3 py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}>
                {t('business:service.schedulePay')}
              </button>
            </form>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 space-y-3">
            <h3 className="font-display font-semibold text-sm">{t('business:service.opExTitle')}</h3>
            <div className="space-y-2">
              {serviceExpenses.map((e) => (
                <div key={e.id} className="flex items-center justify-between gap-2 text-xs py-1.5 border-b border-slate-100 dark:border-slate-800">
                  <span className="truncate">{e.description} · {formatDateShort(e.date)}</span>
                  <span className="font-mono-nums font-semibold shrink-0">{formatCurrency(e.amount, cur)}</span>
                </div>
              ))}
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!expDesc.trim() || Number(expAmt) <= 0) return;
                addBusinessExpense({
                  domain: 'service',
                  category: 'Operating Expense',
                  description: expDesc.trim(),
                  amount: Number(expAmt),
                  date: new Date().toISOString().slice(0, 10),
                });
                setExpDesc('');
                setExpAmt('');
              }}
              className="flex flex-wrap gap-2 pt-2"
            >
              <input
                type="text"
                value={expDesc}
                onChange={(e) => setExpDesc(e.target.value)}
                placeholder={t('business:service.opExPlaceholder')}
                className="flex-1 min-w-[160px] px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
              <input
                type="number"
                value={expAmt}
                onChange={(e) => setExpAmt(e.target.value)}
                placeholder={t('business:service.agreedAmount')}
                className="w-24 px-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] font-mono-nums"
              />
              <button
                type="submit"
                className="px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:border-violet-500"
              >
                {t('common:actions.add')}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Printable In-App Invoice Receipt Preview Modal */}
      {previewInvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/65 p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-lg rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] p-6 space-y-5 shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <div className="text-xs font-semibold text-violet-600 dark:text-violet-400">
                  {activeWorkspace?.name || 'FinX'} · {t('business:service.receiptHeader')}
                </div>
                <h3 className="font-display font-bold text-xl mt-0.5">{previewInvoice.invoiceNumber}</h3>
              </div>
              <button
                type="button"
                onClick={() => setPreviewInvoice(null)}
                aria-label={t('common:actions.close')}
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <div className="text-slate-500">{t('business:service.billedTo')}</div>
                <div className="font-semibold text-sm mt-0.5">{previewInvoice.clientName}</div>
                <div className="text-slate-500">{previewInvoice.projectTitle}</div>
              </div>
              <div className="text-end font-mono-nums">
                <div>{t('business:service.issued')}: {formatDateShort(previewInvoice.issueDate)}</div>
                <div>{t('business:service.dueDate')}: {formatDateShort(previewInvoice.dueDate)}</div>
                <div className="mt-1 font-semibold text-violet-600 dark:text-violet-400">
                  {t('business:service.paymentStatus')}: {translateStatus(previewInvoice.status)}
                </div>
              </div>
            </div>

            <div className="border-y border-slate-200 dark:border-slate-800 py-3 space-y-2 text-xs">
              {previewInvoice.lineItems.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between">
                  <span>{item.description}</span>
                  <span className="font-mono-nums font-semibold">{formatCurrency(item.amount, cur)}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between text-sm font-bold">
              <span>{t('business:service.totalInvoiceAmount')}</span>
              <span className="font-mono-nums">{formatCurrency(previewInvoice.amount, cur)}</span>
            </div>

            <div className="flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{t('business:service.printReceiptBtn')}</span>
              </button>
              <button
                type="button"
                onClick={() => setPreviewInvoice(null)}
                className={`px-4 py-2 text-xs font-semibold rounded-lg ${domainTheme.buttonBgClass}`}
              >
                {t('common:actions.close')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
