import React, { useMemo, useState } from 'react';
import {
  ArrowUpRight,
  Bot,
  Briefcase,
  Building2,
  CalendarRange,
  FileSearch,
  Plus,
  Sparkles,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { DomainLogoEmblem3D } from '../components/DomainBrand3D';
import { StatCard } from '../components/StatCard';
import { UserAvatar } from '../components/UserAvatar';
import { getLocalizedDomainTheme } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import { intelligenceService } from '../services/intelligenceService';
import { DomainId } from '../types/finx';
import { formatCurrency, formatDateShort } from '../utils/formatters';

export const DashboardPage: React.FC = () => {
  const { t } = useTranslation(['dashboard', 'common']);
  const {
    session,
    activeWorkspace,
    navigate,
    openAssistant,
    setYtdDrawerOpen,
    seedSampleWorkspaceData,
    transactions,
    budgets,
    products,
    clients,
    messages,
    metrics,
    languagePrefs,
    settings,
  } = useFinX();

  const [dateRange, setDateRange] = useState<'this-month' | '3-months' | 'ytd'>('this-month');
  const [seeding, setSeeding] = useState(false);

  const enabledDomains: DomainId[] = session?.user.enabledDomains || [
    'personal-finance',
    'product-business',
    'service-business',
    'investment-knowledge',
    'financial-intelligence',
  ];

  const isEmptyRealWorkspace =
    session?.authMode !== 'demo-local' &&
    transactions.length === 0 &&
    products.length === 0 &&
    clients.length === 0;

  const { activeMonthPrefix, recent3MonthPrefixes } = useMemo(() => {
    const months = Array.from(new Set(transactions.map((tx) => tx.date.slice(0, 7)))).sort((a, b) =>
      b.localeCompare(a)
    );
    const nowMonth = new Date().toISOString().slice(0, 7);
    const active = months.includes(nowMonth) ? nowMonth : months[0] || nowMonth;
    const recent3 = new Set(months.slice(0, 3));
    recent3.add(nowMonth);
    return { activeMonthPrefix: active, recent3MonthPrefixes: recent3 };
  }, [transactions]);

  const filteredTx = useMemo(() => {
    if (dateRange === 'this-month') {
      return transactions.filter((tx) => tx.date.startsWith(activeMonthPrefix));
    }
    if (dateRange === '3-months') {
      return transactions.filter((tx) => recent3MonthPrefixes.has(tx.date.slice(0, 7)));
    }
    return transactions;
  }, [activeMonthPrefix, dateRange, recent3MonthPrefixes, transactions]);

  const periodTotals = useMemo(() => {
    const income = filteredTx.filter((tItem) => tItem.type === 'income').reduce((s, tItem) => s + tItem.amount, 0);
    const expenses = filteredTx.filter((tItem) => tItem.type === 'expense').reduce((s, tItem) => s + tItem.amount, 0);
    const net = income - expenses;
    const rate = income > 0 ? Math.round((net / income) * 1000) / 10 : 0;
    return { income, expenses, net, rate };
  }, [filteredTx]);

  const activityChartData = useMemo(() => {
    const byMonth: Record<string, { month: string; income: number; expenses: number }> = {};
    transactions.forEach((tx) => {
      const key = tx.date.slice(0, 7);
      if (!byMonth[key]) {
        byMonth[key] = { month: key, income: 0, expenses: 0 };
      }
      if (tx.type === 'income') byMonth[key].income += tx.amount;
      else byMonth[key].expenses += tx.amount;
    });
    return Object.entries(byMonth)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([, val]) => val);
  }, [transactions]);

  const ruleInsights = useMemo(
    () =>
      intelligenceService.generateRuleBasedInsights({
        transactions,
        budgets,
        products,
        clients,
        metrics,
      }),
    [budgets, clients, metrics, products, transactions]
  );

  const cur = languagePrefs.displayCurrency;

  return (
    <div className="space-y-6">
      {/* Personalized Header & Date Filter */}
      <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
          {session && (
            <UserAvatar user={session.user} size="lg" />
          )}
          <div className="min-w-0">
            <div className="text-xs font-medium text-teal-600 dark:text-[#14B8A6] flex flex-wrap items-center gap-2">
              <span>{activeWorkspace?.name || session?.user.businessName || t('common:header.finxWorkspace')}</span>
              <span aria-hidden="true">·</span>
              <span>
                {session?.authMode === 'demo-local'
                  ? t('common:header.localDemoSandbox')
                  : t('common:header.cloudFirestoreSynced')}
              </span>
            </div>
            <h2 className="font-display font-bold text-lg sm:text-2xl text-slate-900 dark:text-[#F8FAFC] truncate mt-0.5">
              {t('dashboard:greeting', { name: session?.user.name || t('common:brandName') })}
            </h2>
            <p className="mt-0.5 text-xs sm:text-sm text-slate-600 dark:text-[#94A3B8]">
              {t('dashboard:subtitle')}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setYtdDrawerOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-teal-500/40 text-teal-700 dark:text-[#22D3EE] bg-teal-500/10 hover:bg-teal-500/20 transition-colors"
          >
            <CalendarRange className="w-3.5 h-3.5" />
            <span>{t('common:header.ytdButton')}</span>
          </button>

          <div className="inline-flex flex-wrap items-center p-1 rounded-lg bg-slate-200/70 dark:bg-[#172235] border border-slate-200 dark:border-slate-800">
            {(
              [
                { id: 'this-month', label: t('dashboard:dateFilter.thisMonth') },
                { id: '3-months', label: t('dashboard:dateFilter.last3Months') },
                { id: 'ytd', label: t('dashboard:dateFilter.yearToDate') },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setDateRange(item.id)}
                className={`px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                  dateRange === item.id
                    ? 'bg-white dark:bg-[#1E293B] text-slate-900 dark:text-[#F8FAFC] shadow-xs'
                    : 'text-slate-600 dark:text-[#94A3B8] hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Empty Real Account Quick-Start Card */}
      {isEmptyRealWorkspace && (
        <div className="rounded-2xl border border-teal-500/35 bg-gradient-to-r from-teal-50 via-cyan-50/70 to-white dark:from-[#0B232D] dark:via-[#112438] dark:to-[#172235] p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-700 dark:text-[#22D3EE]">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t('dashboard:empty.cloudCleanTitle')}</span>
            </div>
            <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
              {t('dashboard:empty.cloudCleanHeadline')}
            </h3>
            <p className="text-xs text-slate-600 dark:text-[#94A3B8]">
              {t('dashboard:empty.cloudCleanDesc')}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => navigate('personal-finance')}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950"
            >
              {t('dashboard:empty.addFirstTx')}
            </button>
            <button
              type="button"
              disabled={seeding}
              onClick={async () => {
                setSeeding(true);
                await seedSampleWorkspaceData();
                setSeeding(false);
              }}
              className="px-3.5 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-600 hover:border-teal-500 disabled:opacity-50"
            >
              {seeding ? t('dashboard:empty.loadingSample') : t('dashboard:empty.loadSample')}
            </button>
          </div>
        </div>
      )}

      {/* Primary KPI Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          label={t('dashboard:kpi.totalIncome')}
          value={formatCurrency(periodTotals.income, cur)}
          helperText={t('dashboard:kpi.helperIncome')}
          tone="positive"
          onClick={() => navigate('personal-finance')}
        />
        <StatCard
          label={t('dashboard:kpi.totalExpenses')}
          value={formatCurrency(periodTotals.expenses, cur)}
          helperText={t('dashboard:kpi.helperExpenses')}
          tone="neutral"
          onClick={() => navigate('personal-finance')}
        />
        <StatCard
          label={t('dashboard:kpi.availableBalance')}
          value={formatCurrency(periodTotals.net, cur)}
          helperText={t('dashboard:kpi.helperNet')}
          tone={periodTotals.net >= 0 ? 'positive' : 'negative'}
          onClick={() => navigate('reports')}
        />
        <StatCard
          label={t('dashboard:kpi.monthlySavings')}
          value={`${periodTotals.rate}%`}
          helperText={t('dashboard:kpi.helperSavings')}
          tone={periodTotals.rate >= 20 ? 'positive' : 'warning'}
          onClick={() => navigate('planner')}
        />
      </div>

      {/* Active Domain Workspaces Strip (3D Emblems + Distinct Domain Identity) */}
      <div className="space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-display font-semibold text-xs uppercase tracking-wider text-slate-500 dark:text-[#94A3B8]">
            {t('dashboard:sections.activeDomains', { count: enabledDomains.length })}
          </h3>
          <button
            type="button"
            onClick={() => navigate('settings')}
            className="text-xs font-medium text-teal-600 dark:text-[#14B8A6] hover:underline"
          >
            {t('dashboard:sections.customizeDomains')}
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-3">
          {enabledDomains.map((domId) => {
            const themeCfg = getLocalizedDomainTheme(domId);
            return (
              <button
                key={domId}
                type="button"
                onClick={() => navigate(domId)}
                className={`p-3.5 rounded-xl border ${themeCfg.borderAccentClass} bg-white dark:bg-[#1E293B] hover:shadow-md transition-all text-start flex items-center gap-3 group`}
              >
                <DomainLogoEmblem3D domain={domId} reducedMotion={settings.reducedMotion} size="sm" />
                <div className="min-w-0">
                  <div className={`text-[11px] font-semibold ${themeCfg.accentTextClass}`}>
                    {themeCfg.shortLabel}
                  </div>
                  <div className="text-xs font-medium text-slate-700 dark:text-[#F8FAFC] truncate mt-0.5 group-hover:underline">
                    {t('dashboard:sections.openWorkspace')}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Quick Actions Strip */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 flex flex-wrap items-center justify-between gap-3">
        <span className="text-xs font-semibold text-slate-600 dark:text-[#94A3B8]">
          {t('dashboard:sections.quickActions')}
        </span>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => navigate('personal-finance')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 hover:border-teal-500 transition-colors whitespace-nowrap"
          >
            <Plus className="w-3.5 h-3.5 text-teal-600 dark:text-[#14B8A6]" />
            <span>{t('dashboard:quickActionLabels.addExpense')}</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('product-business')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 hover:border-teal-500 transition-colors whitespace-nowrap"
          >
            <Building2 className="w-3.5 h-3.5 text-teal-600 dark:text-[#14B8A6]" />
            <span>{t('dashboard:quickActionLabels.recordSale')}</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('service-business')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 hover:border-teal-500 transition-colors whitespace-nowrap"
          >
            <Briefcase className="w-3.5 h-3.5 text-teal-600 dark:text-[#14B8A6]" />
            <span>{t('dashboard:quickActionLabels.recordClientPayment')}</span>
          </button>
          <button
            type="button"
            onClick={() => navigate('documents')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700 hover:border-teal-500 transition-colors whitespace-nowrap"
          >
            <FileSearch className="w-3.5 h-3.5 text-teal-600 dark:text-[#14B8A6]" />
            <span>{t('dashboard:quickActionLabels.analyzeDocument')}</span>
          </button>
          <button
            type="button"
            onClick={() => openAssistant('finance-assistant')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 hover:bg-teal-700 dark:hover:bg-[#22D3EE] transition-colors whitespace-nowrap"
          >
            <Bot className="w-3.5 h-3.5" />
            <span>{t('dashboard:quickActionLabels.askAssistant')}</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Chart + Business Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-semibold text-sm text-slate-900 dark:text-[#F8FAFC]">
              {t('dashboard:sections.activityChart')}
            </h3>
            <button
              type="button"
              onClick={() => navigate('reports')}
              className="inline-flex items-center gap-1 text-xs font-medium text-teal-600 dark:text-[#14B8A6] hover:underline"
            >
              <span>{t('common:nav.reports')}</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="h-64">
            {activityChartData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-center px-4 text-xs text-slate-500 dark:text-[#94A3B8]">
                {t('dashboard:empty.chartEmpty')}
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={activityChartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
                  <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#94A3B8' }} />
                  <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#172235',
                      borderColor: '#334155',
                      borderRadius: 8,
                      color: '#F8FAFC',
                      fontSize: 12,
                    }}
                  />
                  <Bar
                    dataKey="income"
                    name={t('dashboard:labels.incomeSeries')}
                    fill="#14B8A6"
                    radius={[4, 4, 0, 0]}
                  />
                  <Bar
                    dataKey="expenses"
                    name={t('dashboard:labels.expensesSeries')}
                    fill="#22D3EE"
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Business Overview + AI Insights */}
        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-5">
            <h3 className="font-display font-semibold text-sm text-slate-900 dark:text-[#F8FAFC] mb-4">
              {t('dashboard:sections.businessOverview')}
            </h3>
            <div className="space-y-3">
              <button
                type="button"
                onClick={() => navigate('product-business')}
                className="w-full p-3.5 rounded-lg border border-slate-200 dark:border-slate-700/80 hover:border-orange-500/60 flex items-center justify-between gap-2 text-start transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    {t('common:nav.productBusiness')}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-[#94A3B8] mt-0.5 truncate">
                    {t('dashboard:labels.skusCount', { count: products.length })} ·{' '}
                    {t('dashboard:labels.netProfitLabel')} {formatCurrency(metrics.productNetProfit, cur)}
                  </div>
                </div>
                <span className="font-mono-nums text-sm font-bold text-orange-600 dark:text-orange-400 shrink-0">
                  {formatCurrency(metrics.productRevenue, cur)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => navigate('service-business')}
                className="w-full p-3.5 rounded-lg border border-slate-200 dark:border-slate-700/80 hover:border-violet-500/60 flex items-center justify-between gap-2 text-start transition-colors"
              >
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    {t('common:nav.serviceBusiness')}
                  </div>
                  <div className="text-xs text-slate-500 dark:text-[#94A3B8] mt-0.5 truncate">
                    {t('dashboard:labels.pendingLabel')}{' '}
                    {formatCurrency(metrics.servicePendingReceivables, cur)} ·{' '}
                    {t('dashboard:labels.clientsCount', { count: clients.length })}
                  </div>
                </div>
                <span className="font-mono-nums text-sm font-bold text-violet-600 dark:text-violet-400 shrink-0">
                  {formatCurrency(metrics.serviceCollectedRevenue, cur)}
                </span>
              </button>
            </div>
          </div>

          <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display font-semibold text-sm text-slate-900 dark:text-[#F8FAFC]">
                {t('dashboard:sections.aiInsights')}
              </h3>
              <button
                type="button"
                onClick={() => navigate('financial-intelligence')}
                className="text-xs font-medium text-teal-600 dark:text-[#14B8A6] hover:underline"
              >
                {t('common:nav.financialIntelligence')}
              </button>
            </div>
            <div className="space-y-2.5">
              {ruleInsights.slice(0, 3).map((ins) => (
                <button
                  key={ins.id}
                  type="button"
                  onClick={() => navigate('financial-intelligence')}
                  className="w-full text-start p-2.5 rounded-lg bg-slate-50 dark:bg-[#172235] hover:bg-slate-100 dark:hover:bg-[#172235]/80 transition-colors"
                >
                  <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                    {ins.title}
                  </div>
                  <div className="text-[11px] text-slate-500 dark:text-[#94A3B8] mt-0.5">
                    {ins.domain} · {ins.explanation}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row: Budget Progress, Recent Transactions, FinX Messages */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-semibold text-sm">{t('dashboard:sections.budgetProgress')}</h3>
            <button
              type="button"
              onClick={() => navigate('personal-finance')}
              className="text-xs text-teal-600 dark:text-[#14B8A6] hover:underline"
            >
              {t('common:actions.manage')}
            </button>
          </div>
          {budgets.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-[#94A3B8]">
              {t('dashboard:empty.budgetsEmpty')}
            </p>
          ) : (
            <div className="space-y-3.5">
              {budgets.slice(0, 4).map((b) => {
                const spent = transactions
                  .filter(
                    (tx) =>
                      tx.type === 'expense' &&
                      tx.category === b.category &&
                      tx.date.startsWith(activeMonthPrefix)
                  )
                  .reduce((s, tx) => s + tx.amount, 0);
                const pct =
                  b.monthlyLimit > 0 ? Math.min(100, Math.round((spent / b.monthlyLimit) * 100)) : 0;
                const warn = pct >= b.alertThresholdPercent;
                return (
                  <div key={b.id}>
                    <div className="flex items-center justify-between text-xs mb-1 gap-2">
                      <span className="font-medium truncate">{b.category}</span>
                      <span className="font-mono-nums text-slate-500 dark:text-[#94A3B8] shrink-0">
                        {formatCurrency(spent, cur)} / {formatCurrency(b.monthlyLimit, cur)} ({pct}%)
                      </span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-100 dark:bg-[#101827] overflow-hidden">
                      <div
                        style={{ width: `${pct}%` }}
                        className={`h-full rounded-full ${
                          pct >= 100
                            ? 'bg-red-500 dark:bg-[#F87171]'
                            : warn
                              ? 'bg-amber-500 dark:bg-[#FBBF24]'
                              : 'bg-teal-600 dark:bg-[#14B8A6]'
                        }`}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-semibold text-sm">{t('dashboard:sections.recentTransactions')}</h3>
            <button
              type="button"
              onClick={() => navigate('personal-finance')}
              className="text-xs text-teal-600 dark:text-[#14B8A6] hover:underline"
            >
              {t('common:actions.viewAll')}
            </button>
          </div>
          {filteredTx.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-[#94A3B8]">
              {t('dashboard:empty.txEmpty')}
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredTx.slice(0, 5).map((tx) => (
                <button
                  key={tx.id}
                  type="button"
                  onClick={() => navigate('personal-finance')}
                  className="w-full py-2.5 flex items-center justify-between gap-2 text-start hover:opacity-85"
                >
                  <div className="min-w-0">
                    <div className="text-xs font-medium truncate">{tx.description}</div>
                    <div className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                      {tx.category} · {formatDateShort(tx.date)}
                    </div>
                  </div>
                  <span
                    className={`font-mono-nums text-xs font-semibold shrink-0 ${
                      tx.type === 'income'
                        ? 'text-emerald-600 dark:text-[#34D399]'
                        : 'text-slate-800 dark:text-[#F8FAFC]'
                    }`}
                  >
                    {tx.type === 'income' ? '+' : '-'}
                    {formatCurrency(tx.amount, cur)}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-4 sm:p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display font-semibold text-sm">{t('dashboard:sections.notifications')}</h3>
            <button
              type="button"
              onClick={() => navigate('messages')}
              className="text-xs text-teal-600 dark:text-[#14B8A6] hover:underline"
            >
              {t('common:nav.messages')}
            </button>
          </div>
          {messages.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-[#94A3B8]">
              {t('dashboard:empty.messagesEmpty')}
            </p>
          ) : (
            <div className="space-y-2.5">
              {messages.slice(0, 4).map((msg) => (
                <button
                  key={msg.id}
                  type="button"
                  onClick={() => navigate('messages')}
                  className="w-full p-2.5 rounded-lg bg-slate-50 dark:bg-[#172235] text-start hover:bg-slate-100 dark:hover:bg-[#172235]/80"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold truncate">{msg.title}</span>
                    {!msg.read && (
                      <span className="text-[10px] font-semibold text-teal-600 dark:text-[#22D3EE] shrink-0">
                        {t('dashboard:labels.unread')}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 dark:text-[#94A3B8] mt-0.5 line-clamp-2">
                    {msg.content}
                  </p>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
