import React from 'react';
import { Download } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { StatCard } from '../components/StatCard';
import { getLocalizedDomainTheme } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import { downloadTextFile, formatCurrency } from '../utils/formatters';

export const ReportsAnalyticsPage: React.FC = () => {
  const { t } = useTranslation(['business', 'common']);
  const { metrics, transactions, products, clients, languagePrefs } = useFinX();
  const cur = languagePrefs.displayCurrency;

  const domainComparison = [
    {
      domain: getLocalizedDomainTheme('personal-finance').label,
      inflow: metrics.personalIncome,
      outflow: metrics.personalExpenses,
      net: metrics.personalNetSavings,
    },
    {
      domain: getLocalizedDomainTheme('product-business').label,
      inflow: metrics.productRevenue,
      outflow: metrics.productCOGS + metrics.productOperatingExpenses,
      net: metrics.productNetProfit,
    },
    {
      domain: getLocalizedDomainTheme('service-business').label,
      inflow: metrics.serviceCollectedRevenue,
      outflow: metrics.serviceExpensesAndPayroll,
      net: metrics.serviceNetProfit,
    },
  ];

  const handleExportCsv = () => {
    const header = 'Domain,Inflow,Outflow,Net\n';
    const rows = domainComparison
      .map((r) => `"${r.domain}",${r.inflow.toFixed(2)},${r.outflow.toFixed(2)},${r.net.toFixed(2)}`)
      .join('\n');
    downloadTextFile('finx-financial-report.csv', header + rows, 'text/csv;charset=utf-8');
  };

  const handleExportJson = () => {
    const payload = {
      generatedAt: new Date().toISOString(),
      displayCurrency: cur,
      summary: metrics,
      counts: {
        transactions: transactions.length,
        products: products.length,
        clients: clients.length,
      },
      domainComparison,
    };
    downloadTextFile(
      'finx-financial-report.json',
      JSON.stringify(payload, null, 2),
      'application/json'
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display font-bold text-2xl">{t('common:nav.reports')}</h2>
          <p className="text-sm text-slate-600 dark:text-[#94A3B8] mt-1">
            {t('business:extraPages.reportsSubtitle')}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 hover:border-teal-500"
          >
            <Download className="w-3.5 h-3.5 text-teal-600 dark:text-[#14B8A6]" />
            <span>{t('common:actions.exportCsv')}</span>
          </button>
          <button
            type="button"
            onClick={handleExportJson}
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t('common:actions.exportJson')}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard
          label={t('business:intelligence.combinedInflow')}
          value={formatCurrency(metrics.combinedGrossInflow, cur)}
          tone="positive"
        />
        <StatCard
          label={t('business:intelligence.combinedNet')}
          value={formatCurrency(metrics.combinedNetPosition, cur)}
          tone={metrics.combinedNetPosition >= 0 ? 'positive' : 'negative'}
        />
        <StatCard
          label={t('business:extraPages.reportsInvReceivables')}
          value={formatCurrency(
            metrics.inventoryValuationAtCost + metrics.servicePendingReceivables,
            cur
          )}
        />
      </div>

      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5">
        <h3 className="font-display font-semibold text-sm mb-4">
          {t('business:extraPages.reportsChartTitle')}
        </h3>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={domainComparison}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,0.2)" />
              <XAxis dataKey="domain" tick={{ fontSize: 12, fill: '#94A3B8' }} />
              <YAxis tick={{ fontSize: 12, fill: '#94A3B8' }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#172235',
                  borderColor: '#334155',
                  borderRadius: 8,
                  color: '#F8FAFC',
                  fontSize: 12,
                }}
              />
              <Bar dataKey="inflow" name={t('business:extraPages.reportsInflow')} fill="#14B8A6" radius={[4, 4, 0, 0]} />
              <Bar dataKey="outflow" name={t('business:extraPages.reportsOutflow')} fill="#FBBF24" radius={[4, 4, 0, 0]} />
              <Bar dataKey="net" name={t('business:extraPages.reportsNet')} fill="#22D3EE" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
