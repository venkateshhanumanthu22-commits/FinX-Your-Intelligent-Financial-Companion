import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  BarChart3,
  Bell,
  BookOpen,
  Bot,
  Briefcase,
  Building2,
  CalendarClock,
  CalendarRange,
  ChevronLeft,
  ChevronRight,
  FileSearch,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageSquareText,
  Mic,
  PieChart,
  Plus,
  Puzzle,
  Search,
  Settings,
  Shield,
  Sparkles,
  Wallet,
  X,
} from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { FinXLogo } from '../components/FinXLogo';
import { SearchableLanguageSelector } from '../components/SearchableLanguageSelector';
import { ThemeToggle } from '../components/ThemeToggle';
import { UserAvatar } from '../components/UserAvatar';
import { getLocalizedDomainTheme } from '../config/domainThemes';
import { useFinX } from '../context/FinXContext';
import { ALL_DOMAIN_IDS } from '../services/firestoreRepository';
import { AppRoute, DomainId } from '../types/finx';
import { formatCurrency } from '../utils/formatters';

interface NavItemDef {
  route: AppRoute;
  labelKey: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: number;
  domainId?: DomainId;
}

export const DashboardLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { t } = useTranslation('common');
  const {
    route,
    navigate,
    goBack,
    canGoBack,
    session,
    logout,
    unreadCount,
    openAssistant,
    languagePrefs,
    setUnifiedLanguage,
    transactions,
    products,
    clients,
    messages,
    workspaces,
    activeWorkspace,
    switchWorkspace,
    createWorkspace,
    setYtdDrawerOpen,
    postLoginGreeting,
    dismissPostLoginGreeting,
  } = useFinX();

  const [sidebarExpanded, setSidebarExpanded] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  const [newWsModalOpen, setNewWsModalOpen] = useState(false);
  const [newWsName, setNewWsName] = useState('');
  const [newWsDomain, setNewWsDomain] = useState<DomainId>('product-business');

  const enabledDomainsSet = useMemo(
    () => new Set<DomainId>(session?.user.enabledDomains || ALL_DOMAIN_IDS),
    [session?.user.enabledDomains]
  );

  const allNavItems: NavItemDef[] = useMemo(
    () => [
      { route: 'dashboard', labelKey: 'nav.dashboard', icon: LayoutDashboard },
      { route: 'personal-finance', labelKey: 'nav.personalFinance', icon: Wallet, domainId: 'personal-finance' },
      { route: 'product-business', labelKey: 'nav.productBusiness', icon: Building2, domainId: 'product-business' },
      { route: 'service-business', labelKey: 'nav.serviceBusiness', icon: Briefcase, domainId: 'service-business' },
      { route: 'investment-knowledge', labelKey: 'nav.investmentKnowledge', icon: GraduationCap, domainId: 'investment-knowledge' },
      { route: 'financial-intelligence', labelKey: 'nav.financialIntelligence', icon: BarChart3, domainId: 'financial-intelligence' },
      { route: 'assistant', labelKey: 'nav.assistant', icon: Bot },
      { route: 'messages', labelKey: 'nav.messages', icon: MessageSquareText, badge: unreadCount },
      { route: 'documents', labelKey: 'nav.documents', icon: FileSearch },
      { route: 'planner', labelKey: 'nav.planner', icon: CalendarClock },
      { route: 'extensions', labelKey: 'nav.extensions', icon: Puzzle },
      { route: 'learning', labelKey: 'nav.learning', icon: BookOpen },
      { route: 'reports', labelKey: 'nav.reports', icon: PieChart },
      { route: 'security', labelKey: 'nav.security', icon: Shield },
      { route: 'settings', labelKey: 'nav.settings', icon: Settings },
    ],
    [unreadCount]
  );

  const navItems = useMemo(
    () => allNavItems.filter((item) => !item.domainId || enabledDomainsSet.has(item.domainId)),
    [allNavItems, enabledDomainsSet]
  );

  const globalSearchResults = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return [];
    const results: Array<{ id: string; title: string; subtitle: string; route: AppRoute }> = [];

    navItems.forEach((item) => {
      const label = t(item.labelKey);
      if (label.toLowerCase().includes(q)) {
        results.push({ id: `nav-${item.route}`, title: label, subtitle: t('header.navigation'), route: item.route });
      }
    });

    transactions.forEach((tx) => {
      if (tx.description.toLowerCase().includes(q) || tx.category.toLowerCase().includes(q)) {
        results.push({
          id: tx.id,
          title: tx.description,
          subtitle: `${t('nav.personalFinance')} · ${formatCurrency(tx.amount, languagePrefs.displayCurrency)}`,
          route: 'personal-finance',
        });
      }
    });

    products.forEach((prod) => {
      if (prod.name.toLowerCase().includes(q) || prod.productCode.toLowerCase().includes(q)) {
        results.push({
          id: prod.id,
          title: prod.name,
          subtitle: `${t('nav.productBusiness')} · ${prod.productCode} (${prod.availableQuantity})`,
          route: 'product-business',
        });
      }
    });

    clients.forEach((cli) => {
      if (cli.name.toLowerCase().includes(q) || cli.serviceProvided.toLowerCase().includes(q)) {
        results.push({
          id: cli.id,
          title: cli.name,
          subtitle: `${t('nav.serviceBusiness')} · ${cli.paymentStatus}`,
          route: 'service-business',
        });
      }
    });

    return results.slice(0, 8);
  }, [clients, languagePrefs.displayCurrency, navItems, products, searchQuery, t, transactions]);

  const activeNav = allNavItems.find((item) => item.route === route);

  const handleCreateWorkspaceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWsName.trim()) return;
    await createWorkspace({
      name: newWsName.trim(),
      domain: newWsDomain,
      currency: languagePrefs.displayCurrency,
    });
    setNewWsName('');
    setNewWsModalOpen(false);
  };

  const renderWorkspaceSelector = () => (
    <div className="px-3 py-2.5 border-b border-slate-200 dark:border-slate-800 space-y-1.5">
      {sidebarExpanded && (
        <div className="flex items-center justify-between text-[10px] font-semibold uppercase tracking-wider text-slate-400">
          <span>{t('workspaces.switcherLabel')}</span>
          <button
            type="button"
            onClick={() => setNewWsModalOpen(true)}
            title={t('workspaces.createTitle')}
            className="p-0.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-teal-600 dark:text-[#22D3EE]"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
      {sidebarExpanded ? (
        <select
          aria-label={t('workspaces.switcherLabel')}
          value={activeWorkspace?.id || session?.user.activeWorkspaceId || ''}
          onChange={(e) => switchWorkspace(e.target.value)}
          className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] px-2.5 py-1.5 text-xs font-medium text-slate-800 dark:text-slate-100 truncate"
        >
          {workspaces.map((ws) => (
            <option key={ws.id} value={ws.id}>
              {ws.name}
            </option>
          ))}
        </select>
      ) : (
        <button
          type="button"
          onClick={() => setNewWsModalOpen(true)}
          title={activeWorkspace?.name || t('workspaces.createTitle')}
          className="w-full flex justify-center p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-teal-600 dark:text-[#22D3EE]"
        >
          <Briefcase className="w-4 h-4" />
        </button>
      )}
    </div>
  );

  const renderNavList = (onSelectExtra?: () => void) => (
    <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-1">
      {navItems.map((item) => {
        const Icon = item.icon;
        const active = route === item.route;
        const label = t(item.labelKey);
        return (
          <button
            key={item.route}
            type="button"
            onClick={() => {
              navigate(item.route);
              onSelectExtra?.();
            }}
            title={!sidebarExpanded ? label : undefined}
            className={`w-full flex items-center justify-between gap-2.5 px-3 py-2.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
              active
                ? 'bg-teal-600/12 dark:bg-[#14B8A6]/15 text-teal-700 dark:text-[#14B8A6] font-semibold'
                : 'text-slate-600 dark:text-[#94A3B8] hover:bg-slate-100 dark:hover:bg-[#172235] hover:text-slate-900 dark:hover:text-[#F8FAFC]'
            }`}
          >
            <span className="flex items-center gap-3 min-w-0">
              <Icon className="w-4 h-4 shrink-0" />
              {sidebarExpanded && <span className="truncate">{label}</span>}
            </span>
            {sidebarExpanded && item.badge && item.badge > 0 ? (
              <span className="font-mono-nums text-[11px] font-semibold text-teal-600 dark:text-[#22D3EE]">
                {item.badge}
              </span>
            ) : null}
          </button>
        );
      })}
    </nav>
  );

  const mobileBottomItems: Array<{ route: AppRoute; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number }> = [
    { route: 'dashboard', label: t('nav.dashboard'), icon: LayoutDashboard },
    { route: 'personal-finance', label: t('nav.personalFinance'), icon: Wallet },
    { route: 'assistant', label: t('brandName'), icon: Bot },
    { route: 'messages', label: t('nav.messages'), icon: MessageSquareText, badge: unreadCount },
    { route: 'settings', label: t('nav.settings'), icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] flex">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:flex flex-col border-e border-slate-200 dark:border-slate-800 bg-white dark:bg-[#172235] shrink-0 transition-all duration-200 ${
          sidebarExpanded ? 'w-64' : 'w-[72px]'
        }`}
      >
        <div className="h-16 px-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => navigate('dashboard')}
            className="min-w-0 flex items-center"
          >
            <FinXLogo showWordmark={sidebarExpanded} size="sm" />
          </button>
          <button
            type="button"
            onClick={() => setSidebarExpanded((s) => !s)}
            aria-label={sidebarExpanded ? t('header.collapseSidebar') : t('header.expandSidebar')}
            title={sidebarExpanded ? t('header.collapseSidebar') : t('header.expandSidebar')}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-[#1E293B]"
          >
            {sidebarExpanded ? (
              <ChevronLeft className="w-4 h-4 rtl:rotate-180" />
            ) : (
              <ChevronRight className="w-4 h-4 rtl:rotate-180" />
            )}
          </button>
        </div>
        {workspaces.length > 0 && renderWorkspaceSelector()}
        {renderNavList()}
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/60"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative w-72 max-w-[85vw] bg-white dark:bg-[#172235] border-e border-slate-200 dark:border-slate-800 flex flex-col h-full">
            <div className="h-16 px-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <FinXLogo size="sm" />
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label={t('header.closeNav')}
                className="p-2 rounded-lg text-slate-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {workspaces.length > 0 && renderWorkspaceSelector()}
            {renderNavList(() => setMobileMenuOpen(false))}
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Workspace Header */}
        <header className="sticky top-0 z-30 h-16 px-3 sm:px-6 border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-[#101827]/95 backdrop-blur-xs flex items-center justify-between gap-2 sm:gap-3">
          <div className="flex items-center gap-2 sm:gap-2.5 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label={t('header.openNav')}
              className="lg:hidden p-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-[#F8FAFC] shrink-0"
            >
              <Menu className="w-4 h-4" />
            </button>

            {canGoBack && (
              <button
                type="button"
                onClick={goBack}
                title={t('actions.back')}
                aria-label={t('actions.back')}
                className="hidden sm:inline-flex p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-teal-500 transition-colors shrink-0"
              >
                <ArrowLeft className="w-4 h-4 rtl:rotate-180" />
              </button>
            )}

            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 leading-none mb-0.5">
                {route !== 'dashboard' && (
                  <>
                    <button
                      type="button"
                      onClick={() => navigate('dashboard')}
                      className="hover:text-teal-500 transition-colors truncate max-w-[90px] sm:max-w-none"
                    >
                      {t('nav.dashboard')}
                    </button>
                    <span>/</span>
                  </>
                )}
                <span className="truncate text-slate-500 dark:text-slate-400 max-w-[110px] sm:max-w-none">
                  {activeWorkspace?.name || session?.user.businessName}
                </span>
              </div>
              <h1 className="font-display font-bold text-sm sm:text-base text-slate-900 dark:text-[#F8FAFC] truncate leading-tight">
                {activeNav ? t(activeNav.labelKey) : t('brandName')}
              </h1>
            </div>
          </div>

          {/* Global Search */}
          <div className="hidden md:block relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute start-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('header.searchPlaceholder')}
              className="w-full ps-9 pe-3 py-2 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#172235] text-slate-900 dark:text-[#F8FAFC] placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
            {globalSearchResults.length > 0 && (
              <div className="absolute top-full mt-1.5 start-0 end-0 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] shadow-xl overflow-hidden z-50">
                {globalSearchResults.map((res) => (
                  <button
                    key={res.id}
                    type="button"
                    onClick={() => {
                      navigate(res.route);
                      setSearchQuery('');
                    }}
                    className="w-full px-3.5 py-2.5 text-start hover:bg-slate-50 dark:hover:bg-[#172235] border-b last:border-b-0 border-slate-100 dark:border-slate-800"
                  >
                    <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC]">
                      {res.title}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-[#94A3B8]">
                      {res.subtitle}
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Right Utility Controls */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Top-Right YTD Transactions Trigger */}
            <button
              type="button"
              onClick={() => setYtdDrawerOpen(true)}
              title={t('ytd.title')}
              className="inline-flex items-center gap-1.5 px-2 sm:px-3 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#172235] text-slate-800 dark:text-[#F8FAFC] hover:border-teal-500 transition-colors whitespace-nowrap"
            >
              <CalendarRange className="w-3.5 h-3.5 text-teal-600 dark:text-[#22D3EE]" />
              <span className="hidden sm:inline">{t('header.ytdButton')}</span>
            </button>

            <SearchableLanguageSelector
              value={languagePrefs.displayLanguage}
              onChange={setUnifiedLanguage}
              compact
            />

            <ThemeToggle compact />

            <button
              type="button"
              onClick={() => openAssistant('finance-assistant')}
              title={t('actions.talkToFinX')}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 hover:bg-teal-700 dark:hover:bg-[#22D3EE] transition-colors whitespace-nowrap"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>{t('brandName')}</span>
            </button>

            {/* Notifications Popover */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setNotifOpen((o) => !o);
                  setProfileOpen(false);
                }}
                aria-label={t('header.notifications')}
                title={t('header.notifications')}
                className="relative p-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#172235] text-slate-700 dark:text-[#F8FAFC] hover:border-teal-500/60"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -end-1 min-w-[18px] h-[18px] px-1 rounded-full bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950 text-[10px] font-mono-nums font-bold flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>

              {notifOpen && (
                <div className="absolute end-0 mt-2 w-80 max-w-[90vw] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] shadow-xl z-50 overflow-hidden">
                  <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <span className="text-xs font-semibold">{t('header.notifications')}</span>
                    <button
                      type="button"
                      onClick={() => {
                        setNotifOpen(false);
                        navigate('messages');
                      }}
                      className="text-xs text-teal-600 dark:text-[#14B8A6] hover:underline"
                    >
                      {t('header.viewAllMessages')}
                    </button>
                  </div>
                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                    {messages.length === 0 ? (
                      <p className="p-4 text-xs text-slate-500 dark:text-slate-400">
                        {t('header.noUnread')}
                      </p>
                    ) : (
                      messages.slice(0, 4).map((m) => (
                        <button
                          key={m.id}
                          type="button"
                          onClick={() => {
                            setNotifOpen(false);
                            navigate('messages');
                          }}
                          className="w-full p-3 text-start hover:bg-slate-50 dark:hover:bg-[#172235]"
                        >
                          <div className="text-xs font-semibold text-slate-900 dark:text-[#F8FAFC] truncate">
                            {m.title}
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-[#94A3B8] mt-0.5 line-clamp-2">
                            {m.content}
                          </div>
                        </button>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Profile Dropdown */}
            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  setProfileOpen((o) => !o);
                  setNotifOpen(false);
                }}
                aria-label={t('nav.settings')}
                className="flex items-center gap-2 p-1 pe-1 sm:pe-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#172235] hover:border-teal-500/60"
              >
                <UserAvatar user={session?.user} size="sm" />
                <span className="hidden xl:inline text-xs font-medium max-w-[110px] truncate">
                  {session?.user.name}
                </span>
              </button>

              {profileOpen && (
                <div className="absolute end-0 mt-2 w-64 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] shadow-xl z-50 p-2">
                  <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2.5">
                    <UserAvatar user={session?.user} size="sm" />
                    <div className="min-w-0">
                      <div className="text-xs font-semibold truncate">{session?.user.name}</div>
                      <div className="text-[11px] text-slate-500 dark:text-[#94A3B8] truncate">
                        {session?.user.email}
                      </div>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setProfileOpen(false);
                      navigate('settings');
                    }}
                    className="w-full mt-1 flex items-center gap-2 px-3 py-2 text-xs rounded-lg hover:bg-slate-100 dark:hover:bg-[#172235]"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>{t('nav.settings')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setProfileOpen(false);
                      navigate('security');
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs rounded-lg hover:bg-slate-100 dark:hover:bg-[#172235]"
                  >
                    <Shield className="w-3.5 h-3.5" />
                    <span>{t('nav.security')}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setProfileOpen(false);
                      logout();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-600 dark:text-[#F87171] rounded-lg hover:bg-red-50 dark:hover:bg-red-950/30"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>{t('actions.signOut')}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Main Workspace Page Viewport */}
        <main className="flex-1 p-3 sm:p-6 max-w-[1440px] w-full mx-auto pb-24 md:pb-20 space-y-5">
          {postLoginGreeting && (
            <div className="flex items-center justify-between gap-3 rounded-xl border border-teal-500/30 bg-teal-500/10 px-4 py-3 text-xs text-teal-900 dark:text-teal-200">
              <div className="flex items-center gap-2.5 min-w-0">
                <Sparkles className="w-4 h-4 text-teal-500 shrink-0" />
                <span className="font-medium">{postLoginGreeting}</span>
              </div>
              <button
                type="button"
                onClick={dismissPostLoginGreeting}
                aria-label={t('header.dismissWelcome')}
                className="p-1 rounded hover:bg-teal-500/20 shrink-0"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
          {children}
        </main>
      </div>

      {/* Sticky Mobile Bottom Navigation Bar */}
      <nav
        aria-label={t('header.navigation')}
        className="md:hidden fixed bottom-0 inset-x-0 z-30 border-t border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-[#101827]/95 backdrop-blur-md grid grid-cols-5 px-1 py-1"
      >
        {mobileBottomItems.map((item) => {
          const Icon = item.icon;
          const active = route === item.route;
          return (
            <button
              key={item.route}
              type="button"
              onClick={() => navigate(item.route)}
              className={`relative flex flex-col items-center justify-center gap-0.5 min-h-[44px] px-1 py-1 rounded-lg text-[10px] font-medium transition-colors ${
                active
                  ? 'text-teal-600 dark:text-[#14B8A6] bg-teal-500/10'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="truncate max-w-full">{item.label}</span>
              {item.badge && item.badge > 0 ? (
                <span className="absolute top-1 end-2 min-w-[14px] h-[14px] px-1 rounded-full bg-teal-600 text-white text-[9px] font-bold flex items-center justify-center">
                  {item.badge}
                </span>
              ) : null}
            </button>
          );
        })}
      </nav>

      {/* Create Business / Workspace Modal */}
      {newWsModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <form
            onSubmit={handleCreateWorkspaceSubmit}
            className="w-full max-w-md rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold text-base">{t('workspaces.createTitle')}</h3>
              <button
                type="button"
                onClick={() => setNewWsModalOpen(false)}
                aria-label={t('actions.close')}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                {t('workspaces.nameLabel')}
              </label>
              <input
                type="text"
                required
                value={newWsName}
                onChange={(e) => setNewWsName(e.target.value)}
                placeholder={t('workspaces.namePlaceholder')}
                className="w-full px-3.5 py-2.5 text-sm rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                {t('workspaces.domainLabel')}
              </label>
              <select
                value={newWsDomain}
                onChange={(e) => setNewWsDomain(e.target.value as DomainId)}
                className="w-full px-3 py-2.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827]"
              >
                {ALL_DOMAIN_IDS.map((id) => (
                  <option key={id} value={id}>
                    {getLocalizedDomainTheme(id).label}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setNewWsModalOpen(false)}
                className="px-4 py-2 text-xs font-medium rounded-lg border border-slate-200 dark:border-slate-700"
              >
                {t('actions.cancel')}
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950"
              >
                {t('workspaces.createButton')}
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
