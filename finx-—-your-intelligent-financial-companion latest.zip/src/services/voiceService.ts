import i18n from '../i18n';
import { getLanguageDef } from '../i18n/languages';
import { AppRoute, ThemeMode, VoiceDiagnosticInfo } from '../types/finx';

export type FinXIntentId =
  | 'OPEN_DASHBOARD'
  | 'OPEN_PERSONAL_FINANCE'
  | 'OPEN_PRODUCT_BUSINESS'
  | 'OPEN_SERVICE_BUSINESS'
  | 'OPEN_INVESTMENT_KNOWLEDGE'
  | 'OPEN_FINANCIAL_INTELLIGENCE'
  | 'OPEN_ASSISTANT'
  | 'OPEN_MESSAGES'
  | 'OPEN_DOCUMENTS'
  | 'OPEN_PLANNER'
  | 'OPEN_EXTENSIONS'
  | 'OPEN_LEARNING'
  | 'OPEN_REPORTS'
  | 'OPEN_SECURITY'
  | 'OPEN_SETTINGS'
  | 'OPEN_LOGIN'
  | 'OPEN_REGISTER'
  | 'OPEN_NOTIFICATIONS'
  | 'SWITCH_DARK_MODE'
  | 'SWITCH_LIGHT_MODE'
  | 'GO_BACK'
  | 'EXPLAIN_PAGE';

export interface VoiceCommandMatch {
  intentId: FinXIntentId;
  type: 'navigate' | 'theme' | 'go-back' | 'open-notifications' | 'explain-page';
  route?: AppRoute;
  theme?: ThemeMode;
  requiresAuth: boolean;
  confirmationByLang: Record<string, string>;
}

interface SpeechRecognitionAlternativeLike {
  transcript: string;
  confidence: number;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  length: number;
  0: SpeechRecognitionAlternativeLike;
}

export interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

export interface SpeechRecognitionErrorEventLike {
  error: string;
  message?: string;
}

export interface SpeechRecognitionInstance {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onstart: (() => void) | null;
  onresult: ((event: SpeechRecognitionEventLike) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

type SpeechRecognitionConstructor = new () => SpeechRecognitionInstance;

export function getSpeechRecognitionConstructor(): SpeechRecognitionConstructor | null {
  if (typeof window === 'undefined') return null;
  const w = window as unknown as {
    SpeechRecognition?: SpeechRecognitionConstructor;
    webkitSpeechRecognition?: SpeechRecognitionConstructor;
  };
  return w.SpeechRecognition || w.webkitSpeechRecognition || null;
}

export async function inspectVoiceDiagnostics(
  lastError: { name: string | null; message: string | null },
  activeInputLocale = 'en-US',
  activeOutputLocale = 'en-US'
): Promise<VoiceDiagnosticInfo> {
  const origin = typeof window !== 'undefined' ? window.location.origin : 'unknown';
  const isSecureContext = typeof window !== 'undefined' ? Boolean(window.isSecureContext) : false;
  const mediaDevicesAvailable =
    typeof navigator !== 'undefined' &&
    Boolean(navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function');
  const speechRecognitionAvailable = Boolean(getSpeechRecognitionConstructor());
  const speechSynthesisAvailable =
    typeof window !== 'undefined' && 'speechSynthesis' in window;
  const availableVoicesCount = speechSynthesisAvailable
    ? window.speechSynthesis.getVoices().length
    : 0;

  let permissionState: VoiceDiagnosticInfo['permissionState'] = 'unsupported';
  if (typeof navigator !== 'undefined' && navigator.permissions?.query) {
    try {
      const status = await navigator.permissions.query({
        name: 'microphone' as PermissionName,
      });
      if (status.state === 'granted' || status.state === 'denied' || status.state === 'prompt') {
        permissionState = status.state;
      }
    } catch {
      permissionState = 'unsupported';
    }
  }

  return {
    origin,
    isSecureContext,
    mediaDevicesAvailable,
    speechRecognitionAvailable,
    speechSynthesisAvailable,
    permissionState,
    lastErrorName: lastError.name,
    lastErrorMessage: lastError.message,
    activeSpeechInputLocale: activeInputLocale,
    activeSpeechOutputLocale: activeOutputLocale,
    availableVoicesCount,
  };
}

export function formatMicrophoneErrorGuidance(errorName: string, rawMessage?: string): string {
  switch (errorName) {
    case 'NotAllowedError':
    case 'not-allowed':
    case 'PermissionDeniedError':
    case 'service-not-allowed':
      return i18n.t('assistant:diagnosticsLabels.micDenied');
    case 'NotFoundError':
    case 'DevicesNotFoundError':
    case 'audio-capture':
      return i18n.t('assistant:diagnosticsLabels.micNotFound');
    case 'NotReadableError':
      return i18n.t('assistant:diagnosticsLabels.micBusy');
    case 'language-not-supported':
      return i18n.t('assistant:diagnosticsLabels.micLangUnsupported');
    case 'network':
      return i18n.t('assistant:diagnosticsLabels.micNetwork');
    case 'no-speech':
      return i18n.t('assistant:diagnosticsLabels.micNoSpeech');
    default:
      return rawMessage
        ? `${errorName}: ${rawMessage}`
        : i18n.t('assistant:diagnosticsLabels.micCheckFailed');
  }
}

interface MultilingualIntentEntry {
  intentId: FinXIntentId;
  type: VoiceCommandMatch['type'];
  route?: AppRoute;
  theme?: ThemeMode;
  requiresAuth: boolean;
  patterns: RegExp[];
  confirmationByLang: Record<string, string>;
}

const MULTILINGUAL_INTENT_REGISTRY: MultilingualIntentEntry[] = [
  {
    intentId: 'SWITCH_DARK_MODE',
    type: 'theme',
    theme: 'dark',
    requiresAuth: false,
    patterns: [
      /\b(dark mode|switch to dark|enable dark|dark theme)\b/i,
      /డార్క్\s*మోడ్|నలుపు\s*థీమ్/i,
      /डार्क\s*मोड|अंधेरा\s*थीम/i,
      /டார்க்\s*மோட்/i,
      /modo oscuro/i,
      /الوضع الداكن/i,
      /mode sombre/i,
    ],
    confirmationByLang: {
      en: 'Switched FinX interface to Dark Mode.',
      te: 'FinX ఇంటర్‌ఫేస్ డార్క్ మోడ్‌లోకి మార్చబడింది.',
      hi: 'FinX इंटरफ़ेस डार्क मोड में बदल दिया गया है।',
      ta: 'FinX டார்க் மோடிற்கு மாற்றப்பட்டது.',
      es: 'Se cambió la interfaz de FinX al modo oscuro.',
      ar: 'تم تبديل واجهة FinX إلى الوضع الداكن.',
    },
  },
  {
    intentId: 'SWITCH_LIGHT_MODE',
    type: 'theme',
    theme: 'light',
    requiresAuth: false,
    patterns: [
      /\b(light mode|switch to light|enable light|light theme)\b/i,
      /లైట్\s*మోడ్|తెలుపు\s*థీమ్/i,
      /लाइट\s*मोड|हल्का\s*थीम/i,
      /லைட்\s*மோட்/i,
      /modo claro/i,
      /الوضع الفاتح/i,
      /mode clair/i,
    ],
    confirmationByLang: {
      en: 'Switched FinX interface to Light Mode.',
      te: 'FinX ఇంటర్‌ఫేస్ లైట్ మోడ్‌లోకి మార్చబడింది.',
      hi: 'FinX इंटरफ़ेस लाइट मोड में बदल दिया गया है।',
      ta: 'FinX லைட் மோடிற்கு மாற்றப்பட்டது.',
      es: 'Se cambió la interfaz de FinX al modo claro.',
      ar: 'تم تبديل واجهة FinX إلى الوضع الفاتح.',
    },
  },
  {
    intentId: 'GO_BACK',
    type: 'go-back',
    requiresAuth: false,
    patterns: [
      /\b(go back|previous page|navigate back)\b/i,
      /వెనక్కి\s*వెళ్ళు|మునుపటి\s*పేజీ/i,
      /वापस\s*जाएं|पिछला\s*पृष्ठ/i,
      /பின்செல்/i,
      /volver|regresar/i,
      /العودة/i,
    ],
    confirmationByLang: {
      en: 'Navigated back to the previous view.',
      te: 'మునుపటి పేజీకి వెనక్కి వెళ్ళాము.',
      hi: 'पिछले पृष्ठ पर वापस आ गए हैं।',
      ta: 'முந்தைய பக்கத்திற்குத் திரும்பியது.',
      es: 'Volvimos a la vista anterior.',
      ar: 'تم الرجوع إلى الصفحة السابقة.',
    },
  },
  {
    intentId: 'EXPLAIN_PAGE',
    type: 'explain-page',
    requiresAuth: false,
    patterns: [
      /\b(explain this page|what is this screen|what page is this)\b/i,
      /ఈ\s*పేజీ\s*వివరించు/i,
      /इस\s*पृष्ठ\s*को\s*समझाएं/i,
      /இந்தப்\s*பக்கத்தை\s*விளக்கு/i,
      /explica esta página/i,
      /اشرح هذه الصفحة/i,
    ],
    confirmationByLang: {
      en: 'Explaining the current FinX page.',
      te: 'ప్రస్తుత FinX పేజీ గురించి వివరిస్తున్నాను.',
      hi: 'वर्तमान FinX पृष्ठ का विवरण प्रस्तुत है।',
      ta: 'தற்போதைய FinX பக்கத்தை விளக்குகிறேன்.',
      es: 'Explicando la página actual de FinX.',
      ar: 'جارٍ شرح صفحة FinX الحالية.',
    },
  },
  {
    intentId: 'OPEN_DASHBOARD',
    type: 'navigate',
    route: 'dashboard',
    requiresAuth: true,
    patterns: [
      /\b(open|go to|show|view|take me)\b.*\b(dashboard|home|overview)\b/i,
      /డాష్‌?బోర్డ్|హోమ్/i,
      /डैशबोर्ड|होम/i,
      /டாஷ்போர்டு|முகப்பு/i,
      /panel principal|tablero/i,
      /لوحة التحكم/i,
    ],
    confirmationByLang: {
      en: 'Opened your FinX Dashboard.',
      te: 'మీ FinX డాష్‌బోర్డ్ తెరవబడింది.',
      hi: 'आपका FinX डैशबोर्ड खोल दिया गया है।',
      ta: 'உங்கள் FinX டாஷ்போர்டு திறக்கப்பட்டது.',
      es: 'Se abrió tu panel de FinX.',
      ar: 'تم فتح لوحة تحكم FinX.',
    },
  },
  {
    intentId: 'OPEN_PERSONAL_FINANCE',
    type: 'navigate',
    route: 'personal-finance',
    requiresAuth: true,
    patterns: [
      /\b(personal finance|my finances|personal ledger|my expenses)\b/i,
      /వ్యక్తిగత\s*ఆర్థిక|ఖర్చులు/i,
      /व्यक्तिगत\s*वित्त|मेरे\s*खर्च/i,
      /தனிப்பட்ட\s*நிதி/i,
      /finanzas personales/i,
      /التمويل الشخصي/i,
    ],
    confirmationByLang: {
      en: 'Opened Personal Finance.',
      te: 'వ్యక్తిగత ఆర్థిక విభాగం తెరవబడింది.',
      hi: 'व्यक्तिगत वित्त अनुभाग खोल दिया गया है।',
      ta: 'தனிப்பட்ட நிதிப் பக்கம் திறக்கப்பட்டது.',
      es: 'Se abrió Finanzas Personales.',
      ar: 'تم فتح قسم التمويل الشخصي.',
    },
  },
  {
    intentId: 'OPEN_PRODUCT_BUSINESS',
    type: 'navigate',
    route: 'product-business',
    requiresAuth: true,
    patterns: [
      /\b(product business|product-based|inventory|stock)\b/i,
      /ఉత్పత్తి\s*వ్యాపారం|ఇన్వెంటరీ/i,
      /उत्पाद\s*व्यवसाय|इन्वेंट्री/i,
      /தயாரிப்பு\s*வணிகம்/i,
      /negocio de productos|inventario/i,
      /تجارة المنتجات/i,
    ],
    confirmationByLang: {
      en: 'Opened Product-Based Business.',
      te: 'ఉత్పత్తి ఆధారిత వ్యాపారం తెరవబడింది.',
      hi: 'उत्पाद-आधारित व्यवसाय खोल दिया गया है।',
      ta: 'தயாரிப்பு வணிகம் திறக்கப்பட்டது.',
      es: 'Se abrió Negocio de Productos.',
      ar: 'تم فتح قسم تجارة المنتجات.',
    },
  },
  {
    intentId: 'OPEN_SERVICE_BUSINESS',
    type: 'navigate',
    route: 'service-business',
    requiresAuth: true,
    patterns: [
      /\b(service business|consultancy|clients)\b/i,
      /సేవా\s*వ్యాపారం|క్లయింట్లు/i,
      /सेवा\s*व्यवसाय|परामर्श/i,
      /சேவை\s*வணிகம்/i,
      /negocio de servicios|consultoría/i,
      /الخدمات والاستشارات/i,
    ],
    confirmationByLang: {
      en: 'Opened Service & Consultancy Business.',
      te: 'సేవా & కన్సల్టెన్సీ వ్యాపారం తెరవబడింది.',
      hi: 'सेवा और परामर्श व्यवसाय खोल दिया गया है।',
      ta: 'சேவை மற்றும் ஆலோசனை வணிகம் திறக்கப்பட்டது.',
      es: 'Se abrió Servicios y Consultoría.',
      ar: 'تم فتح قسم الخدمات والاستشارات.',
    },
  },
  {
    intentId: 'OPEN_INVESTMENT_KNOWLEDGE',
    type: 'navigate',
    route: 'investment-knowledge',
    requiresAuth: true,
    patterns: [
      /\b(investment knowledge|investments|paper trading|mutual funds|stocks)\b/i,
      /పెట్టుబడి\s*జ్ఞానం|స్టాక్/i,
      /निवेश\s*ज्ञान|शेयर\s*बाज़ार/i,
      /முதலீட்டு\s*அறிவு/i,
      /conocimiento de inversión/i,
      /معرفة الاستثمار/i,
    ],
    confirmationByLang: {
      en: 'Opened Investment Knowledge.',
      te: 'పెట్టుబడి జ్ఞానం తెరవబడింది.',
      hi: 'निवेश ज्ञान अनुभाग खोल दिया गया है।',
      ta: 'முதலீட்டு அறிவு திறக்கப்பட்டது.',
      es: 'Se abrió Conocimiento de Inversión.',
      ar: 'تم فتح قسم معرفة الاستثمار.',
    },
  },
  {
    intentId: 'OPEN_FINANCIAL_INTELLIGENCE',
    type: 'navigate',
    route: 'financial-intelligence',
    requiresAuth: true,
    patterns: [
      /\b(financial intelligence|analytics|forecast)\b/i,
      /ఆర్థిక\s*మేధస్సు|విశ్లేషణ/i,
      /वित्तीय\s*बुद्धिमत्ता|विश्लेषण/i,
      /நிதி\s*நுண்ணறிவு/i,
      /inteligencia financiera/i,
      /الذكاء المالي/i,
    ],
    confirmationByLang: {
      en: 'Opened Financial Intelligence.',
      te: 'ఆర్థిక మేధస్సు తెరవబడింది.',
      hi: 'वित्तीय बुद्धिमत्ता अनुभाग खोल दिया गया है।',
      ta: 'நிதி நுண்ணறிவு திறக்கப்பட்டது.',
      es: 'Se abrió Inteligencia Financiera.',
      ar: 'تم فتح قسم الذكاء المالي.',
    },
  },
  {
    intentId: 'OPEN_MESSAGES',
    type: 'navigate',
    route: 'messages',
    requiresAuth: true,
    patterns: [
      /\b(finx messages|messages|inbox|notifications|alerts)\b/i,
      /సందేశాలు|నోటిఫికేషన్లు/i,
      /संदेश|सूचनाएं/i,
      /செய்திகள்|அறிவிப்புகள்/i,
      /mensajes|notificaciones/i,
      /الرسائل|الإشعارات/i,
    ],
    confirmationByLang: {
      en: 'Opened FinX Messages.',
      te: 'FinX సందేశాలు తెరవబడ్డాయి.',
      hi: 'FinX संदेश खोल दिए गए हैं।',
      ta: 'FinX செய்திகள் திறக்கப்பட்டது.',
      es: 'Se abrió Mensajes de FinX.',
      ar: 'تم فتح رسائل FinX.',
    },
  },
  {
    intentId: 'OPEN_EXTENSIONS',
    type: 'navigate',
    route: 'extensions',
    requiresAuth: true,
    patterns: [
      /\b(extension center|extensions|plugins)\b/i,
      /ఎక్స్‌టెన్షన్లు/i,
      /एक्सटेंशन/i,
      /நீட்டிப்புகள்/i,
      /extensiones/i,
      /الإضافات/i,
    ],
    confirmationByLang: {
      en: 'Opened Extension Center.',
      te: 'ఎక్స్‌టెన్షన్ సెంటర్ తెరవబడింది.',
      hi: 'एक्सटेंशन सेंटर खोल दिया गया है।',
      ta: 'நீட்டிப்பு மையம் திறக்கப்பட்டது.',
      es: 'Se abrió el Centro de Extensiones.',
      ar: 'تم فتح مركز الإضافات.',
    },
  },
  {
    intentId: 'OPEN_DOCUMENTS',
    type: 'navigate',
    route: 'documents',
    requiresAuth: true,
    patterns: [
      /\b(document analyzer|documents|upload receipt)\b/i,
      /డాక్యుమెంట్|రసీదు/i,
      /दस्तावेज़|रसीद/i,
      /ஆவண|ரசீது/i,
      /documentos|analizador/i,
      /المستندات/i,
    ],
    confirmationByLang: {
      en: 'Opened Document Analyzer.',
      te: 'డాక్యుమెంట్ ఎనలైజర్ తెరవబడింది.',
      hi: 'दस्तावेज़ विश्लेषक खोल दिया गया है।',
      ta: 'ஆவண பகுப்பாய்வி திறக்கப்பட்டது.',
      es: 'Se abrió el Analizador de Documentos.',
      ar: 'تم فتح محلل المستندات.',
    },
  },
  {
    intentId: 'OPEN_PLANNER',
    type: 'navigate',
    route: 'planner',
    requiresAuth: true,
    patterns: [
      /\b(smart planner|financial planner|planner)\b/i,
      /ప్లానర్|ప్రణాళిక/i,
      /प्लानर|योजना/i,
      /திட்டமிடுபவர்/i,
      /planificador/i,
      /المخطط/i,
    ],
    confirmationByLang: {
      en: 'Opened Smart Financial Planner.',
      te: 'స్మార్ట్ ఫైనాన్షియల్ ప్లానర్ తెరవబడింది.',
      hi: 'स्मार्ट वित्तीय प्लानर खोल दिया गया है।',
      ta: 'ஸ்மார்ட் நிதி திட்டமிடுபவர் திறக்கப்பட்டது.',
      es: 'Se abrió el Planificador Inteligente.',
      ar: 'تم فتح المخطط المالي الذكي.',
    },
  },
  {
    intentId: 'OPEN_LEARNING',
    type: 'navigate',
    route: 'learning',
    requiresAuth: true,
    patterns: [
      /\b(learning center|learn|academy)\b/i,
      /లెర్నింగ్|నేర్చుకోండి/i,
      /लर्निंग|सीखें/i,
      /கற்றல் மையம்/i,
      /aprendizaje|aprender/i,
      /مركز التعلم/i,
    ],
    confirmationByLang: {
      en: 'Opened Learning Center.',
      te: 'లెర్నింగ్ సెంటర్ తెరవబడింది.',
      hi: 'लर्निंग सेंटर खोल दिया गया है।',
      ta: 'கற்றல் மையம் திறக்கப்பட்டது.',
      es: 'Se abrió el Centro de Aprendizaje.',
      ar: 'تم فتح مركز التعلم.',
    },
  },
  {
    intentId: 'OPEN_REPORTS',
    type: 'navigate',
    route: 'reports',
    requiresAuth: true,
    patterns: [
      /\b(reports|statements|export csv)\b/i,
      /రిపోర్ట్|నివేదికలు/i,
      /रिपोर्ट|विवरण/i,
      /அறிக்கைகள்/i,
      /informes|reportes/i,
      /التقارير/i,
    ],
    confirmationByLang: {
      en: 'Opened Reports & Analytics.',
      te: 'నివేదికలు & విశ్లేషణలు తెరవబడ్డాయి.',
      hi: 'रिपोर्ट और विश्लेषण खोल दिए गए हैं।',
      ta: 'அறிக்கைகள் & பகுப்பாய்வு திறக்கப்பட்டது.',
      es: 'Se abrió Informes y Análisis.',
      ar: 'تم فتح التقارير والتحليلات.',
    },
  },
  {
    intentId: 'OPEN_SECURITY',
    type: 'navigate',
    route: 'security',
    requiresAuth: true,
    patterns: [
      /\b(privacy|security)\b/i,
      /భద్రత|గోప్యత/i,
      /सुरक्षा|गोपनीयता/i,
      /தனியுரிமை|பாதுகாப்பு/i,
      /privacidad|seguridad/i,
      /الخصوصية|الأمان/i,
    ],
    confirmationByLang: {
      en: 'Opened Privacy & Security Center.',
      te: 'గోప్యత & భద్రతా కేంద్రం తెరవబడింది.',
      hi: 'गोपनीयता और सुरक्षा केंद्र खोल दिया गया है।',
      ta: 'தனியுரிமை & பாதுகாப்பு மையம் திறக்கப்பட்டது.',
      es: 'Se abrió Privacidad y Seguridad.',
      ar: 'تم فتح مركز الخصوصية والأمان.',
    },
  },
  {
    intentId: 'OPEN_SETTINGS',
    type: 'navigate',
    route: 'settings',
    requiresAuth: true,
    patterns: [
      /\b(settings|preferences|language settings)\b/i,
      /సెట్టింగులు|భాష/i,
      /सेटिंग्स|भाषा/i,
      /அமைப்புகள்/i,
      /configuración/i,
      /الإعدادات/i,
    ],
    confirmationByLang: {
      en: 'Opened Settings.',
      te: 'సెట్టింగులు తెరవబడ్డాయి.',
      hi: 'सेटिंग्स खोल दी गई हैं।',
      ta: 'அமைப்புகள் திறக்கப்பட்டது.',
      es: 'Se abrió Configuración.',
      ar: 'تم فتح الإعدادات.',
    },
  },
  {
    intentId: 'OPEN_LOGIN',
    type: 'navigate',
    route: 'login',
    requiresAuth: false,
    patterns: [
      /\b(open|go to|take me)\b.*\b(login|sign in)\b/i,
      /లాగిన్/i,
      /लॉगिन/i,
      /உள்நுழைய/i,
      /iniciar sesión/i,
      /تسجيل الدخول/i,
    ],
    confirmationByLang: {
      en: 'Opened Login to Workspace.',
      te: 'లాగిన్ పేజీ తెరవబడింది.',
      hi: 'लॉगिन पृष्ठ खोल दिया गया है।',
      ta: 'உள்நுழைவுப் பக்கம் திறக்கப்பட்டது.',
      es: 'Se abrió el inicio de sesión.',
      ar: 'تم فتح صفحة تسجيل الدخول.',
    },
  },
  {
    intentId: 'OPEN_REGISTER',
    type: 'navigate',
    route: 'register',
    requiresAuth: false,
    patterns: [
      /\b(open|go to|take me)\b.*\b(register|sign up|get started)\b/i,
      /నమోదు|ఖాతా/i,
      /रजिस्टर|खाता बनाएं/i,
      /பதிவு|கணக்கு/i,
      /registrarse|crear cuenta/i,
      /إنشاء حساب/i,
    ],
    confirmationByLang: {
      en: 'Opened Workspace Registration.',
      te: 'నమోదు పేజీ తెరవబడింది.',
      hi: 'पंजीकरण पृष्ठ खोल दिया गया है।',
      ta: 'பதிவுப் பக்கம் திறக்கப்பட்டது.',
      es: 'Se abrió el registro de espacio.',
      ar: 'تم فتح صفحة إنشاء الحساب.',
    },
  },
];

export function matchCentralizedVoiceCommand(
  transcript: string,
  isAuthenticated: boolean
): VoiceCommandMatch | null {
  const q = transcript.trim();
  if (!q) return null;

  // Safety guard: never authorize payments or trades by voice
  if (
    /\b(pay|transfer|send money|upi pin|buy stock|sell stock|execute trade|authorize payment)\b/i.test(
      q
    )
  ) {
    return null;
  }

  for (const entry of MULTILINGUAL_INTENT_REGISTRY) {
    if (entry.requiresAuth && !isAuthenticated) continue;
    if (entry.patterns.some((p) => p.test(q))) {
      return {
        intentId: entry.intentId,
        type: entry.type,
        route: entry.route,
        theme: entry.theme,
        requiresAuth: entry.requiresAuth,
        confirmationByLang: entry.confirmationByLang,
      };
    }
  }

  return null;
}

export function getIntentConfirmationText(
  match: VoiceCommandMatch,
  outputLocale: string
): string {
  const langCode = getLanguageDef(outputLocale).code;
  return match.confirmationByLang[langCode] || match.confirmationByLang.en || 'Action completed.';
}

export function getVoicesForLocale(locale: string): SpeechSynthesisVoice[] {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return [];
  const voices = window.speechSynthesis.getVoices();
  const base = locale.split('-')[0].toLowerCase();
  const exact = voices.filter((v) => v.lang.toLowerCase() === locale.toLowerCase());
  const partial = voices.filter(
    (v) =>
      v.lang.toLowerCase().startsWith(base) &&
      v.lang.toLowerCase() !== locale.toLowerCase()
  );
  return [...exact, ...partial];
}

export function inspectSpeechLanguageSupport(
  inputLocale: string,
  outputLocale: string,
  preferredVoiceURI?: string
): {
  sttSupportedByBrowserApi: boolean;
  sttNote: string;
  ttsSupported: boolean;
  ttsVoices: SpeechSynthesisVoice[];
  chosenVoice: SpeechSynthesisVoice | null;
  ttsNote: string;
} {
  const sttCtor = getSpeechRecognitionConstructor();
  const sttSupportedByBrowserApi = Boolean(sttCtor);
  const inputDef = getLanguageDef(inputLocale);
  const outputDef = getLanguageDef(outputLocale);

  const sttNote = sttSupportedByBrowserApi
    ? i18n.t('assistant:diagnosticsLabels.sttAvailable', {
        locale: inputLocale,
        lang: inputDef.nativeName,
      })
    : i18n.t('assistant:diagnosticsLabels.sttUnavailable');

  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return {
      sttSupportedByBrowserApi,
      sttNote,
      ttsSupported: false,
      ttsVoices: [],
      chosenVoice: null,
      ttsNote: i18n.t('assistant:diagnosticsLabels.ttsUnavailable'),
    };
  }

  const allVoices = window.speechSynthesis.getVoices();
  const matchingVoices = getVoicesForLocale(outputLocale);
  const chosenVoice =
    (preferredVoiceURI && preferredVoiceURI !== 'auto'
      ? allVoices.find((v) => v.voiceURI === preferredVoiceURI)
      : null) ||
    matchingVoices[0] ||
    null;

  if (!allVoices.length) {
    return {
      sttSupportedByBrowserApi,
      sttNote,
      ttsSupported: true,
      ttsVoices: [],
      chosenVoice: null,
      ttsNote: i18n.t('assistant:diagnosticsLabels.ttsOsLoading'),
    };
  }

  if (!chosenVoice && outputDef.code !== 'en') {
    return {
      sttSupportedByBrowserApi,
      sttNote,
      ttsSupported: false,
      ttsVoices: [],
      chosenVoice: null,
      ttsNote: i18n.t('assistant:diagnosticsLabels.ttsMissingLocale', {
        lang: outputDef.nativeName,
        locale: outputLocale,
      }),
    };
  }

  return {
    sttSupportedByBrowserApi,
    sttNote,
    ttsSupported: true,
    ttsVoices: matchingVoices,
    chosenVoice,
    ttsNote: chosenVoice
      ? i18n.t('assistant:diagnosticsLabels.ttsActiveVoice', {
          name: chosenVoice.name,
          lang: chosenVoice.lang,
        })
      : i18n.t('assistant:diagnosticsLabels.ttsDefaultEnglish'),
  };
}
