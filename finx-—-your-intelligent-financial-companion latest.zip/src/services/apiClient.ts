export interface ServiceResponse<T> {
  ok: boolean;
  data?: T;
  error?: string;
  source: 'demo-repository' | 'server-api' | 'fastapi-pending';
}

export const FASTAPI_CONFIG = {
  baseUrl: import.meta.env?.VITE_FINX_API_URL || '/api',
  backendTarget: 'Python 3.12 + FastAPI + SQLite/PostgreSQL',
  endpoints: {
    auth: '/v1/auth',
    users: '/v1/users',
    transactions: '/v1/personal/transactions',
    budgets: '/v1/personal/budgets',
    products: '/v1/product-business/products',
    inventory: '/v1/product-business/inventory',
    clients: '/v1/service-business/clients',
    businessPayments: '/v1/service-business/payments',
    reports: '/v1/reports',
    notifications: '/v1/messages',
    documents: '/v1/documents',
    aiAssistant: '/assistant/chat',
    intelligence: '/v1/intelligence',
    extensions: '/v1/extensions',
  },
} as const;

export async function postJson<TResponse>(
  url: string,
  payload: unknown,
  signal?: AbortSignal
): Promise<{ status: number; data: TResponse }> {
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
    signal,
  });

  const data = (await response.json().catch(() => ({}))) as TResponse;
  if (!response.ok) {
    const errPayload = data as { error?: string };
    throw new Error(errPayload?.error || `Request failed with status ${response.status}`);
  }
  return { status: response.status, data };
}
