import { getLanguageDef } from '../i18n/languages';
import { AppRoute, AssistantMessage, GroundingSource, LanguageCode, NeuralVoiceName } from '../types/finx';
import { postJson } from './apiClient';

export interface AiChatRequestParams {
  message: string;
  history: AssistantMessage[];
  language: LanguageCode;
  mode: 'finance-assistant' | 'finx-guide';
  isAuthenticated: boolean;
  currentRoute: AppRoute;
  authorizedSummary: Record<string, unknown> | null;
  signal?: AbortSignal;
}

export interface AiChatResponsePayload {
  reply: string;
  followUpSuggestion: string | null;
  navigationRoute: AppRoute | null;
  themeAction: 'dark' | 'light' | null;
  detectedLanguage?: string | null;
  sources?: GroundingSource[];
  model: string;
}

export interface NeuralVoicePersona {
  id: NeuralVoiceName;
  label: string;
  tone: string;
  stylePrompt: string;
}

export const NEURAL_VOICE_PERSONAS: NeuralVoicePersona[] = [
  {
    id: 'Kore',
    label: 'Kore — Warm Advisor',
    tone: 'Clear, balanced & reassuring',
    stylePrompt: 'Warm, clear, friendly financial advisor speaking naturally',
  },
  {
    id: 'Zephyr',
    label: 'Zephyr — Bright Companion',
    tone: 'Upbeat, conversational & approachable',
    stylePrompt: 'Friendly, conversational, approachable everyday companion',
  },
  {
    id: 'Puck',
    label: 'Puck — Energetic Guide',
    tone: 'Crisp, lively & engaging',
    stylePrompt: 'Upbeat, crisp, enthusiastic product guide',
  },
  {
    id: 'Charon',
    label: 'Charon — Calm Analyst',
    tone: 'Steady, thoughtful & analytical',
    stylePrompt: 'Calm, composed, analytical financial strategist',
  },
  {
    id: 'Fenrir',
    label: 'Fenrir — Executive Brief',
    tone: 'Confident, grounded & authoritative',
    stylePrompt: 'Confident, steady, concise executive briefing tone',
  },
];

export interface NeuralTtsResponsePayload {
  audioBase64: string;
  mimeType: string;
  voiceName: NeuralVoiceName;
  model: string;
  cached?: boolean;
}

export interface AudioTranscribeResponsePayload {
  transcript: string;
  model: string;
}

export const aiAssistantService = {
  async checkHealth(): Promise<{
    aiConfigured: boolean;
    model: string;
    ttsModel?: string;
    transcribeModel?: string;
    groundingEnabled?: boolean;
  }> {
    try {
      const res = await fetch('/api/assistant/health');
      if (!res.ok) return { aiConfigured: false, model: 'unavailable' };
      return (await res.json()) as {
        aiConfigured: boolean;
        model: string;
        ttsModel?: string;
        transcribeModel?: string;
        groundingEnabled?: boolean;
      };
    } catch {
      return { aiConfigured: false, model: 'unavailable' };
    }
  },

  async sendMessage(params: AiChatRequestParams): Promise<AiChatResponsePayload> {
    const langDef = getLanguageDef(params.language);
    const historyTurns = params.history.slice(-12).map((msg) => ({
      role: msg.role,
      content: msg.content,
    }));

    const { data } = await postJson<AiChatResponsePayload>(
      '/api/assistant/chat',
      {
        message: params.message,
        history: historyTurns,
        language: params.language,
        languageLabel: `${langDef.englishName} (${langDef.nativeName}, ${langDef.defaultSpeechLocale})`,
        mode: params.mode,
        isAuthenticated: params.isAuthenticated,
        currentRoute: params.currentRoute,
        authorizedSummary: params.isAuthenticated ? params.authorizedSummary : null,
      },
      params.signal
    );

    return data;
  },

  async synthesizeSpeech(params: {
    text: string;
    voiceName?: NeuralVoiceName;
    languageLabel?: string;
    style?: string;
    signal?: AbortSignal;
  }): Promise<NeuralTtsResponsePayload> {
    const persona = NEURAL_VOICE_PERSONAS.find((p) => p.id === params.voiceName) || NEURAL_VOICE_PERSONAS[0];
    const { data } = await postJson<NeuralTtsResponsePayload>(
      '/api/assistant/tts',
      {
        text: params.text,
        voiceName: persona.id,
        languageLabel: params.languageLabel,
        style: params.style || persona.stylePrompt,
      },
      params.signal
    );
    return data;
  },

  async transcribeAudio(params: {
    audioBase64: string;
    mimeType: string;
    languageHint?: string;
    signal?: AbortSignal;
  }): Promise<AudioTranscribeResponsePayload> {
    const { data } = await postJson<AudioTranscribeResponsePayload>(
      '/api/assistant/transcribe',
      {
        audioBase64: params.audioBase64,
        mimeType: params.mimeType,
        languageHint: params.languageHint,
      },
      params.signal
    );
    return data;
  },
};
