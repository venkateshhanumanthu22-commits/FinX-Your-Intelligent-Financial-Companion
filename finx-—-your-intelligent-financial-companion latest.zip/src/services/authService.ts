import { DEMO_USER_PROFILE } from '../data/mockRepository';
import { AuthSession, UserProfile } from '../types/finx';
import { ServiceResponse } from './apiClient';
import { validateEmail, validatePassword, validateRequiredText } from '../utils/validators';

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterPayload {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: UserProfile['role'];
  businessName: string;
}

export const authService = {
  loginDemo(credentials: LoginCredentials): ServiceResponse<AuthSession> {
    const emailErr = validateEmail(credentials.email);
    if (emailErr) return { ok: false, error: emailErr, source: 'demo-repository' };

    const passErr = validatePassword(credentials.password, false);
    if (passErr) return { ok: false, error: passErr, source: 'demo-repository' };

    const normalizedEmail = credentials.email.trim().toLowerCase();
    const isDefaultDemo = normalizedEmail === DEMO_USER_PROFILE.email.toLowerCase();

    const user: UserProfile = isDefaultDemo
      ? { ...DEMO_USER_PROFILE }
      : {
          ...DEMO_USER_PROFILE,
          id: `demo-${Date.now().toString(36)}`,
          name: normalizedEmail.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
          email: normalizedEmail,
          isDemoAccount: true,
        };

    return {
      ok: true,
      source: 'demo-repository',
      data: {
        user,
        sessionStartedAt: new Date().toISOString(),
        authMode: 'demo-local',
        tokenNotice:
          'Demo frontend session active. Passwords are not stored in browser storage; production authentication requires the FastAPI backend.',
      },
    };
  },

  loginOneClickDemo(): ServiceResponse<AuthSession> {
    return {
      ok: true,
      source: 'demo-repository',
      data: {
        user: { ...DEMO_USER_PROFILE },
        sessionStartedAt: new Date().toISOString(),
        authMode: 'demo-local',
        tokenNotice:
          'Demo workspace signed in as Elena Vance using synthetic demonstration data.',
      },
    };
  },

  registerDemo(payload: RegisterPayload): ServiceResponse<AuthSession> {
    const nameErr = validateRequiredText(payload.name, 'Full name');
    if (nameErr) return { ok: false, error: nameErr, source: 'demo-repository' };

    const emailErr = validateEmail(payload.email);
    if (emailErr) return { ok: false, error: emailErr, source: 'demo-repository' };

    const passErr = validatePassword(payload.password, true);
    if (passErr) return { ok: false, error: passErr, source: 'demo-repository' };

    if (payload.password !== payload.confirmPassword) {
      return { ok: false, error: 'Passwords do not match.', source: 'demo-repository' };
    }

    const user: UserProfile = {
      id: `user-${Date.now().toString(36)}`,
      name: payload.name.trim(),
      email: payload.email.trim().toLowerCase(),
      role: payload.role,
      businessName: payload.businessName.trim() || `${payload.name.trim()} Workspace`,
      currency: 'USD',
      avatarUrl: DEMO_USER_PROFILE.avatarUrl,
      avatarCategory: 'neutral',
      avatarPresetId: 'neutral-compass',
      enabledDomains: [
        'personal-finance',
        'product-business',
        'service-business',
        'investment-knowledge',
        'financial-intelligence',
      ],
      activeWorkspaceId: 'ws-demo-default',
      isDemoAccount: true,
      createdAt: new Date().toISOString(),
    };

    return {
      ok: true,
      source: 'demo-repository',
      data: {
        user,
        sessionStartedAt: new Date().toISOString(),
        authMode: 'demo-local',
        tokenNotice:
          'Demo account created for current session. Credentials are never persisted in localStorage.',
      },
    };
  },
};
