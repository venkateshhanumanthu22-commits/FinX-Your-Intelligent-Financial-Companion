import i18n from '../i18n';
import {
  BudgetCategory,
  BusinessExpense,
  PayrollRecord,
  PersonalTransaction,
  ProductItem,
  SaleRecord,
  ServiceClient,
} from '../types/finx';

export interface ActualMetricsSummary {
  personalIncome: number;
  personalExpenses: number;
  personalNetSavings: number;
  savingsRatePercent: number;
  productRevenue: number;
  productCOGS: number;
  productOperatingExpenses: number;
  productNetProfit: number;
  inventoryValuationAtCost: number;
  serviceCollectedRevenue: number;
  servicePendingReceivables: number;
  serviceOverdueAmount: number;
  serviceExpensesAndPayroll: number;
  serviceNetProfit: number;
  combinedGrossInflow: number;
  combinedNetPosition: number;
}

export interface RuleBasedInsight {
  id: string;
  severity: 'info' | 'warning' | 'alert';
  domain: string;
  title: string;
  explanation: string;
  ruleDefinition: string;
}

export interface DemoForecastPoint {
  month: string;
  projectedIncome: number;
  projectedExpense: number;
  projectedNet: number;
}

function resolveTargetMonth(transactions: PersonalTransaction[]): { yearMonth: string; monthLabel: string } {
  const expenseDates = transactions
    .filter((t) => t.type === 'expense' && /^\d{4}-\d{2}/.test(t.date))
    .map((t) => t.date.slice(0, 7))
    .sort();
  const currentMonth = new Date().toISOString().slice(0, 7);
  const yearMonth = expenseDates.length > 0 ? expenseDates[expenseDates.length - 1] : currentMonth;
  const [yStr, mStr] = yearMonth.split('-');
  const refDate = new Date(Number(yStr), Math.max(0, Number(mStr) - 1), 15);
  let monthLabel = yearMonth;
  try {
    monthLabel = new Intl.DateTimeFormat(i18n.language || 'en', { month: 'long' }).format(refDate);
  } catch {
    monthLabel = yearMonth;
  }
  return { yearMonth, monthLabel };
}

export const intelligenceService = {
  computeActualMetrics(params: {
    transactions: PersonalTransaction[];
    products: ProductItem[];
    sales: SaleRecord[];
    businessExpenses: BusinessExpense[];
    clients: ServiceClient[];
    payroll: PayrollRecord[];
  }): ActualMetricsSummary {
    const personalIncome = params.transactions
      .filter((t) => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
    const personalExpenses = params.transactions
      .filter((t) => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
    const personalNetSavings = personalIncome - personalExpenses;
    const savingsRatePercent =
      personalIncome > 0 ? Math.round((personalNetSavings / personalIncome) * 1000) / 10 : 0;

    const productRevenue = params.sales.reduce((sum, s) => sum + s.totalAmount, 0);
    const productCOGS = params.sales.reduce((sum, s) => {
      const prod = params.products.find((p) => p.id === s.productId);
      return sum + (prod ? prod.purchaseCost * s.quantity : 0);
    }, 0);
    const productOperatingExpenses = params.businessExpenses
      .filter((e) => e.domain === 'product')
      .reduce((sum, e) => sum + e.amount, 0);
    const productNetProfit = productRevenue - productCOGS - productOperatingExpenses;
    const inventoryValuationAtCost = params.products.reduce(
      (sum, p) => sum + p.purchaseCost * p.availableQuantity,
      0
    );

    const serviceCollectedRevenue = params.clients.reduce((sum, c) => sum + c.paidAmount, 0);
    const servicePendingReceivables = params.clients.reduce(
      (sum, c) => sum + Math.max(0, c.agreedAmount - c.paidAmount),
      0
    );
    const serviceOverdueAmount = params.clients
      .filter((c) => c.paymentStatus === 'Overdue')
      .reduce((sum, c) => sum + Math.max(0, c.agreedAmount - c.paidAmount), 0);
    const serviceExpensesAndPayroll =
      params.businessExpenses
        .filter((e) => e.domain === 'service')
        .reduce((sum, e) => sum + e.amount, 0) +
      params.payroll.reduce((sum, p) => sum + p.amount, 0);
    const serviceNetProfit = serviceCollectedRevenue - serviceExpensesAndPayroll;

    const combinedGrossInflow = personalIncome + productRevenue + serviceCollectedRevenue;
    const combinedNetPosition = personalNetSavings + productNetProfit + serviceNetProfit;

    return {
      personalIncome,
      personalExpenses,
      personalNetSavings,
      savingsRatePercent,
      productRevenue,
      productCOGS,
      productOperatingExpenses,
      productNetProfit,
      inventoryValuationAtCost,
      serviceCollectedRevenue,
      servicePendingReceivables,
      serviceOverdueAmount,
      serviceExpensesAndPayroll,
      serviceNetProfit,
      combinedGrossInflow,
      combinedNetPosition,
    };
  },

  generateRuleBasedInsights(params: {
    transactions: PersonalTransaction[];
    budgets: BudgetCategory[];
    products: ProductItem[];
    clients: ServiceClient[];
    metrics: ActualMetricsSummary;
  }): RuleBasedInsight[] {
    const insights: RuleBasedInsight[] = [];
    const { yearMonth, monthLabel } = resolveTargetMonth(params.transactions);
    const personalLabel = i18n.t('common:domains.personal-finance.label', { defaultValue: 'Personal Finance' });
    const productLabel = i18n.t('common:domains.product-business.label', { defaultValue: 'Product Business' });
    const serviceLabel = i18n.t('common:domains.service-business.label', { defaultValue: 'Service Business' });

    // Rule 1: Budget threshold check (latest month spending vs limit)
    params.budgets.forEach((b) => {
      const spent = params.transactions
        .filter((t) => t.type === 'expense' && t.category === b.category && t.date.startsWith(yearMonth))
        .reduce((sum, t) => sum + t.amount, 0);
      const pct = b.monthlyLimit > 0 ? Math.round((spent / b.monthlyLimit) * 100) : 0;
      if (pct >= b.alertThresholdPercent) {
        insights.push({
          id: `rule-budget-${b.id}`,
          severity: pct >= 100 ? 'alert' : 'warning',
          domain: personalLabel,
          title: i18n.t('business:intelligence.rules.budgetTitle', { category: b.category, pct }),
          explanation: i18n.t('business:intelligence.rules.budgetExplanation', {
            month: monthLabel,
            category: b.category,
            spent: spent.toFixed(2),
            pct,
            limit: b.monthlyLimit.toFixed(2),
          }),
          ruleDefinition: i18n.t('business:intelligence.rules.budgetRule', {
            threshold: b.alertThresholdPercent,
          }),
        });
      }
    });

    // Rule 2: Low inventory reorder threshold
    const lowStockProducts = params.products.filter((p) => p.availableQuantity <= p.reorderLevel);
    if (lowStockProducts.length > 0) {
      insights.push({
        id: 'rule-low-stock',
        severity: 'warning',
        domain: productLabel,
        title: i18n.t('business:intelligence.rules.lowStockTitle', {
          count: lowStockProducts.length,
        }),
        explanation: i18n.t('business:intelligence.rules.lowStockExplanation', {
          items: lowStockProducts.map((p) => `${p.name} (${p.availableQuantity})`).join(', '),
        }),
        ruleDefinition: i18n.t('business:intelligence.rules.lowStockRule'),
      });
    }

    // Rule 3: Overdue consultancy receivables
    const overdueClients = params.clients.filter((c) => c.paymentStatus === 'Overdue');
    if (overdueClients.length > 0) {
      const overdueTotal = overdueClients.reduce(
        (s, c) => s + Math.max(0, c.agreedAmount - c.paidAmount),
        0
      );
      insights.push({
        id: 'rule-overdue-clients',
        severity: 'alert',
        domain: serviceLabel,
        title: i18n.t('business:intelligence.rules.overdueTitle', {
          total: overdueTotal.toLocaleString(i18n.language || 'en'),
        }),
        explanation: i18n.t('business:intelligence.rules.overdueExplanation', {
          clients: overdueClients.map((c) => c.name).join(', '),
        }),
        ruleDefinition: i18n.t('business:intelligence.rules.overdueRule'),
      });
    }

    // Rule 4: Expense anomaly check (single expense > 1.75x average non-housing expense)
    const nonHousingExpenses = params.transactions.filter(
      (t) => t.type === 'expense' && t.category !== 'Housing'
    );
    if (nonHousingExpenses.length >= 3) {
      const avg =
        nonHousingExpenses.reduce((s, t) => s + t.amount, 0) / nonHousingExpenses.length;
      const outliers = nonHousingExpenses.filter((t) => t.amount > avg * 1.75);
      if (outliers.length > 0) {
        insights.push({
          id: 'rule-expense-spike',
          severity: 'info',
          domain: personalLabel,
          title: i18n.t('business:intelligence.rules.outlierTitle'),
          explanation: i18n.t('business:intelligence.rules.outlierExplanation', {
            desc: outliers[0].description,
            amount: outliers[0].amount.toFixed(2),
            avg: avg.toFixed(2),
          }),
          ruleDefinition: i18n.t('business:intelligence.rules.outlierRule'),
        });
      }
    }

    return insights;
  },

  generateDemoLinearForecast(metrics: ActualMetricsSummary): DemoForecastPoint[] {
    const baseMonthlyInflow = Math.max(1000, Math.round(metrics.combinedGrossInflow / 2));
    const baseMonthlyOutflow = Math.max(
      800,
      Math.round((metrics.combinedGrossInflow - metrics.combinedNetPosition) / 2)
    );

    const demoSuffix = i18n.t('business:intelligence.rules.demoSuffix', { defaultValue: 'Demo' });
    const now = new Date();
    const months = [1, 2, 3, 4].map((offset) => {
      const d = new Date(now.getFullYear(), now.getMonth() + offset, 1);
      let label = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      try {
        label = new Intl.DateTimeFormat(i18n.language || 'en', {
          month: 'short',
          year: 'numeric',
        }).format(d);
      } catch {
        // fallback already set
      }
      return `${label} (${demoSuffix})`;
    });

    return months.map((month, idx) => {
      const growthFactor = 1 + idx * 0.025;
      const expenseFactor = 1 + idx * 0.012;
      const projectedIncome = Math.round(baseMonthlyInflow * growthFactor);
      const projectedExpense = Math.round(baseMonthlyOutflow * expenseFactor);
      return {
        month,
        projectedIncome,
        projectedExpense,
        projectedNet: projectedIncome - projectedExpense,
      };
    });
  },
};
