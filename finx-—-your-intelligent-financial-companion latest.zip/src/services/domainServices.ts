import {
  DEMO_BILLS,
  DEMO_BUDGETS,
  DEMO_BUSINESS_EXPENSES,
  DEMO_CLIENTS,
  DEMO_DOCUMENTS,
  DEMO_MESSAGES,
  DEMO_PAPER_TRADES,
  DEMO_PAYROLL,
  DEMO_PLANS,
  DEMO_PRODUCTS,
  DEMO_PROJECTS,
  DEMO_PURCHASES,
  DEMO_SALES,
  DEMO_SAVINGS_GOALS,
  DEMO_SUBSCRIPTIONS,
  DEMO_TRANSACTIONS,
  INITIAL_EXTENSIONS,
  INITIAL_EXTENSION_LOGS,
} from '../data/mockRepository';
import {
  BillItem,
  BudgetCategory,
  BusinessExpense,
  ExtensionActivityLog,
  ExtensionDefinition,
  FinancialPlanItem,
  FinXMessage,
  PaperTradePosition,
  PayrollRecord,
  PersonalTransaction,
  ProductItem,
  PurchaseRecord,
  SaleRecord,
  SavingsGoal,
  ServiceClient,
  ServiceProject,
  SubscriptionItem,
  UploadedDocument,
} from '../types/finx';
import { generateId } from '../utils/formatters';

export interface WorkspaceSnapshot {
  transactions: PersonalTransaction[];
  budgets: BudgetCategory[];
  savingsGoals: SavingsGoal[];
  bills: BillItem[];
  subscriptions: SubscriptionItem[];
  products: ProductItem[];
  sales: SaleRecord[];
  purchases: PurchaseRecord[];
  businessExpenses: BusinessExpense[];
  clients: ServiceClient[];
  projects: ServiceProject[];
  payroll: PayrollRecord[];
  paperTrades: PaperTradePosition[];
  messages: FinXMessage[];
  documents: UploadedDocument[];
  plans: FinancialPlanItem[];
  extensions: ExtensionDefinition[];
  extensionLogs: ExtensionActivityLog[];
}

export const workspaceRepository = {
  loadInitialDemoWorkspace(): WorkspaceSnapshot {
    return {
      transactions: [...DEMO_TRANSACTIONS],
      budgets: [...DEMO_BUDGETS],
      savingsGoals: [...DEMO_SAVINGS_GOALS],
      bills: [...DEMO_BILLS],
      subscriptions: [...DEMO_SUBSCRIPTIONS],
      products: [...DEMO_PRODUCTS],
      sales: [...DEMO_SALES],
      purchases: [...DEMO_PURCHASES],
      businessExpenses: [...DEMO_BUSINESS_EXPENSES],
      clients: [...DEMO_CLIENTS],
      projects: [...DEMO_PROJECTS],
      payroll: [...DEMO_PAYROLL],
      paperTrades: [...DEMO_PAPER_TRADES],
      messages: [...DEMO_MESSAGES],
      documents: [...DEMO_DOCUMENTS],
      plans: [...DEMO_PLANS],
      extensions: INITIAL_EXTENSIONS.map((e) => ({ ...e, config: { ...e.config } })),
      extensionLogs: [...INITIAL_EXTENSION_LOGS],
    };
  },

  createInternalMessage(params: Omit<FinXMessage, 'id' | 'timestamp' | 'read' | 'isSimulatedInternal'>): FinXMessage {
    return {
      ...params,
      id: generateId('msg'),
      timestamp: new Date().toISOString(),
      read: false,
      isSimulatedInternal: true,
    };
  },
};

export const documentsService = {
  async parseUploadedFileDemo(
    file: File,
    category: UploadedDocument['documentCategory']
  ): Promise<UploadedDocument> {
    let detectedAmount: number | undefined;
    let detectedDate: string | undefined;
    let summaryText = `Demonstration parser inspected "${file.name}" (${Math.max(1, Math.round(file.size / 1024))} KB).`;

    if (file.type.startsWith('text/') || file.name.endsWith('.csv') || file.name.endsWith('.json') || file.name.endsWith('.txt')) {
      const content = await file.text().catch(() => '');
      const amountMatch = content.match(/\$?\s?(\d{1,6}(?:,\d{3})*(?:\.\d{2})?)/);
      if (amountMatch) {
        const parsed = Number(amountMatch[1].replace(/,/g, ''));
        if (Number.isFinite(parsed) && parsed > 0) detectedAmount = parsed;
      }
      const dateMatch = content.match(/(\d{4}-\d{2}-\d{2})/);
      if (dateMatch) detectedDate = dateMatch[1];
      if (content.trim().length > 0) {
        summaryText = `Demonstration text extraction scanned ${content.split(/\r?\n/).length} line(s) from "${file.name}". Backend OCR/PDF parsing requires FastAPI document service.`;
      }
    } else {
      summaryText = `File "${file.name}" queued with demonstration metadata extraction. Full binary PDF/image OCR requires Python FastAPI document pipeline.`;
    }

    return {
      id: generateId('doc'),
      fileName: file.name,
      fileType: file.type || 'application/octet-stream',
      fileSizeKb: Math.max(1, Math.round(file.size / 1024)),
      documentCategory: category,
      uploadedAt: new Date().toISOString(),
      status: 'Processed (Demo)',
      extractedSummary: summaryText,
      extractedFields: {
        vendorOrEntity: file.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' '),
        documentDate: detectedDate || new Date().toISOString().slice(0, 10),
        detectedAmount: detectedAmount ?? 145.0,
        suggestedCategory: category === 'Invoice' ? 'Software & Tools' : 'Food & Dining',
        referenceNumber: `DOC-${Math.floor(1000 + Math.random() * 9000)}`,
      },
    };
  },
};
