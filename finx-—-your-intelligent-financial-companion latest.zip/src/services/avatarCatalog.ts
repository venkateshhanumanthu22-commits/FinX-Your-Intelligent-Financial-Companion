import { AvatarCategory } from '../types/finx';

export interface AvatarPreset {
  id: string;
  category: AvatarCategory;
  label: string;
  bgFrom: string;
  bgTo: string;
  accent: string;
  skin: string;
  hair: string;
  outfit: string;
  styleVariant: 'classic' | 'modern' | 'editorial';
}

export const AVATAR_PRESETS: AvatarPreset[] = [
  // Neutral (Default — never inferred from name)
  {
    id: 'neutral-compass',
    category: 'neutral',
    label: 'Neutral Horizon',
    bgFrom: '#0F172A',
    bgTo: '#0D9488',
    accent: '#22D3EE',
    skin: '#F1C27D',
    hair: '#1E293B',
    outfit: '#0EA5E9',
    styleVariant: 'modern',
  },
  {
    id: 'neutral-prism',
    category: 'neutral',
    label: 'Neutral Prism',
    bgFrom: '#1E1B4B',
    bgTo: '#6D28D9',
    accent: '#A78BFA',
    skin: '#E0AC69',
    hair: '#334155',
    outfit: '#7C3AED',
    styleVariant: 'editorial',
  },
  // Male options
  {
    id: 'male-executive',
    category: 'male',
    label: 'Male Executive',
    bgFrom: '#0F172A',
    bgTo: '#1E3A8A',
    accent: '#38BDF8',
    skin: '#E0AC69',
    hair: '#1E293B',
    outfit: '#1D4ED8',
    styleVariant: 'classic',
  },
  {
    id: 'male-founder',
    category: 'male',
    label: 'Male Founder',
    bgFrom: '#064E3B',
    bgTo: '#0D9488',
    accent: '#34D399',
    skin: '#C68642',
    hair: '#0F172A',
    outfit: '#047857',
    styleVariant: 'modern',
  },
  // Female options
  {
    id: 'female-advisor',
    category: 'female',
    label: 'Female Advisor',
    bgFrom: '#4C1D95',
    bgTo: '#7C3AED',
    accent: '#F472B6',
    skin: '#F1C27D',
    hair: '#292524',
    outfit: '#6D28D9',
    styleVariant: 'classic',
  },
  {
    id: 'female-strategist',
    category: 'female',
    label: 'Female Strategist',
    bgFrom: '#0F172A',
    bgTo: '#0369A1',
    accent: '#2DD4BF',
    skin: '#C68642',
    hair: '#1C1917',
    outfit: '#0D9488',
    styleVariant: 'editorial',
  },
];

export function getPresetsForCategory(category: AvatarCategory): AvatarPreset[] {
  return AVATAR_PRESETS.filter((p) => p.category === category);
}

export function getDefaultPresetForCategory(category: AvatarCategory): AvatarPreset {
  return AVATAR_PRESETS.find((p) => p.category === category) || AVATAR_PRESETS[0];
}

export function getPresetById(id?: string, fallbackCategory: AvatarCategory = 'neutral'): AvatarPreset {
  return (
    AVATAR_PRESETS.find((p) => p.id === id) ||
    AVATAR_PRESETS.find((p) => p.category === fallbackCategory) ||
    AVATAR_PRESETS[0]
  );
}

/**
 * Compresses an uploaded user profile photo to a square 128x128 JPEG data URL (< 45 KB)
 * so it complies cleanly with Firestore security size limits (<= 65,000 chars).
 */
export async function compressAvatarImageFile(file: File): Promise<string> {
  if (!file.type.startsWith('image/')) {
    throw new Error('Please choose a valid image file (PNG, JPG, or WebP).');
  }

  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Failed to read selected image file.'));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Unable to decode selected image.'));
    image.src = dataUrl;
  });

  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas rendering is unavailable in this browser.');

  const minDim = Math.min(img.width, img.height);
  const sx = (img.width - minDim) / 2;
  const sy = (img.height - minDim) / 2;
  ctx.drawImage(img, sx, sy, minDim, minDim, 0, 0, size, size);

  let compressed = canvas.toDataURL('image/jpeg', 0.8);
  if (compressed.length > 55000) {
    compressed = canvas.toDataURL('image/jpeg', 0.6);
  }
  if (compressed.length > 64000) {
    throw new Error('Image remains too large after compression. Please select a simpler photo.');
  }
  return compressed;
}
