import { User as FirebaseUser } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import {
  AuditLogEntry,
  AvatarCategory,
  DisplayCurrency,
  DomainId,
  LanguagePreferences,
  ThemeMode,
  UserProfile,
  WorkspaceProfile,
  YtdUnifiedTransaction,
} from '../types/finx';
import { generateId } from '../utils/formatters';

export type LedgerRecordKind =
  | 'personal_tx'
  | 'product_sale'
  | 'product_purchase'
  | 'business_expense'
  | 'service_payment'
  | 'payroll';

export interface FirestoreLedgerEntry {
  id: string;
  ownerId: string;
  workspaceId: string;
  domain: DomainId;
  recordKind: LedgerRecordKind;
  txType: 'income' | 'expense';
  title: string;
  category: string;
  amount: number;
  quantity?: number;
  unitPrice?: number;
  date: string;
  counterparty?: string;
  paymentMethod?: string;
  referenceCode?: string;
  notes?: string;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export interface FirestoreDomainEntity {
  id: string;
  ownerId: string;
  workspaceId: string;
  domain: DomainId;
  entityType: string;
  title: string;
  status: string;
  payload: Record<string, string | number | boolean>;
  createdAt?: unknown;
  updatedAt?: unknown;
}

export const ALL_DOMAIN_IDS: DomainId[] = [
  'personal-finance',
  'product-business',
  'service-business',
  'investment-knowledge',
  'financial-intelligence',
];

function clampStr(v: unknown, max: number, fallback = ''): string {
  const s = typeof v === 'string' ? v.trim() : fallback;
  return s.slice(0, max);
}

function sanitizeId(raw: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 120);
  return cleaned || generateId('id');
}

function toIsoDate(ts: unknown): string {
  if (ts && typeof (ts as { toDate?: () => Date }).toDate === 'function') {
    return (ts as { toDate: () => Date }).toDate().toISOString();
  }
  if (typeof ts === 'string') return ts;
  return new Date().toISOString();
}

export interface OnboardingOverrides {
  name?: string;
  role?: UserProfile['role'];
  businessName?: string;
  avatarCategory?: AvatarCategory;
  avatarPresetId?: string;
  customPhotoDataUrl?: string;
  enabledDomains?: DomainId[];
  currency?: DisplayCurrency;
  languagePrefs?: LanguagePreferences;
  theme?: ThemeMode;
}

export const firestoreRepository = {
  async ensureUserAndDefaultWorkspace(
    fbUser: FirebaseUser,
    overrides?: OnboardingOverrides
  ): Promise<{
    user: UserProfile;
    workspaces: WorkspaceProfile[];
    languagePrefs: Partial<LanguagePreferences>;
    theme: ThemeMode;
    reducedMotion: boolean;
    isNewUser: boolean;
  }> {
    const uid = fbUser.uid;
    const userPath = `users/${uid}`;
    const userRef = doc(db, 'users', uid);

    let existingSnap;
    try {
      existingSnap = await getDoc(userRef);
    } catch (err) {
      handleFirestoreError(err, OperationType.GET, userPath);
    }

    if (existingSnap && existingSnap.exists()) {
      const data = existingSnap.data();

      // If caller passed explicit onboarding overrides on sign-up/profile update, persist safely
      if (overrides && (overrides.avatarCategory || overrides.enabledDomains || overrides.name)) {
        const updatePayload: Record<string, unknown> = {
          updatedAt: serverTimestamp(),
        };
        if (overrides.name) updatePayload.name = clampStr(overrides.name, 80);
        if (overrides.role) updatePayload.role = clampStr(overrides.role, 60);
        if (overrides.avatarCategory) updatePayload.avatarCategory = overrides.avatarCategory;
        if (overrides.avatarPresetId) updatePayload.avatarPresetId = clampStr(overrides.avatarPresetId, 64);
        if (overrides.customPhotoDataUrl !== undefined) {
          updatePayload.customPhotoDataUrl = clampStr(overrides.customPhotoDataUrl, 65000);
        }
        if (overrides.enabledDomains && overrides.enabledDomains.length > 0) {
          updatePayload.enabledDomains = overrides.enabledDomains.slice(0, 5);
        }
        try {
          await updateDoc(userRef, updatePayload);
        } catch (err) {
          handleFirestoreError(err, OperationType.UPDATE, userPath);
        }
      }

      const freshSnap = await getDoc(userRef);
      const d = freshSnap.data() || data;

      const workspaces = await this.listWorkspaces(uid);
      const activeWsId =
        workspaces.find((w) => w.id === d.activeWorkspaceId)?.id || workspaces[0]?.id || 'ws-default';
      const activeWs = workspaces.find((w) => w.id === activeWsId);

      const user: UserProfile = {
        id: uid,
        name: clampStr(d.name, 80, fbUser.displayName || 'FinX Member'),
        email: clampStr(d.email, 160, fbUser.email || ''),
        role: (d.role as UserProfile['role']) || 'Individual & Entrepreneur',
        businessName: activeWs?.name || clampStr(fbUser.displayName ? `${fbUser.displayName} Workspace` : 'My FinX Workspace', 80),
        currency: (d.currency as DisplayCurrency) || 'USD',
        avatarUrl: d.customPhotoDataUrl || '',
        avatarCategory: (d.avatarCategory as AvatarCategory) || 'neutral',
        avatarPresetId: clampStr(d.avatarPresetId, 64, 'neutral-compass'),
        customPhotoDataUrl: clampStr(d.customPhotoDataUrl, 65000) || undefined,
        enabledDomains: Array.isArray(d.enabledDomains) && d.enabledDomains.length > 0
          ? (d.enabledDomains as DomainId[])
          : [...ALL_DOMAIN_IDS],
        activeWorkspaceId: activeWsId,
        isDemoAccount: false,
        createdAt: toIsoDate(d.createdAt),
      };

      return {
        user,
        workspaces,
        languagePrefs: {
          useSameLanguageEverywhere: Boolean(d.useSameLanguageEverywhere ?? true),
          displayLanguage: (d.displayLanguage || 'en') as LanguagePreferences['displayLanguage'],
          textAssistantLanguage: (d.textAssistantLanguage || 'en') as LanguagePreferences['textAssistantLanguage'],
          voiceInputLocale: d.voiceInputLocale || 'en-US',
          voiceOutputLocale: d.voiceOutputLocale || 'en-US',
          voiceOutputVoiceURI: d.voiceOutputVoiceURI || 'auto',
          autoSpeakResponses: Boolean(d.autoSpeakResponses ?? true),
          displayCurrency: (d.currency as DisplayCurrency) || 'USD',
          neuralVoiceName: (d.neuralVoiceName as LanguagePreferences['neuralVoiceName']) || 'Kore',
          preferNeuralVoice: d.preferNeuralVoice !== undefined ? Boolean(d.preferNeuralVoice) : true,
          handsFreeLoop: d.handsFreeLoop !== undefined ? Boolean(d.handsFreeLoop) : true,
        },
        theme: (d.theme as ThemeMode) || 'dark',
        reducedMotion: Boolean(d.reducedMotion ?? false),
        isNewUser: false,
      };
    }

    // Create brand-new verified Firestore profile + initial default workspace atomically
    const defaultWsId = sanitizeId(`ws_${uid.slice(0, 8)}_primary`);
    const chosenDomains: DomainId[] =
      overrides?.enabledDomains && overrides.enabledDomains.length > 0
        ? overrides.enabledDomains.slice(0, 5)
        : [...ALL_DOMAIN_IDS];

    const displayName = clampStr(
      overrides?.name || fbUser.displayName || fbUser.email?.split('@')[0] || 'FinX Member',
      80
    );
    const businessName = clampStr(
      overrides?.businessName || `${displayName} Workspace`,
      80
    );
    const currency: DisplayCurrency = overrides?.currency || overrides?.languagePrefs?.displayCurrency || 'USD';
    const lp = overrides?.languagePrefs;

    const batch = writeBatch(db);
    const profilePayload: Record<string, unknown> = {
      uid,
      name: displayName,
      email: clampStr(fbUser.email || '', 160),
      avatarCategory: overrides?.avatarCategory || 'neutral',
      avatarPresetId: clampStr(overrides?.avatarPresetId, 64, 'neutral-compass'),
      role: clampStr(overrides?.role || 'Individual & Entrepreneur', 60),
      currency,
      enabledDomains: chosenDomains,
      activeWorkspaceId: defaultWsId,
      useSameLanguageEverywhere: lp?.useSameLanguageEverywhere ?? true,
      displayLanguage: clampStr(lp?.displayLanguage || 'en', 10),
      textAssistantLanguage: clampStr(lp?.textAssistantLanguage || 'en', 10),
      voiceInputLocale: clampStr(lp?.voiceInputLocale || 'en-US', 20),
      voiceOutputLocale: clampStr(lp?.voiceOutputLocale || 'en-US', 20),
      voiceOutputVoiceURI: clampStr(lp?.voiceOutputVoiceURI || 'auto', 160),
      autoSpeakResponses: lp?.autoSpeakResponses ?? true,
      neuralVoiceName: clampStr(lp?.neuralVoiceName || 'Kore', 24),
      preferNeuralVoice: lp?.preferNeuralVoice ?? true,
      handsFreeLoop: lp?.handsFreeLoop ?? true,
      voiceSpeechRate: 1.0,
      reducedMotion: false,
      theme: overrides?.theme || 'dark',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    if (overrides?.customPhotoDataUrl) {
      profilePayload.customPhotoDataUrl = clampStr(overrides.customPhotoDataUrl, 65000);
    }

    const wsRef = doc(db, 'users', uid, 'workspaces', defaultWsId);
    const wsPayload = {
      id: defaultWsId,
      ownerId: uid,
      name: businessName,
      domain: chosenDomains[0] || 'personal-finance',
      description: 'Primary FinX financial workspace',
      currency,
      isDefault: true,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };

    const auditId = sanitizeId(`log_${Date.now().toString(36)}`);
    const auditRef = doc(db, 'users', uid, 'auditLogs', auditId);
    const auditPayload = {
      id: auditId,
      ownerId: uid,
      workspaceId: defaultWsId,
      action: 'WORKSPACE_INITIALIZED',
      domain: 'system',
      summary: `Created verified FinX profile and workspace "${businessName}".`,
      createdAt: serverTimestamp(),
    };

    batch.set(userRef, profilePayload);
    batch.set(wsRef, wsPayload);
    batch.set(auditRef, auditPayload);

    try {
      await batch.commit();
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, userPath);
    }

    const createdWs: WorkspaceProfile = {
      id: defaultWsId,
      ownerId: uid,
      name: businessName,
      domain: chosenDomains[0] || 'personal-finance',
      description: 'Primary FinX financial workspace',
      currency,
      isDefault: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const user: UserProfile = {
      id: uid,
      name: displayName,
      email: clampStr(fbUser.email || '', 160),
      role: (overrides?.role || 'Individual & Entrepreneur') as UserProfile['role'],
      businessName,
      currency,
      avatarUrl: overrides?.customPhotoDataUrl || '',
      avatarCategory: overrides?.avatarCategory || 'neutral',
      avatarPresetId: clampStr(overrides?.avatarPresetId, 64, 'neutral-compass'),
      customPhotoDataUrl: overrides?.customPhotoDataUrl,
      enabledDomains: chosenDomains,
      activeWorkspaceId: defaultWsId,
      isDemoAccount: false,
      createdAt: new Date().toISOString(),
    };

    return {
      user,
      workspaces: [createdWs],
      languagePrefs: lp || {},
      theme: overrides?.theme || 'dark',
      reducedMotion: false,
      isNewUser: true,
    };
  },

  async updateUserProfileDoc(
    uid: string,
    patch: Partial<{
      name: string;
      avatarCategory: AvatarCategory;
      avatarPresetId: string;
      customPhotoDataUrl: string;
      role: UserProfile['role'];
      currency: DisplayCurrency;
      enabledDomains: DomainId[];
      activeWorkspaceId: string;
      useSameLanguageEverywhere: boolean;
      displayLanguage: string;
      textAssistantLanguage: string;
      voiceInputLocale: string;
      voiceOutputLocale: string;
      voiceOutputVoiceURI: string;
      autoSpeakResponses: boolean;
      neuralVoiceName: LanguagePreferences['neuralVoiceName'];
      preferNeuralVoice: boolean;
      handsFreeLoop: boolean;
      voiceSpeechRate: number;
      reducedMotion: boolean;
      theme: ThemeMode;
    }>
  ): Promise<void> {
    if (!auth.currentUser || auth.currentUser.uid !== uid) return;
    const path = `users/${uid}`;
    const safePatch: Record<string, unknown> = { updatedAt: serverTimestamp() };

    if (patch.name !== undefined) safePatch.name = clampStr(patch.name, 80, 'Member');
    if (patch.avatarCategory !== undefined) safePatch.avatarCategory = patch.avatarCategory;
    if (patch.avatarPresetId !== undefined) safePatch.avatarPresetId = clampStr(patch.avatarPresetId, 64, 'neutral-compass');
    if (patch.customPhotoDataUrl !== undefined) safePatch.customPhotoDataUrl = clampStr(patch.customPhotoDataUrl, 65000);
    if (patch.role !== undefined) safePatch.role = clampStr(patch.role, 60);
    if (patch.currency !== undefined) safePatch.currency = patch.currency;
    if (patch.enabledDomains !== undefined && patch.enabledDomains.length > 0) {
      safePatch.enabledDomains = patch.enabledDomains.slice(0, 5);
    }
    if (patch.activeWorkspaceId !== undefined) safePatch.activeWorkspaceId = sanitizeId(patch.activeWorkspaceId);
    if (patch.useSameLanguageEverywhere !== undefined) safePatch.useSameLanguageEverywhere = patch.useSameLanguageEverywhere;
    if (patch.displayLanguage !== undefined) safePatch.displayLanguage = clampStr(patch.displayLanguage, 10, 'en');
    if (patch.textAssistantLanguage !== undefined) safePatch.textAssistantLanguage = clampStr(patch.textAssistantLanguage, 10, 'en');
    if (patch.voiceInputLocale !== undefined) safePatch.voiceInputLocale = clampStr(patch.voiceInputLocale, 20, 'en-US');
    if (patch.voiceOutputLocale !== undefined) safePatch.voiceOutputLocale = clampStr(patch.voiceOutputLocale, 20, 'en-US');
    if (patch.voiceOutputVoiceURI !== undefined) safePatch.voiceOutputVoiceURI = clampStr(patch.voiceOutputVoiceURI, 160, 'auto');
    if (patch.autoSpeakResponses !== undefined) safePatch.autoSpeakResponses = patch.autoSpeakResponses;
    if (patch.neuralVoiceName !== undefined) safePatch.neuralVoiceName = clampStr(patch.neuralVoiceName, 24, 'Kore');
    if (patch.preferNeuralVoice !== undefined) safePatch.preferNeuralVoice = patch.preferNeuralVoice;
    if (patch.handsFreeLoop !== undefined) safePatch.handsFreeLoop = patch.handsFreeLoop;
    if (patch.voiceSpeechRate !== undefined) safePatch.voiceSpeechRate = Math.min(2, Math.max(0.5, patch.voiceSpeechRate));
    if (patch.reducedMotion !== undefined) safePatch.reducedMotion = patch.reducedMotion;
    if (patch.theme !== undefined) safePatch.theme = patch.theme;

    try {
      await updateDoc(doc(db, 'users', uid), safePatch);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  },

  async updateWorkspaceName(uid: string, workspaceId: string, name: string): Promise<void> {
    if (!auth.currentUser || auth.currentUser.uid !== uid || !workspaceId) return;
    const safeWsId = sanitizeId(workspaceId);
    const path = `users/${uid}/workspaces/${safeWsId}`;
    const safeName = clampStr(name, 80, 'My FinX Workspace');
    try {
      await updateDoc(doc(db, 'users', uid, 'workspaces', safeWsId), {
        name: safeName,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, path);
    }
  },

  async listWorkspaces(uid: string): Promise<WorkspaceProfile[]> {
    const path = `users/${uid}/workspaces`;
    try {
      const q = query(collection(db, 'users', uid, 'workspaces'), where('ownerId', '==', uid));
      const snap = await getDocs(q);
      return snap.docs.map((d) => {
        const raw = d.data();
        return {
          id: d.id,
          ownerId: String(raw.ownerId || uid),
          name: clampStr(raw.name, 80, 'Workspace'),
          domain: (raw.domain as DomainId) || 'personal-finance',
          description: clampStr(raw.description, 240) || undefined,
          currency: (raw.currency as DisplayCurrency) || 'USD',
          isDefault: Boolean(raw.isDefault),
          createdAt: toIsoDate(raw.createdAt),
          updatedAt: toIsoDate(raw.updatedAt),
        };
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.LIST, path);
    }
  },

  async createWorkspaceDoc(
    uid: string,
    input: { name: string; domain: DomainId; description?: string; currency: DisplayCurrency }
  ): Promise<WorkspaceProfile> {
    const wsId = sanitizeId(`ws_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`);
    const path = `users/${uid}/workspaces/${wsId}`;
    const payload = {
      id: wsId,
      ownerId: uid,
      name: clampStr(input.name, 80, 'New Business'),
      domain: input.domain,
      description: clampStr(input.description || `${input.name} workspace`, 240),
      currency: input.currency,
      isDefault: false,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    try {
      await setDoc(doc(db, 'users', uid, 'workspaces', wsId), payload);
      await this.appendAuditLog(
        uid,
        wsId,
        'WORKSPACE_CREATED',
        input.domain,
        `Created isolated business workspace "${payload.name}" (${input.domain}).`
      );
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
    return {
      id: wsId,
      ownerId: uid,
      name: payload.name,
      domain: input.domain,
      description: payload.description,
      currency: input.currency,
      isDefault: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
  },

  async upsertLedgerEntry(
    uid: string,
    workspaceId: string,
    entry: Omit<FirestoreLedgerEntry, 'ownerId' | 'workspaceId' | 'createdAt' | 'updatedAt'> & { isNew?: boolean }
  ): Promise<void> {
    const entryId = sanitizeId(entry.id);
    const path = `users/${uid}/workspaces/${workspaceId}/ledgerEntries/${entryId}`;
    const ref = doc(db, 'users', uid, 'workspaces', workspaceId, 'ledgerEntries', entryId);

    const baseData: Record<string, unknown> = {
      id: entryId,
      ownerId: uid,
      workspaceId,
      domain: entry.domain,
      recordKind: entry.recordKind,
      txType: entry.txType,
      title: clampStr(entry.title, 140, 'Entry'),
      category: clampStr(entry.category, 60, 'General'),
      amount: Math.min(1000000000, Math.max(0.01, Number(entry.amount) || 0.01)),
      date: clampStr(entry.date, 10, new Date().toISOString().slice(0, 10)),
      updatedAt: serverTimestamp(),
    };

    if (entry.quantity !== undefined) baseData.quantity = Math.max(0, Number(entry.quantity) || 0);
    if (entry.unitPrice !== undefined) baseData.unitPrice = Math.max(0, Number(entry.unitPrice) || 0);
    if (entry.counterparty) baseData.counterparty = clampStr(entry.counterparty, 100);
    if (entry.paymentMethod) baseData.paymentMethod = clampStr(entry.paymentMethod, 40);
    if (entry.referenceCode) baseData.referenceCode = clampStr(entry.referenceCode, 64);
    if (entry.notes) baseData.notes = clampStr(entry.notes, 400);

    try {
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        await setDoc(ref, { ...baseData, createdAt: serverTimestamp() });
      } else {
        await updateDoc(ref, {
          title: baseData.title,
          category: baseData.category,
          amount: baseData.amount,
          date: baseData.date,
          ...(baseData.quantity !== undefined ? { quantity: baseData.quantity } : {}),
          ...(baseData.unitPrice !== undefined ? { unitPrice: baseData.unitPrice } : {}),
          ...(baseData.counterparty !== undefined ? { counterparty: baseData.counterparty } : {}),
          ...(baseData.paymentMethod !== undefined ? { paymentMethod: baseData.paymentMethod } : {}),
          ...(baseData.notes !== undefined ? { notes: baseData.notes } : {}),
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  },

  async deleteLedgerEntry(uid: string, workspaceId: string, entryId: string): Promise<void> {
    const safeId = sanitizeId(entryId);
    const path = `users/${uid}/workspaces/${workspaceId}/ledgerEntries/${safeId}`;
    try {
      await deleteDoc(doc(db, 'users', uid, 'workspaces', workspaceId, 'ledgerEntries', safeId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  },

  async upsertDomainEntity(
    uid: string,
    workspaceId: string,
    entity: Omit<FirestoreDomainEntity, 'ownerId' | 'workspaceId' | 'createdAt' | 'updatedAt'>
  ): Promise<void> {
    const safeId = sanitizeId(entity.id);
    const path = `users/${uid}/workspaces/${workspaceId}/domainEntities/${safeId}`;
    const ref = doc(db, 'users', uid, 'workspaces', workspaceId, 'domainEntities', safeId);

    const flatPayload: Record<string, string | number | boolean> = {};
    Object.entries(entity.payload || {})
      .slice(0, 24)
      .forEach(([k, v]) => {
        if (typeof v === 'string') flatPayload[k] = v.slice(0, 500);
        else if (typeof v === 'number' && Number.isFinite(v)) flatPayload[k] = v;
        else if (typeof v === 'boolean') flatPayload[k] = v;
      });

    try {
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        await setDoc(ref, {
          id: safeId,
          ownerId: uid,
          workspaceId,
          domain: entity.domain,
          entityType: clampStr(entity.entityType, 40, 'item'),
          title: clampStr(entity.title, 160, 'Record'),
          status: clampStr(entity.status, 40, 'Active'),
          payload: flatPayload,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } else {
        await updateDoc(ref, {
          title: clampStr(entity.title, 160, 'Record'),
          status: clampStr(entity.status, 40, 'Active'),
          payload: flatPayload,
          updatedAt: serverTimestamp(),
        });
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  },

  async deleteDomainEntity(uid: string, workspaceId: string, entityId: string): Promise<void> {
    const safeId = sanitizeId(entityId);
    const path = `users/${uid}/workspaces/${workspaceId}/domainEntities/${safeId}`;
    try {
      await deleteDoc(doc(db, 'users', uid, 'workspaces', workspaceId, 'domainEntities', safeId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, path);
    }
  },

  subscribeWorkspaceCollections(
    uid: string,
    workspaceId: string,
    onLedger: (entries: FirestoreLedgerEntry[]) => void,
    onEntities: (entities: FirestoreDomainEntity[]) => void,
    onAudit: (logs: AuditLogEntry[]) => void
  ): () => void {
    const ledgerPath = `users/${uid}/workspaces/${workspaceId}/ledgerEntries`;
    const entitiesPath = `users/${uid}/workspaces/${workspaceId}/domainEntities`;
    const auditPath = `users/${uid}/auditLogs`;

    const ledgerQ = query(
      collection(db, 'users', uid, 'workspaces', workspaceId, 'ledgerEntries'),
      where('ownerId', '==', uid),
      where('workspaceId', '==', workspaceId)
    );
    const entitiesQ = query(
      collection(db, 'users', uid, 'workspaces', workspaceId, 'domainEntities'),
      where('ownerId', '==', uid),
      where('workspaceId', '==', workspaceId)
    );
    const auditQ = query(
      collection(db, 'users', uid, 'auditLogs'),
      where('ownerId', '==', uid),
      orderBy('createdAt', 'desc'),
      limit(30)
    );

    const unsub1 = onSnapshot(
      ledgerQ,
      (snap) => {
        onLedger(snap.docs.map((d) => d.data() as FirestoreLedgerEntry));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, ledgerPath)
    );

    const unsub2 = onSnapshot(
      entitiesQ,
      (snap) => {
        onEntities(snap.docs.map((d) => d.data() as FirestoreDomainEntity));
      },
      (err) => handleFirestoreError(err, OperationType.LIST, entitiesPath)
    );

    const unsub3 = onSnapshot(
      auditQ,
      (snap) => {
        onAudit(
          snap.docs.map((d) => {
            const raw = d.data();
            return {
              id: d.id,
              ownerId: String(raw.ownerId || uid),
              workspaceId: String(raw.workspaceId || workspaceId),
              action: clampStr(raw.action, 80),
              domain: clampStr(raw.domain, 40),
              summary: clampStr(raw.summary, 240),
              createdAt: toIsoDate(raw.createdAt),
            };
          })
        );
      },
      (err) => handleFirestoreError(err, OperationType.LIST, auditPath)
    );

    return () => {
      unsub1();
      unsub2();
      unsub3();
    };
  },

  async appendAuditLog(
    uid: string,
    workspaceId: string,
    action: string,
    domain: string,
    summary: string
  ): Promise<void> {
    if (!auth.currentUser || auth.currentUser.uid !== uid) return;
    const logId = sanitizeId(`log_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`);
    const path = `users/${uid}/auditLogs/${logId}`;
    try {
      await setDoc(doc(db, 'users', uid, 'auditLogs', logId), {
        id: logId,
        ownerId: uid,
        workspaceId: sanitizeId(workspaceId),
        action: clampStr(action, 80, 'ACTION'),
        domain: clampStr(domain, 40, 'system'),
        summary: clampStr(summary, 240, 'Workspace update recorded.'),
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, path);
    }
  },

  async fetchAllYtdLedgerEntries(
    uid: string,
    workspaces: WorkspaceProfile[]
  ): Promise<YtdUnifiedTransaction[]> {
    const all: YtdUnifiedTransaction[] = [];
    for (const ws of workspaces) {
      const path = `users/${uid}/workspaces/${ws.id}/ledgerEntries`;
      try {
        const q = query(
          collection(db, 'users', uid, 'workspaces', ws.id, 'ledgerEntries'),
          where('ownerId', '==', uid),
          where('workspaceId', '==', ws.id)
        );
        const snap = await getDocs(q);
        snap.docs.forEach((d) => {
          const r = d.data() as FirestoreLedgerEntry;
          all.push({
            id: r.id,
            workspaceId: ws.id,
            workspaceName: ws.name,
            domain: r.domain,
            recordKind: r.recordKind,
            txType: r.txType,
            title: r.title,
            category: r.category,
            amount: r.amount,
            date: r.date,
            counterparty: r.counterparty,
            paymentMethod: r.paymentMethod,
          });
        });
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, path);
      }
    }
    return all.sort((a, b) => b.date.localeCompare(a.date));
  },
};
