import React from 'react';
import { Moon, Sun } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { useFinX } from '../context/FinXContext';

interface ThemeToggleProps {
  compact?: boolean;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({ compact = false }) => {
  const { theme, toggleTheme } = useFinX();
  const { t } = useTranslation('common');
  const isDark = theme === 'dark';

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={isDark ? t('actions.lightMode') : t('actions.darkMode')}
      title={isDark ? t('actions.lightMode') : t('actions.darkMode')}
      className={`inline-flex items-center justify-center gap-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#172235] text-slate-700 dark:text-[#F8FAFC] hover:border-teal-500/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-500 transition-colors whitespace-nowrap shrink-0 ${
        compact ? 'p-2 min-h-[38px] min-w-[38px]' : 'px-3.5 py-2 text-xs font-medium min-h-[38px]'
      }`}
    >
      {isDark ? (
        <Sun className="w-4 h-4 text-amber-400 shrink-0" />
      ) : (
        <Moon className="w-4 h-4 text-slate-700 shrink-0" />
      )}
      {!compact && (
        <span>{isDark ? t('actions.lightMode') : t('actions.darkMode')}</span>
      )}
    </button>
  );
};
