import React, { useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  AlertCircle,
  ArrowDownLeft,
  ArrowUpRight,
  Calendar,
  Download,
  RefreshCw,
  Search,
  X,
} from 'lucide-react';
import { useFinX } from '../context/FinXContext';
import { getLocalizedDomainTheme } from '../config/domainThemes';
import { DomainId, YtdUnifiedTransaction } from '../types/finx';
import { formatCurrency } from '../utils/formatters';

type CalendarMode = 'calendar' | 'fiscal';
type PeriodGrouping = 'monthly' | 'quarterly' | 'yearly';

function getFiscalRange(year: number, mode: CalendarMode): { start: string; end: string; label: string } {
  if (mode === 'calendar') {
    return { start: `${year}-01-01`, end: `${year}-12-31`, label: `CY ${year} (Jan – Dec)` };
  }
  return { start: `${year}-04-01`, end: `${year + 1}-03-31`, label: `FY ${year}–${String(year + 1).slice(-2)} (Apr – Mar)` };
}

function getBucketKey(dateStr: string, grouping: PeriodGrouping, mode: CalendarMode): string {
  const [yStr, mStr] = dateStr.split('-');
  const y = Number(yStr);
  const m = Number(mStr);
  if (!y || !m) return 'Unknown';

  if (grouping === 'yearly') {
    if (mode === 'calendar') return `${y}`;
    const fyStart = m >= 4 ? y : y - 1;
    return `FY ${fyStart}-${String(fyStart + 1).slice(-2)}`;
  }

  if (grouping === 'quarterly') {
    if (mode === 'calendar') {
      const q = Math.ceil(m / 3);
      return `${y} Q${q}`;
    }
    const fiscalMonthIdx = (m - 4 + 12) % 12; // 0=Apr .. 11=Mar
    const fq = Math.floor(fiscalMonthIdx / 3) + 1;
    const fyStart = m >= 4 ? y : y - 1;
    return `FY${String(fyStart).slice(-2)} Q${fq}`;
  }

  return `${yStr}-${mStr}`;
}

export const YtdTransactionsDrawer: React.FC = () => {
  const { t } = useTranslation('common');
  const {
    ytdDrawerOpen,
    setYtdDrawerOpen,
    ytdTransactions,
    ytdLoading,
    ytdError,
    ytdLastUpdated,
    refreshYtdTransactions,
    languagePrefs,
    session,
  } = useFinX();

  const currentYear = new Date().getFullYear();
  const [selectedYear, setSelectedYear] = useState<number>(currentYear);
  const [calendarMode, setCalendarMode] = useState<CalendarMode>('calendar');
  const [grouping, setGrouping] = useState<PeriodGrouping>('monthly');
  const [domainFilter, setDomainFilter] = useState<DomainId | 'all'>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | 'income' | 'expense'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const enabledDomains = useMemo(
    () => new Set<DomainId>(session?.user.enabledDomains || ['personal-finance', 'product-business', 'service-business']),
    [session?.user.enabledDomains]
  );

  const range = useMemo(() => getFiscalRange(selectedYear, calendarMode), [selectedYear, calendarMode]);

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return ytdTransactions.filter((tx) => {
      if (!enabledDomains.has(tx.domain)) return false;
      if (tx.date < range.start || tx.date > range.end) return false;
      if (domainFilter !== 'all' && tx.domain !== domainFilter) return false;
      if (typeFilter !== 'all' && tx.txType !== typeFilter) return false;
      if (q) {
        const hay = `${tx.title} ${tx.category} ${tx.counterparty || ''} ${tx.workspaceName}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [domainFilter, enabledDomains, range.end, range.start, searchQuery, typeFilter, ytdTransactions]);

  const summary = useMemo(() => {
    let income = 0;
    let expense = 0;
    filtered.forEach((tx) => {
      if (tx.txType === 'income') income += tx.amount;
      else expense += tx.amount;
    });
    return {
      income,
      expense,
      net: income - expense,
      count: filtered.length,
    };
  }, [filtered]);

  const groupedBuckets = useMemo(() => {
    const map = new Map<string, { label: string; income: number; expense: number; count: number }>();
    filtered.forEach((tx) => {
      const key = getBucketKey(tx.date, grouping, calendarMode);
      const curr = map.get(key) || { label: key, income: 0, expense: 0, count: 0 };
      if (tx.txType === 'income') curr.income += tx.amount;
      else curr.expense += tx.amount;
      curr.count += 1;
      map.set(key, curr);
    });
    return Array.from(map.values()).sort((a, b) => b.label.localeCompare(a.label));
  }, [calendarMode, filtered, grouping]);

  if (!ytdDrawerOpen) return null;

  const yearOptions = Array.from(
    new Set([currentYear, currentYear - 1, currentYear - 2])
  ).sort((a, b) => b - a);

  const exportCsv = () => {
    const rows = [
      ['Date', 'Workspace', 'Domain', 'Kind', 'Type', 'Title', 'Category', 'Counterparty', 'Amount'].join(','),
      ...filtered.map((tx: YtdUnifiedTransaction) =>
        [
          tx.date,
          `"${tx.workspaceName.replace(/"/g, '""')}"`,
          tx.domain,
          tx.recordKind,
          tx.txType,
          `"${tx.title.replace(/"/g, '""')}"`,
          `"${tx.category.replace(/"/g, '""')}"`,
          `"${(tx.counterparty || '').replace(/"/g, '""')}"`,
          tx.txType === 'income' ? tx.amount : -tx.amount,
        ].join(',')
      ),
    ];
    const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `finx-ytd-${selectedYear}-${calendarMode}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/60 backdrop-blur-sm">
      <div
        role="dialog"
        aria-modal="true"
        aria-label={t('ytd.title')}
        className="relative flex h-full w-full max-w-4xl flex-col bg-white dark:bg-[#0f172a] border-s border-slate-200 dark:border-slate-800 shadow-2xl"
      >
        {/* Drawer Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 py-4">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-teal-500 shrink-0" />
              <h2 className="text-base sm:text-lg font-display font-bold text-slate-900 dark:text-white truncate">
                {t('ytd.title')}
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {t('ytd.subtitle')} · {range.label}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={refreshYtdTransactions}
              disabled={ytdLoading}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${ytdLoading ? 'animate-spin' : ''}`} />
              <span>{t('ytd.refresh')}</span>
            </button>

            <button
              type="button"
              onClick={exportCsv}
              disabled={filtered.length === 0}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 disabled:opacity-50 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{t('actions.exportCsv')}</span>
            </button>

            <button
              type="button"
              onClick={() => setYtdDrawerOpen(false)}
              aria-label={t('actions.close')}
              className="p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Controls Bar */}
        <div className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/50 px-4 sm:px-6 py-3 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <select
              aria-label={t('ytd.financialYear')}
              value={selectedYear}
              onChange={(e) => setSelectedYear(Number(e.target.value))}
              className="rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs font-medium text-slate-800 dark:text-slate-100"
            >
              {yearOptions.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>

            <select
              aria-label={t('ytd.calendarType')}
              value={calendarMode}
              onChange={(e) => setCalendarMode(e.target.value as CalendarMode)}
              className="rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs font-medium text-slate-800 dark:text-slate-100"
            >
              <option value="calendar">{t('ytd.calendarYear')}</option>
              <option value="fiscal">{t('ytd.fiscalYear')}</option>
            </select>

            <div className="inline-flex rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-0.5">
              {(['monthly', 'quarterly', 'yearly'] as PeriodGrouping[]).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => setGrouping(g)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                    grouping === g
                      ? 'bg-teal-600 text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {g === 'monthly'
                    ? t('ytd.viewMonthly')
                    : g === 'quarterly'
                      ? t('ytd.viewQuarterly')
                      : t('ytd.viewYearly')}
                </button>
              ))}
            </div>

            <select
              aria-label={t('ytd.filterByDomain')}
              value={domainFilter}
              onChange={(e) => setDomainFilter(e.target.value as DomainId | 'all')}
              className="rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs font-medium text-slate-800 dark:text-slate-100"
            >
              <option value="all">{t('ytd.allDomains')}</option>
              {(['personal-finance', 'product-business', 'service-business'] as DomainId[])
                .filter((d) => enabledDomains.has(d))
                .map((d) => (
                  <option key={d} value={d}>
                    {getLocalizedDomainTheme(d).label}
                  </option>
                ))}
            </select>

            <select
              aria-label={t('ytd.filterByType')}
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value as 'all' | 'income' | 'expense')}
              className="rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-2.5 py-1.5 text-xs font-medium text-slate-800 dark:text-slate-100"
            >
              <option value="all">{t('ytd.allTypes')}</option>
              <option value="income">{t('ytd.incomeOnly')}</option>
              <option value="expense">{t('ytd.expenseOnly')}</option>
            </select>

            <div className="relative flex-1 min-w-[160px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute start-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('ytd.searchPlaceholder')}
                className="w-full rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 ps-8 pe-3 py-1.5 text-xs text-slate-800 dark:text-slate-100 placeholder:text-slate-400"
              />
            </div>
          </div>

          {ytdLastUpdated && (
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {t('ytd.lastUpdated')}: {new Date(ytdLastUpdated).toLocaleTimeString()}
            </p>
          )}
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5">
          {ytdError && (
            <div className="flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-xs text-rose-700 dark:text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{ytdError}</span>
            </div>
          )}

          {/* KPI Summary Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 p-3.5">
              <p className="text-[11px] uppercase tracking-wide text-slate-500 dark:text-slate-400">
                {t('ytd.totalIncome')}
              </p>
              <p className="mt-1 text-base sm:text-lg font-mono-nums font-bold text-emerald-600 dark:text-emerald-400">
                {formatCurrency(summary.income, languagePrefs.displayCurrency)}
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 p-3.5">
              <p className="text-[11px] uppercase tracking-wide text-slate-500 dark:text-slate-400">
                {t('ytd.totalExpense')}
              </p>
              <p className="mt-1 text-base sm:text-lg font-mono-nums font-bold text-rose-600 dark:text-rose-400">
                {formatCurrency(summary.expense, languagePrefs.displayCurrency)}
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 p-3.5">
              <p className="text-[11px] uppercase tracking-wide text-slate-500 dark:text-slate-400">
                {t('ytd.netBalance')}
              </p>
              <p
                className={`mt-1 text-base sm:text-lg font-mono-nums font-bold ${
                  summary.net >= 0
                    ? 'text-teal-600 dark:text-teal-400'
                    : 'text-rose-600 dark:text-rose-400'
                }`}
              >
                {formatCurrency(summary.net, languagePrefs.displayCurrency)}
              </p>
            </div>
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-800/40 p-3.5">
              <p className="text-[11px] uppercase tracking-wide text-slate-500 dark:text-slate-400">
                {t('ytd.txCount')}
              </p>
              <p className="mt-1 text-base sm:text-lg font-mono-nums font-bold text-slate-900 dark:text-white">
                {summary.count}
              </p>
            </div>
          </div>

          {/* Period Breakdown */}
          {groupedBuckets.length > 0 && (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden">
              <div className="bg-slate-50 dark:bg-slate-800/60 px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700 dark:text-slate-200">
                  {t('ytd.periodBreakdown')}
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  {t('ytd.periodCount', { count: groupedBuckets.length })}
                </span>
              </div>
              <div className="divide-y divide-slate-200 dark:divide-slate-800">
                {groupedBuckets.map((bucket) => {
                  const net = bucket.income - bucket.expense;
                  return (
                    <div
                      key={bucket.label}
                      className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 text-xs bg-white dark:bg-slate-900/40"
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono-nums font-semibold text-slate-800 dark:text-slate-100">
                          {bucket.label}
                        </span>
                        <span className="text-slate-400">({bucket.count})</span>
                      </div>
                      <div className="flex items-center gap-4 font-mono-nums">
                        <span className="text-emerald-600 dark:text-emerald-400">
                          +{formatCurrency(bucket.income, languagePrefs.displayCurrency)}
                        </span>
                        <span className="text-rose-600 dark:text-rose-400">
                          -{formatCurrency(bucket.expense, languagePrefs.displayCurrency)}
                        </span>
                        <span
                          className={`font-semibold ${
                            net >= 0
                              ? 'text-slate-900 dark:text-white'
                              : 'text-rose-600 dark:text-rose-400'
                          }`}
                        >
                          {formatCurrency(net, languagePrefs.displayCurrency)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Unified Transaction Table */}
          {filtered.length === 0 ? (
            <div className="rounded-xl border border-dashed border-slate-300 dark:border-slate-700 p-10 text-center">
              <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">
                {t('ytd.noMatches')}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                {t('states.emptySubtitle')}
              </p>
            </div>
          ) : (
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 overflow-x-auto">
              <table className="w-full text-start text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-2.5 text-start">{t('ytd.tableDate')}</th>
                    <th className="px-4 py-2.5 text-start">{t('ytd.tableEntry')}</th>
                    <th className="px-4 py-2.5 text-start">{t('ytd.tableDomain')}</th>
                    <th className="px-4 py-2.5 text-start">{t('ytd.tableCategory')}</th>
                    <th className="px-4 py-2.5 text-end">{t('ytd.tableAmount')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {filtered.map((tx) => {
                    const domainTheme = getLocalizedDomainTheme(tx.domain);
                    return (
                      <tr
                        key={tx.id}
                        className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                      >
                        <td className="px-4 py-2.5 font-mono-nums text-slate-600 dark:text-slate-300 whitespace-nowrap">
                          {tx.date}
                        </td>
                        <td className="px-4 py-2.5">
                          <div className="flex items-center gap-2">
                            {tx.txType === 'income' ? (
                              <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                            ) : (
                              <ArrowUpRight className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                            )}
                            <div>
                              <p className="font-medium text-slate-900 dark:text-slate-100">
                                {tx.title}
                              </p>
                              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                                {tx.workspaceName}
                                {tx.counterparty ? ` · ${tx.counterparty}` : ''}
                              </p>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-2.5 whitespace-nowrap">
                          <span className={`inline-block rounded-md px-2 py-0.5 text-[11px] font-medium ${domainTheme.badgeClass}`}>
                            {domainTheme.shortLabel}
                          </span>
                        </td>
                        <td className="px-4 py-2.5 text-slate-600 dark:text-slate-300 whitespace-nowrap">
                          {tx.category}
                        </td>
                        <td
                          className={`px-4 py-2.5 text-end font-mono-nums font-semibold whitespace-nowrap ${
                            tx.txType === 'income'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-rose-600 dark:text-rose-400'
                          }`}
                        >
                          {tx.txType === 'income' ? '+' : '-'}
                          {formatCurrency(tx.amount, languagePrefs.displayCurrency)}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
