import React from 'react';

interface FinXLogoProps {
  showWordmark?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

export const FinXLogo: React.FC<FinXLogoProps> = ({
  showWordmark = true,
  size = 'md',
}) => {
  const iconDim = size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-10 h-10' : 'w-8 h-8';
  const textClass =
    size === 'sm' ? 'text-base' : size === 'lg' ? 'text-2xl' : 'text-lg';

  return (
    <span className="inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 select-none">
      <svg
        viewBox="0 0 36 36"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className={`${iconDim} shrink-0`}
        aria-hidden="true"
      >
        <rect
          width="36"
          height="36"
          rx="8"
          className="fill-teal-600 dark:fill-[#14B8A6]"
        />
        <path
          d="M10 11H24M10 11V25M10 18H19"
          stroke="white"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <path
          d="M19 15L26 25M26 15L19 25"
          stroke="#22D3EE"
          strokeWidth="2.5"
          strokeLinecap="round"
        />
      </svg>
      {showWordmark && (
        <span
          className={`font-display font-bold tracking-tight text-slate-900 dark:text-[#F8FAFC] ${textClass}`}
        >
          FinX
        </span>
      )}
    </span>
  );
};
