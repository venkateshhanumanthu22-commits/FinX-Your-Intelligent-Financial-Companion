import React from 'react';
import { getLocalizedDomainTheme } from '../config/domainThemes';
import { DomainId } from '../types/finx';

interface DomainBrand3DProps {
  domain: DomainId;
  workspaceName?: string;
  reducedMotion?: boolean;
  rightSlot?: React.ReactNode;
}

export const DomainLogoEmblem3D: React.FC<{ domain: DomainId; reducedMotion?: boolean; size?: 'sm' | 'md' | 'lg' }> = ({
  domain,
  reducedMotion = false,
  size = 'lg',
}) => {
  const theme = getLocalizedDomainTheme(domain);
  const dim = size === 'sm' ? 'w-11 h-11' : size === 'md' ? 'w-12 h-12' : 'w-16 h-16';

  return (
    <div
      className={`${dim} relative shrink-0 finx-3d-stage select-none`}
      aria-hidden="true"
    >
      <div
        className={`w-full h-full rounded-2xl flex items-center justify-center relative overflow-hidden shadow-lg ${
          reducedMotion ? '' : 'finx-3d-emblem-enter finx-3d-hover-tilt'
        }`}
        style={{
          background: `linear-gradient(135deg, ${theme.primaryHex}, ${theme.secondaryHex})`,
          boxShadow: `0 12px 26px -8px ${theme.primaryHex}66`,
        }}
      >
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background: 'linear-gradient(145deg, rgba(255,255,255,0.28) 0%, rgba(255,255,255,0) 55%)',
          }}
        />

        {domain === 'personal-finance' && (
          <svg viewBox="0 0 48 48" className="w-9 h-9 relative z-10">
            <rect x="7" y="13" width="34" height="24" rx="5" fill="#FFFFFF" fillOpacity="0.18" stroke="#FFFFFF" strokeWidth="2.2" />
            <path d="M12 13 L20 7 H36 L34 13" fill="none" stroke={theme.accentHex} strokeWidth="2.2" strokeLinejoin="round" />
            <circle cx="31" cy="25" r="4.5" fill="#FFFFFF" />
            <circle cx="31" cy="25" r="1.8" fill={theme.primaryHex} />
          </svg>
        )}

        {domain === 'product-business' && (
          <svg viewBox="0 0 48 48" className="w-9 h-9 relative z-10">
            <polygon points="24,6 40,14 24,22 8,14" fill="#FFFFFF" fillOpacity="0.92" />
            <polygon points="8,14 24,22 24,40 8,32" fill="#FFFFFF" fillOpacity="0.55" />
            <polygon points="40,14 24,22 24,40 40,32" fill={theme.accentHex} fillOpacity="0.9" />
          </svg>
        )}

        {domain === 'service-business' && (
          <svg viewBox="0 0 48 48" className="w-9 h-9 relative z-10">
            <ellipse cx="24" cy="24" rx="16" ry="7" transform="rotate(-24 24 24)" fill="none" stroke="#FFFFFF" strokeOpacity="0.75" strokeWidth="2" />
            <ellipse cx="24" cy="24" rx="16" ry="7" transform="rotate(24 24 24)" fill="none" stroke={theme.accentHex} strokeWidth="2" />
            <circle cx="24" cy="24" r="5" fill="#FFFFFF" />
          </svg>
        )}

        {domain === 'investment-knowledge' && (
          <svg viewBox="0 0 48 48" className="w-9 h-9 relative z-10">
            <polygon points="24,6 39,18 32,40 16,40 9,18" fill="#FFFFFF" fillOpacity="0.2" stroke="#FFFFFF" strokeWidth="2" />
            <polyline points="14,30 21,23 26,26 35,15" fill="none" stroke="#FBBF24" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" />
            <circle cx="35" cy="15" r="2.5" fill="#FBBF24" />
          </svg>
        )}

        {domain === 'financial-intelligence' && (
          <svg viewBox="0 0 48 48" className="w-9 h-9 relative z-10">
            <rect x="10" y="10" width="28" height="28" rx="6" fill="#FFFFFF" fillOpacity="0.14" stroke="#FFFFFF" strokeWidth="2" />
            <circle cx="18" cy="19" r="2.8" fill="#22D3EE" />
            <circle cx="30" cy="19" r="2.8" fill="#FFFFFF" />
            <circle cx="24" cy="30" r="3" fill="#22D3EE" />
            <line x1="18" y1="19" x2="30" y2="19" stroke="#FFFFFF" strokeOpacity="0.75" strokeWidth="1.6" />
            <line x1="18" y1="19" x2="24" y2="30" stroke="#22D3EE" strokeWidth="1.6" />
            <line x1="30" y1="19" x2="24" y2="30" stroke="#22D3EE" strokeWidth="1.6" />
          </svg>
        )}
      </div>
    </div>
  );
};

export const DomainBrand3D: React.FC<DomainBrand3DProps> = ({
  domain,
  workspaceName,
  reducedMotion = false,
  rightSlot,
}) => {
  const theme = getLocalizedDomainTheme(domain);

  return (
    <div
      key={domain}
      className={`rounded-2xl border ${theme.borderAccentClass} bg-gradient-to-r ${theme.bannerGradientLight} dark:${theme.bannerGradientDark} p-4 sm:p-6 transition-colors`}
    >
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
          <DomainLogoEmblem3D domain={domain} reducedMotion={reducedMotion} size="lg" />
          <div className="min-w-0">
            <div className={`text-xs font-semibold ${theme.accentTextClass} flex flex-wrap items-center gap-2`}>
              <span>{theme.shortLabel}</span>
              {workspaceName && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="truncate">{workspaceName}</span>
                </>
              )}
            </div>
            <h2 className="font-display font-bold text-lg sm:text-2xl text-slate-900 dark:text-[#F8FAFC] mt-0.5 truncate">
              {theme.name}
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-[#94A3B8] mt-1">
              {theme.tagline}
            </p>
          </div>
        </div>

        {rightSlot && (
          <div className="w-full sm:w-auto min-w-0 max-w-full flex flex-wrap items-center gap-2">
            {rightSlot}
          </div>
        )}
      </div>
    </div>
  );
};
