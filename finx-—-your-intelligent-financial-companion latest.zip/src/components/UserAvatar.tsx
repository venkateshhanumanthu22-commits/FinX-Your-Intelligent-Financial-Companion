import React from 'react';
import { getPresetById } from '../services/avatarCatalog';
import { AvatarCategory, UserProfile } from '../types/finx';

interface UserAvatarProps {
  user?: Partial<UserProfile> | null;
  name?: string;
  avatarCategory?: AvatarCategory;
  category?: AvatarCategory;
  avatarPresetId?: string;
  presetId?: string;
  customPhotoDataUrl?: string;
  fallbackUrl?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const SIZE_MAP = {
  sm: 'w-7 h-7 rounded-md',
  md: 'w-10 h-10 rounded-xl',
  lg: 'w-14 h-14 rounded-2xl',
  xl: 'w-20 h-20 rounded-2xl',
};

export const UserAvatar: React.FC<UserAvatarProps> = ({
  user,
  name,
  avatarCategory,
  category,
  avatarPresetId,
  presetId,
  customPhotoDataUrl,
  fallbackUrl,
  size = 'md',
  className = '',
}) => {
  const resolvedName = name || user?.name || 'FinX User';
  const resolvedCategory = category || avatarCategory || user?.avatarCategory || 'neutral';
  const resolvedPresetId = presetId || avatarPresetId || user?.avatarPresetId;
  const resolvedPhoto = customPhotoDataUrl ?? user?.customPhotoDataUrl;
  const sizeClass = SIZE_MAP[size];

  if (resolvedPhoto) {
    return (
      <img
        src={resolvedPhoto}
        alt={resolvedName}
        referrerPolicy="no-referrer"
        className={`${sizeClass} object-cover border border-slate-200 dark:border-slate-700 shrink-0 ${className}`}
      />
    );
  }

  const preset = getPresetById(resolvedPresetId, resolvedCategory);

  // If legacy fallbackUrl is explicitly provided with no custom preset change, keep clean SVG illustration so it never fails to load
  const gradientId = `finx-av-${preset.id}`;

  return (
    <div
      className={`${sizeClass} relative overflow-hidden border border-slate-200/80 dark:border-slate-700/80 shrink-0 flex items-center justify-center ${className}`}
      title={`${resolvedName} (${preset.label})`}
      aria-label={`${resolvedName} avatar`}
    >
      <svg
        viewBox="0 0 80 80"
        className="w-full h-full"
        role="img"
        aria-hidden="true"
      >
        <defs>
          <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={preset.bgFrom} />
            <stop offset="100%" stopColor={preset.bgTo} />
          </linearGradient>
        </defs>
        <rect width="80" height="80" fill={`url(#${gradientId})`} />
        <circle cx="64" cy="18" r="18" fill={preset.accent} fillOpacity="0.16" />

        {/* Shoulders & Collar */}
        <path
          d="M14 80 C16 60, 28 54, 40 54 C52 54, 64 60, 66 80 Z"
          fill={preset.outfit}
        />
        <path
          d="M32 54 L40 65 L48 54"
          fill="none"
          stroke="#FFFFFF"
          strokeOpacity="0.45"
          strokeWidth="2.2"
          strokeLinecap="round"
        />

        {/* Hair Back Layer for Female / Neutral Editorial */}
        {preset.category === 'female' && (
          <path
            d="M22 36 C21 20, 30 14, 40 14 C50 14, 59 20, 58 36 L60 53 C56 50, 54 46, 54 40 L26 40 C26 46, 24 50, 20 53 Z"
            fill={preset.hair}
          />
        )}

        {/* Neck & Face */}
        <rect x="35" y="45" width="10" height="11" rx="4" fill={preset.skin} />
        <circle cx="40" cy="34" r="14" fill={preset.skin} />

        {/* Hair Crown Layer */}
        {preset.category === 'male' && (
          <path
            d="M26 32 C26 21, 33 16, 41 16 C50 16, 55 22, 54 31 C51 26, 46 24, 39 24 C32 24, 28 27, 26 32 Z"
            fill={preset.hair}
          />
        )}
        {preset.category === 'female' && (
          <path
            d="M25 32 C26 20, 34 15, 42 16 C50 17, 54 23, 55 31 C49 25, 42 23, 35 25 C30 26, 27 29, 25 32 Z"
            fill={preset.hair}
          />
        )}
        {preset.category === 'neutral' && (
          <path
            d="M26 31 C27 20, 33 16, 40 16 C47 16, 53 20, 54 31 C49 26, 44 25, 40 25 C36 25, 31 26, 26 31 Z"
            fill={preset.hair}
          />
        )}

        {/* Facial Expression */}
        <circle cx="35" cy="34" r="1.7" fill="#0F172A" />
        <circle cx="45" cy="34" r="1.7" fill="#0F172A" />
        <path
          d="M35.5 40.5 Q40 44 44.5 40.5"
          fill="none"
          stroke="#7C2D12"
          strokeWidth="1.9"
          strokeLinecap="round"
        />

        {/* Subtle geometric glasses on editorial variant */}
        {preset.styleVariant === 'editorial' && (
          <g stroke={preset.accent} strokeWidth="1.5" fill="none">
            <rect x="30.5" y="30.5" width="8" height="6.5" rx="2" />
            <rect x="41.5" y="30.5" width="8" height="6.5" rx="2" />
            <line x1="38.5" y1="33.5" x2="41.5" y2="33.5" />
          </g>
        )}
      </svg>
      {fallbackUrl && !resolvedPresetId && <span className="sr-only">{resolvedName}</span>}
    </div>
  );
};
