import React from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface ErrorBoundaryState {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<
  { children: React.ReactNode },
  ErrorBoundaryState
> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    let readable = error?.message || 'An unexpected application error occurred.';
    try {
      const parsed = JSON.parse(readable) as { error?: string; operationType?: string; path?: string };
      if (parsed && parsed.error) {
        readable = `Database permission notice (${parsed.operationType || 'read'} on ${parsed.path || 'workspace'}): ${parsed.error}`;
      }
    } catch {
      // keep raw message
    }
    return { hasError: true, message: readable };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('[FinX ErrorBoundary]', error, info.componentStack);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] flex items-center justify-center p-6">
          <div className="max-w-lg w-full rounded-2xl border border-red-300 dark:border-red-800 bg-white dark:bg-[#1E293B] p-6 space-y-4">
            <div className="flex items-center gap-3 text-red-600 dark:text-[#F87171]">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h1 className="font-display font-bold text-lg">FinX Workspace Recovery</h1>
            </div>
            <p className="text-sm text-slate-600 dark:text-[#94A3B8] leading-relaxed">
              {this.state.message}
            </p>
            <button
              type="button"
              onClick={() => {
                this.setState({ hasError: false, message: '' });
                window.location.reload();
              }}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg bg-teal-600 dark:bg-[#14B8A6] text-white dark:text-slate-950"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reload FinX Workspace</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
