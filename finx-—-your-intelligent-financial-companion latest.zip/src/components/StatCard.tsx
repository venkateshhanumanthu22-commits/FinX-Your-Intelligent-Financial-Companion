import React from 'react';
import { ArrowUpRight } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: string;
  helperText?: string;
  tone?: 'neutral' | 'positive' | 'warning' | 'negative';
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  label,
  value,
  helperText,
  tone = 'neutral',
  onClick,
}) => {
  const toneClass =
    tone === 'positive'
      ? 'text-emerald-600 dark:text-[#34D399]'
      : tone === 'warning'
        ? 'text-amber-600 dark:text-[#FBBF24]'
        : tone === 'negative'
          ? 'text-red-600 dark:text-[#F87171]'
          : 'text-slate-900 dark:text-[#F8FAFC]';

  const Container = onClick ? 'button' : 'div';

  return (
    <Container
      {...(onClick ? { type: 'button', onClick } : {})}
      className={`w-full text-start rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1E293B] p-5 transition-colors ${
        onClick
          ? 'hover:border-teal-500/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-500 cursor-pointer group'
          : ''
      }`}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs font-medium text-slate-500 dark:text-[#94A3B8] truncate">
          {label}
        </span>
        {onClick && (
          <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-teal-500 dark:group-hover:text-[#14B8A6] shrink-0 transition-colors" />
        )}
      </div>
      <div className={`mt-2 text-2xl font-display font-bold font-mono-nums tracking-tight ${toneClass}`}>
        {value}
      </div>
      {helperText && (
        <p className="mt-1.5 text-xs text-slate-500 dark:text-[#94A3B8] truncate">
          {helperText}
        </p>
      )}
    </Container>
  );
};
