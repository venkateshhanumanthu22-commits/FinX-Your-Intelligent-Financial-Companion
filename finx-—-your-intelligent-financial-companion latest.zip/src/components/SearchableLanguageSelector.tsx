import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Check, ChevronDown, Globe, Search } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import { getLanguageDef, SUPPORTED_LANGUAGES } from '../i18n/languages';
import { LanguageCode } from '../types/finx';

interface SearchableLanguageSelectorProps {
  value: LanguageCode;
  onChange: (code: LanguageCode) => void;
  compact?: boolean;
  label?: string;
  align?: 'left' | 'right';
}

export const SearchableLanguageSelector: React.FC<SearchableLanguageSelectorProps> = ({
  value,
  onChange,
  compact = false,
  label,
  align = 'right',
}) => {
  const { t } = useTranslation('common');
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const containerRef = useRef<HTMLDivElement | null>(null);
  const searchInputRef = useRef<HTMLInputElement | null>(null);

  const selected = useMemo(() => getLanguageDef(value), [value]);

  const filteredLanguages = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return SUPPORTED_LANGUAGES;
    return SUPPORTED_LANGUAGES.filter(
      (lang) =>
        lang.englishName.toLowerCase().includes(q) ||
        lang.nativeName.toLowerCase().includes(q) ||
        lang.code.toLowerCase().includes(q) ||
        lang.regionLabel.toLowerCase().includes(q)
    );
  }, [query]);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  useEffect(() => {
    if (open) {
      setTimeout(() => searchInputRef.current?.focus(), 40);
    } else {
      setQuery('');
    }
  }, [open]);

  return (
    <div ref={containerRef} className="relative inline-block text-start">
      {label && (
        <label className="block text-xs font-medium text-slate-600 dark:text-[#94A3B8] mb-1.5">
          {label}
        </label>
      )}
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
        className={`inline-flex items-center justify-between gap-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#172235] text-slate-800 dark:text-[#F8FAFC] hover:border-teal-500/60 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-500 transition-colors whitespace-nowrap shrink-0 ${
          compact ? 'px-2.5 py-2 text-xs min-h-[38px]' : 'w-full px-3.5 py-2.5 text-sm min-h-[42px]'
        }`}
      >
        <span className="inline-flex items-center gap-2 min-w-0">
          <Globe className="w-4 h-4 text-teal-600 dark:text-[#14B8A6] shrink-0" />
          <span className="truncate font-medium">{selected.nativeName}</span>
          {!compact && (
            <span className="text-xs text-slate-500 dark:text-[#94A3B8] truncate">
              · {selected.englishName}
            </span>
          )}
        </span>
        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 shrink-0 transition-transform ${
            open ? 'rotate-180' : ''
          }`}
        />
      </button>

      {open && (
        <div
          className={`absolute z-[100] mt-2 w-[min(320px,calc(100vw-24px))] max-w-[calc(100vw-24px)] rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-[#1E293B] shadow-lg overflow-hidden ${
  align === 'left' ? 'end-0' : 'start-0'
}`}
        
          role="listbox"
          aria-label={t('language.selectorTitle')}
        >
          <div className="p-2.5 border-b border-slate-200 dark:border-slate-700">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute start-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                ref={searchInputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={t('language.searchPlaceholder')}
                className="w-full ps-8 pe-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-[#101827] text-slate-900 dark:text-[#F8FAFC] placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
          </div>

<div className="max-h-[min(55dvh,360px)] overflow-y-auto overscroll-contain divide-y divide-slate-100 dark:divide-slate-800/70">            {filteredLanguages.length === 0 ? (
              <div className="p-4 text-center text-xs text-slate-500 dark:text-[#94A3B8]">
                {t('language.noResults')}
              </div>
            ) : (
              filteredLanguages.map((lang) => {
                const isSelected = lang.code === value;
                return (
                  <button
                    key={lang.code}
                    type="button"
                    role="option"
                    aria-selected={isSelected}
                    onClick={() => {
                      onChange(lang.code);
                      setOpen(false);
                    }}
                    className={`w-full flex items-center justify-between gap-3 px-3.5 py-2.5 text-start text-xs transition-colors ${
                      isSelected
                        ? 'bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-200'
                        : 'hover:bg-slate-50 dark:hover:bg-[#172235] text-slate-800 dark:text-[#F8FAFC]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold truncate">{lang.nativeName}</span>
                        <span className="text-slate-500 dark:text-[#94A3B8] truncate">
                          {lang.englishName}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-[#94A3B8] mt-0.5">
                        {lang.code.toUpperCase()} · {lang.regionLabel}
                        {lang.dir === 'rtl' ? ' · RTL' : ''}
                      </div>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4 text-teal-600 dark:text-[#14B8A6] shrink-0" />
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
