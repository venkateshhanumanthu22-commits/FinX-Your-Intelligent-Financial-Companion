import i18n from '../i18n';

export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

export function validateEmail(email: string): string | null {
  const trimmed = email.trim();
  if (!trimmed) return i18n.t('common:validation.emailRequired');
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(trimmed)) return i18n.t('common:validation.emailInvalid');
  return null;
}

export function validatePassword(password: string, isRegistration = false): string | null {
  if (!password) return i18n.t('common:validation.passwordRequired');
  if (isRegistration && password.length < 8) {
    return i18n.t('common:validation.passwordMinReg');
  }
  if (!isRegistration && password.length < 4) {
    return i18n.t('common:validation.passwordMinLogin');
  }
  return null;
}

export function validatePositiveNumber(value: number | string, label: string): string | null {
  const num = typeof value === 'string' ? Number(value) : value;
  if (!Number.isFinite(num) || num <= 0) {
    return i18n.t('common:validation.positiveNumber', { label });
  }
  return null;
}

export function validateNonNegativeNumber(value: number | string, label: string): string | null {
  const num = typeof value === 'string' ? Number(value) : value;
  if (!Number.isFinite(num) || num < 0) {
    return i18n.t('common:validation.nonNegativeNumber', { label });
  }
  return null;
}

export function validateRequiredText(value: string, label: string): string | null {
  if (!value.trim()) {
    return i18n.t('common:validation.requiredField', { label });
  }
  return null;
}
