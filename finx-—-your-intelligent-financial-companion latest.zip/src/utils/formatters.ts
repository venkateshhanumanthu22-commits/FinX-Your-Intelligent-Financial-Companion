import { DisplayCurrency } from '../types/finx';

let activeLocaleTag = 'en-US';
let activeDisplayCurrency: DisplayCurrency = 'USD';

export function setFormattingLocale(localeTag: string, currency: DisplayCurrency): void {
  activeLocaleTag = localeTag || 'en-US';
  activeDisplayCurrency = currency || 'USD';
}

export function formatCurrency(
  amount: number,
  currency: DisplayCurrency | string = activeDisplayCurrency,
  locale: string = activeLocaleTag
): string {
  const safeAmount = Number.isFinite(amount) ? amount : 0;
  try {
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency,
      minimumFractionDigits: currency === 'JPY' ? 0 : 2,
      maximumFractionDigits: currency === 'JPY' ? 0 : 2,
    }).format(safeAmount);
  } catch {
    return `$${safeAmount.toFixed(2)}`;
  }
}

export function formatCompactCurrency(
  amount: number,
  currency: DisplayCurrency | string = activeDisplayCurrency,
  locale: string = activeLocaleTag
): string {
  const safeAmount = Number.isFinite(amount) ? amount : 0;
  try {
    return new Intl.NumberFormat(locale, {
      style: 'currency',
      currency,
      notation: Math.abs(safeAmount) >= 100000 ? 'compact' : 'standard',
      maximumFractionDigits: 0,
    }).format(safeAmount);
  } catch {
    return `$${Math.round(safeAmount)}`;
  }
}

export function formatNumber(value: number, locale: string = activeLocaleTag): string {
  const safe = Number.isFinite(value) ? value : 0;
  try {
    return new Intl.NumberFormat(locale).format(safe);
  } catch {
    return String(safe);
  }
}

export function formatDateShort(isoDate: string, locale: string = activeLocaleTag): string {
  const parsed = new Date(isoDate);
  if (Number.isNaN(parsed.getTime())) return isoDate;
  try {
    return new Intl.DateTimeFormat(locale, {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    }).format(parsed);
  } catch {
    return parsed.toLocaleDateString('en-US');
  }
}

export function formatDateTime(isoDate: string, locale: string = activeLocaleTag): string {
  const parsed = new Date(isoDate);
  if (Number.isNaN(parsed.getTime())) return isoDate;
  try {
    return new Intl.DateTimeFormat(locale, {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    }).format(parsed);
  } catch {
    return parsed.toLocaleString('en-US');
  }
}

export function generateId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

export function downloadTextFile(filename: string, content: string, mimeType: string): void {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
