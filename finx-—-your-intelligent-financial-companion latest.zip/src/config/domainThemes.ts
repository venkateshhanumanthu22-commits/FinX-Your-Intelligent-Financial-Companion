import i18n from '../i18n';
import { DomainId } from '../types/finx';

export interface DomainThemeConfig {
  id: DomainId;
  name: string;
  label: string;
  shortLabel: string;
  tagline: string;
  primaryHex: string;
  secondaryHex: string;
  accentHex: string;
  bannerGradientLight: string;
  bannerGradientDark: string;
  borderAccentClass: string;
  buttonBgClass: string;
  accentTextClass: string;
  surfaceTintClass: string;
  badgeClass: string;
  badgeText: string;
}

export const DOMAIN_THEMES: Record<DomainId, DomainThemeConfig> = {
  'personal-finance': {
    id: 'personal-finance',
    name: 'Individual & Personal Finance',
    label: 'Personal Finance',
    shortLabel: 'Individual Finance',
    tagline: 'Calm cash-flow clarity, personal budgets, savings goals & bill tracking',
    primaryHex: '#0284C7',
    secondaryHex: '#0D9488',
    accentHex: '#38BDF8',
    bannerGradientLight: 'from-sky-50 via-teal-50/80 to-slate-50',
    bannerGradientDark: 'from-[#0B1D2E] via-[#0D2631] to-[#111C2D]',
    borderAccentClass: 'border-sky-300/70 dark:border-sky-500/35',
    buttonBgClass: 'bg-sky-600 hover:bg-sky-700 dark:bg-sky-500 dark:hover:bg-sky-400 text-white dark:text-slate-950',
    accentTextClass: 'text-sky-700 dark:text-sky-400',
    surfaceTintClass: 'bg-sky-500/8',
    badgeClass: 'bg-sky-500/10 text-sky-700 dark:text-sky-300 border-sky-500/30',
    badgeText: 'Calm Blue · Teal',
  },
  'product-business': {
    id: 'product-business',
    name: 'Product Business Finance',
    label: 'Product Business',
    shortLabel: 'Product Business',
    tagline: 'Inventory SKUs, suppliers, customer orders, P&L & sales velocity forecasting',
    primaryHex: '#EA580C',
    secondaryHex: '#1E3A8A',
    accentHex: '#FB923C',
    bannerGradientLight: 'from-orange-50 via-amber-50/70 to-slate-50',
    bannerGradientDark: 'from-[#1F1510] via-[#131E3A] to-[#12192A]',
    borderAccentClass: 'border-orange-300/70 dark:border-orange-500/35',
    buttonBgClass: 'bg-orange-600 hover:bg-orange-700 dark:bg-orange-500 dark:hover:bg-orange-400 text-white dark:text-slate-950',
    accentTextClass: 'text-orange-700 dark:text-orange-400',
    surfaceTintClass: 'bg-orange-500/8',
    badgeClass: 'bg-orange-500/10 text-orange-700 dark:text-orange-300 border-orange-500/30',
    badgeText: 'Amber Orange · Navy',
  },
  'service-business': {
    id: 'service-business',
    name: 'Service & Consultancy Finance',
    label: 'Service Business',
    shortLabel: 'Service & Consultancy',
    tagline: 'Client retainers, milestone profitability, invoices & team payroll ledger',
    primaryHex: '#7C3AED',
    secondaryHex: '#6D28D9',
    accentHex: '#A78BFA',
    bannerGradientLight: 'from-violet-50 via-purple-50/70 to-white',
    bannerGradientDark: 'from-[#1E1433] via-[#1B1838] to-[#141729]',
    borderAccentClass: 'border-violet-300/70 dark:border-violet-500/35',
    buttonBgClass: 'bg-violet-600 hover:bg-violet-700 dark:bg-violet-500 dark:hover:bg-violet-400 text-white dark:text-slate-950',
    accentTextClass: 'text-violet-700 dark:text-violet-300',
    surfaceTintClass: 'bg-violet-500/8',
    badgeClass: 'bg-violet-500/10 text-violet-700 dark:text-violet-300 border-violet-500/30',
    badgeText: 'Purple · Violet',
  },
  'investment-knowledge': {
    id: 'investment-knowledge',
    name: 'Investment Intelligence',
    label: 'Investment Intelligence',
    shortLabel: 'Investment Intelligence',
    tagline: 'Portfolio allocation education, compounding models & risk-calibrated paper lab',
    primaryHex: '#059669',
    secondaryHex: '#D97706',
    accentHex: '#34D399',
    bannerGradientLight: 'from-emerald-50 via-amber-50/40 to-slate-50',
    bannerGradientDark: 'from-[#091F1A] via-[#0B1726] to-[#17181E]',
    borderAccentClass: 'border-emerald-300/70 dark:border-emerald-500/35',
    buttonBgClass: 'bg-emerald-600 hover:bg-emerald-700 dark:bg-emerald-500 dark:hover:bg-emerald-400 text-white dark:text-slate-950',
    accentTextClass: 'text-emerald-700 dark:text-emerald-400',
    surfaceTintClass: 'bg-emerald-500/8',
    badgeClass: 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 border-emerald-500/30',
    badgeText: 'Emerald · Navy · Gold',
  },
  'financial-intelligence': {
    id: 'financial-intelligence',
    name: 'Financial Intelligence & Strategy',
    label: 'Financial Intelligence',
    shortLabel: 'Financial Intelligence',
    tagline: 'Cross-business comparisons, scenario modeling, anomaly checks & AI briefs',
    primaryHex: '#0891B2',
    secondaryHex: '#2563EB',
    accentHex: '#22D3EE',
    bannerGradientLight: 'from-cyan-50 via-blue-50/70 to-slate-50',
    bannerGradientDark: 'from-[#081628] via-[#0A1F38] to-[#0E182B]',
    borderAccentClass: 'border-cyan-300/70 dark:border-cyan-500/35',
    buttonBgClass: 'bg-cyan-600 hover:bg-cyan-700 dark:bg-cyan-500 dark:hover:bg-cyan-400 text-white dark:text-slate-950',
    accentTextClass: 'text-cyan-700 dark:text-cyan-400',
    surfaceTintClass: 'bg-cyan-500/8',
    badgeClass: 'bg-cyan-500/10 text-cyan-700 dark:text-cyan-300 border-cyan-500/30',
    badgeText: 'Navy · Cyan · Blue',
  },
};

export function getLocalizedDomainTheme(id: DomainId): DomainThemeConfig {
  const base = DOMAIN_THEMES[id];
  return {
    ...base,
    name: i18n.t(`common:domains.${id}.name`, { defaultValue: base.name }),
    label: i18n.t(`common:domains.${id}.label`, { defaultValue: base.label }),
    shortLabel: i18n.t(`common:domains.${id}.shortLabel`, { defaultValue: base.shortLabel }),
    tagline: i18n.t(`common:domains.${id}.tagline`, { defaultValue: base.tagline }),
    badgeText: i18n.t(`common:domains.${id}.badgeText`, { defaultValue: base.badgeText }),
  };
}

