import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

import enCommon from './locales/en/common.json';
import enWelcome from './locales/en/welcome.json';
import enDashboard from './locales/en/dashboard.json';
import enFinance from './locales/en/finance.json';
import enBusiness from './locales/en/business.json';
import enAssistant from './locales/en/assistant.json';

import teCommon from './locales/te/common.json';
import teWelcome from './locales/te/welcome.json';
import teDashboard from './locales/te/dashboard.json';
import teFinance from './locales/te/finance.json';
import teBusiness from './locales/te/business.json';
import teAssistant from './locales/te/assistant.json';

import hiCommon from './locales/hi/common.json';
import hiWelcome from './locales/hi/welcome.json';
import hiDashboard from './locales/hi/dashboard.json';
import hiFinance from './locales/hi/finance.json';
import hiBusiness from './locales/hi/business.json';
import hiAssistant from './locales/hi/assistant.json';

import taCommon from './locales/ta/common.json';
import taWelcome from './locales/ta/welcome.json';
import taDashboard from './locales/ta/dashboard.json';
import taFinance from './locales/ta/finance.json';
import taBusiness from './locales/ta/business.json';
import taAssistant from './locales/ta/assistant.json';

import esCommon from './locales/es/common.json';
import esWelcome from './locales/es/welcome.json';
import esDashboard from './locales/es/dashboard.json';
import esFinance from './locales/es/finance.json';
import esBusiness from './locales/es/business.json';
import esAssistant from './locales/es/assistant.json';

import arCommon from './locales/ar/common.json';
import arWelcome from './locales/ar/welcome.json';
import arDashboard from './locales/ar/dashboard.json';
import arFinance from './locales/ar/finance.json';
import arBusiness from './locales/ar/business.json';
import arAssistant from './locales/ar/assistant.json';

import { REGIONAL_CORE_PACKS } from './locales/regionalCorePacks';

export const missingTranslationLog: string[] = [];

const resources: Record<string, Record<string, Record<string, unknown>>> = {
  en: {
    common: enCommon,
    welcome: enWelcome,
    dashboard: enDashboard,
    finance: enFinance,
    business: enBusiness,
    assistant: enAssistant,
  },
  te: {
    common: teCommon,
    welcome: teWelcome,
    dashboard: teDashboard,
    finance: teFinance,
    business: teBusiness,
    assistant: teAssistant,
  },
  hi: {
    common: hiCommon,
    welcome: hiWelcome,
    dashboard: hiDashboard,
    finance: hiFinance,
    business: hiBusiness,
    assistant: hiAssistant,
  },
  ta: {
    common: taCommon,
    welcome: taWelcome,
    dashboard: taDashboard,
    finance: taFinance,
    business: taBusiness,
    assistant: taAssistant,
  },
  es: {
    common: esCommon,
    welcome: esWelcome,
    dashboard: esDashboard,
    finance: esFinance,
    business: esBusiness,
    assistant: esAssistant,
  },
  ar: {
    common: arCommon,
    welcome: arWelcome,
    dashboard: arDashboard,
    finance: arFinance,
    business: arBusiness,
    assistant: arAssistant,
  },
};

Object.entries(REGIONAL_CORE_PACKS).forEach(([langCode, packs]) => {
  resources[langCode] = {
    ...packs,
  };
});

if (!i18n.isInitialized) {
  i18n.use(initReactI18next).init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    defaultNS: 'common',
    ns: ['common', 'welcome', 'dashboard', 'finance', 'business', 'assistant'],
    interpolation: {
      escapeValue: false,
    },
    saveMissing: true,
    missingKeyHandler: (lngs, ns, key) => {
      const entry = `${lngs.join(',')}:${ns}:${key}`;
      if (!missingTranslationLog.includes(entry)) {
        missingTranslationLog.push(entry);
      }
    },
  });
}

export default i18n;
