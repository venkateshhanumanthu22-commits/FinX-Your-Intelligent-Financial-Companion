import { LanguageCode } from '../types/finx';

export interface LanguageDefinition {
  code: LanguageCode;
  englishName: string;
  nativeName: string;
  regionLabel: string;
  dir: 'ltr' | 'rtl';
  defaultSpeechLocale: string;
  speechVariants: { locale: string; label: string }[];
  translationCoverage: 'complete' | 'core';
}

export const SUPPORTED_LANGUAGES: LanguageDefinition[] = [
  {
    code: 'en',
    englishName: 'English',
    nativeName: 'English',
    regionLabel: 'Global',
    dir: 'ltr',
    defaultSpeechLocale: 'en-US',
    speechVariants: [
      { locale: 'en-US', label: 'English (United States)' },
      { locale: 'en-IN', label: 'English (India)' },
      { locale: 'en-GB', label: 'English (United Kingdom)' },
      { locale: 'en-AU', label: 'English (Australia)' },
    ],
    translationCoverage: 'complete',
  },
  {
    code: 'te',
    englishName: 'Telugu',
    nativeName: 'తెలుగు',
    regionLabel: 'India',
    dir: 'ltr',
    defaultSpeechLocale: 'te-IN',
    speechVariants: [{ locale: 'te-IN', label: 'తెలుగు (భారతదేశం / India)' }],
    translationCoverage: 'complete',
  },
  {
    code: 'hi',
    englishName: 'Hindi',
    nativeName: 'हिन्दी',
    regionLabel: 'India',
    dir: 'ltr',
    defaultSpeechLocale: 'hi-IN',
    speechVariants: [{ locale: 'hi-IN', label: 'हिन्दी (भारत / India)' }],
    translationCoverage: 'complete',
  },
  {
    code: 'ta',
    englishName: 'Tamil',
    nativeName: 'தமிழ்',
    regionLabel: 'India / SG',
    dir: 'ltr',
    defaultSpeechLocale: 'ta-IN',
    speechVariants: [
      { locale: 'ta-IN', label: 'தமிழ் (இந்தியா / India)' },
      { locale: 'ta-SG', label: 'தமிழ் (Singapore)' },
    ],
    translationCoverage: 'complete',
  },
  {
    code: 'kn',
    englishName: 'Kannada',
    nativeName: 'ಕನ್ನಡ',
    regionLabel: 'India',
    dir: 'ltr',
    defaultSpeechLocale: 'kn-IN',
    speechVariants: [{ locale: 'kn-IN', label: 'ಕನ್ನಡ (ಭಾರತ / India)' }],
    translationCoverage: 'core',
  },
  {
    code: 'ml',
    englishName: 'Malayalam',
    nativeName: 'മലയാളം',
    regionLabel: 'India',
    dir: 'ltr',
    defaultSpeechLocale: 'ml-IN',
    speechVariants: [{ locale: 'ml-IN', label: 'മലയാളം (ഇന്ത്യ / India)' }],
    translationCoverage: 'core',
  },
  {
    code: 'bn',
    englishName: 'Bengali',
    nativeName: 'বাংলা',
    regionLabel: 'India / BD',
    dir: 'ltr',
    defaultSpeechLocale: 'bn-IN',
    speechVariants: [
      { locale: 'bn-IN', label: 'বাংলা (ভারত / India)' },
      { locale: 'bn-BD', label: 'বাংলা (বাংলাদেশ / Bangladesh)' },
    ],
    translationCoverage: 'core',
  },
  {
    code: 'mr',
    englishName: 'Marathi',
    nativeName: 'मराठी',
    regionLabel: 'India',
    dir: 'ltr',
    defaultSpeechLocale: 'mr-IN',
    speechVariants: [{ locale: 'mr-IN', label: 'मराठी (भारत / India)' }],
    translationCoverage: 'core',
  },
  {
    code: 'gu',
    englishName: 'Gujarati',
    nativeName: 'ગુજરાતી',
    regionLabel: 'India',
    dir: 'ltr',
    defaultSpeechLocale: 'gu-IN',
    speechVariants: [{ locale: 'gu-IN', label: 'ગુજરાતી (ભારત / India)' }],
    translationCoverage: 'core',
  },
  {
    code: 'pa',
    englishName: 'Punjabi',
    nativeName: 'ਪੰਜਾਬੀ',
    regionLabel: 'India',
    dir: 'ltr',
    defaultSpeechLocale: 'pa-IN',
    speechVariants: [{ locale: 'pa-IN', label: 'ਪੰਜਾਬੀ (ਭਾਰਤ / India)' }],
    translationCoverage: 'core',
  },
  {
    code: 'ur',
    englishName: 'Urdu',
    nativeName: 'اردو',
    regionLabel: 'South Asia',
    dir: 'rtl',
    defaultSpeechLocale: 'ur-IN',
    speechVariants: [
      { locale: 'ur-IN', label: 'اردو (India)' },
      { locale: 'ur-PK', label: 'اردو (Pakistan)' },
    ],
    translationCoverage: 'core',
  },
  {
    code: 'or',
    englishName: 'Odia',
    nativeName: 'ଓଡ଼ିଆ',
    regionLabel: 'India',
    dir: 'ltr',
    defaultSpeechLocale: 'or-IN',
    speechVariants: [{ locale: 'or-IN', label: 'ଓଡ଼ିଆ (India)' }],
    translationCoverage: 'core',
  },
  {
    code: 'as',
    englishName: 'Assamese',
    nativeName: 'অসমীয়া',
    regionLabel: 'India',
    dir: 'ltr',
    defaultSpeechLocale: 'as-IN',
    speechVariants: [{ locale: 'as-IN', label: 'অসমীয়া (India)' }],
    translationCoverage: 'core',
  },
  {
    code: 'es',
    englishName: 'Spanish',
    nativeName: 'Español',
    regionLabel: 'Global',
    dir: 'ltr',
    defaultSpeechLocale: 'es-ES',
    speechVariants: [
      { locale: 'es-ES', label: 'Español (España)' },
      { locale: 'es-MX', label: 'Español (México)' },
      { locale: 'es-US', label: 'Español (EE. UU.)' },
    ],
    translationCoverage: 'complete',
  },
  {
    code: 'fr',
    englishName: 'French',
    nativeName: 'Français',
    regionLabel: 'Global',
    dir: 'ltr',
    defaultSpeechLocale: 'fr-FR',
    speechVariants: [
      { locale: 'fr-FR', label: 'Français (France)' },
      { locale: 'fr-CA', label: 'Français (Canada)' },
    ],
    translationCoverage: 'core',
  },
  {
    code: 'de',
    englishName: 'German',
    nativeName: 'Deutsch',
    regionLabel: 'Europe',
    dir: 'ltr',
    defaultSpeechLocale: 'de-DE',
    speechVariants: [{ locale: 'de-DE', label: 'Deutsch (Deutschland)' }],
    translationCoverage: 'core',
  },
  {
    code: 'ar',
    englishName: 'Arabic',
    nativeName: 'العربية',
    regionLabel: 'MENA',
    dir: 'rtl',
    defaultSpeechLocale: 'ar-SA',
    speechVariants: [
      { locale: 'ar-SA', label: 'العربية (السعودية)' },
      { locale: 'ar-AE', label: 'العربية (الإمارات)' },
      { locale: 'ar-EG', label: 'العربية (مصر)' },
    ],
    translationCoverage: 'complete',
  },
  {
    code: 'zh',
    englishName: 'Chinese',
    nativeName: '中文',
    regionLabel: 'East Asia',
    dir: 'ltr',
    defaultSpeechLocale: 'zh-CN',
    speechVariants: [
      { locale: 'zh-CN', label: '中文 (简体 / Simplified)' },
      { locale: 'zh-TW', label: '中文 (繁體 / Traditional)' },
    ],
    translationCoverage: 'core',
  },
  {
    code: 'ja',
    englishName: 'Japanese',
    nativeName: '日本語',
    regionLabel: 'Japan',
    dir: 'ltr',
    defaultSpeechLocale: 'ja-JP',
    speechVariants: [{ locale: 'ja-JP', label: '日本語 (日本)' }],
    translationCoverage: 'core',
  },
  {
    code: 'ko',
    englishName: 'Korean',
    nativeName: '한국어',
    regionLabel: 'Korea',
    dir: 'ltr',
    defaultSpeechLocale: 'ko-KR',
    speechVariants: [{ locale: 'ko-KR', label: '한국어 (대한민국)' }],
    translationCoverage: 'core',
  },
  {
    code: 'pt',
    englishName: 'Portuguese',
    nativeName: 'Português',
    regionLabel: 'Global',
    dir: 'ltr',
    defaultSpeechLocale: 'pt-BR',
    speechVariants: [
      { locale: 'pt-BR', label: 'Português (Brasil)' },
      { locale: 'pt-PT', label: 'Português (Portugal)' },
    ],
    translationCoverage: 'core',
  },
];

export function getLanguageDef(code: string): LanguageDefinition {
  const base = code.split('-')[0].toLowerCase();
  return (
    SUPPORTED_LANGUAGES.find((l) => l.code === base) || SUPPORTED_LANGUAGES[0]
  );
}

export function getAllSpeechVariants(): {
  locale: string;
  label: string;
  englishName: string;
  nativeName: string;
  langCode: LanguageCode;
}[] {
  return SUPPORTED_LANGUAGES.flatMap((lang) =>
    lang.speechVariants.map((variant) => ({
      locale: variant.locale,
      label: variant.label,
      englishName: lang.englishName,
      nativeName: lang.nativeName,
      langCode: lang.code,
    }))
  );
}
