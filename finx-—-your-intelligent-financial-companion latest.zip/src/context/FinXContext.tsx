import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
} from 'firebase/auth';
import { useTranslation } from 'react-i18next';
import i18n from '../i18n';
import { getLanguageDef } from '../i18n/languages';
import { INITIAL_SETTINGS } from '../data/mockRepository';
import { auth, googleProvider, testFirestoreConnection } from '../firebase';
import { aiAssistantService } from '../services/aiAssistantService';
import { authService, LoginCredentials, RegisterPayload } from '../services/authService';
import { documentsService, workspaceRepository } from '../services/domainServices';
import {
  ALL_DOMAIN_IDS,
  FirestoreDomainEntity,
  FirestoreLedgerEntry,
  firestoreRepository,
  OnboardingOverrides,
} from '../services/firestoreRepository';
import { ActualMetricsSummary, intelligenceService } from '../services/intelligenceService';
import { getIntentConfirmationText, matchCentralizedVoiceCommand } from '../services/voiceService';
import {
  AppRoute,
  AppSettings,
  AssistantMessage,
  AuditLogEntry,
  AuthSession,
  AvatarCategory,
  BillItem,
  BudgetCategory,
  BusinessExpense,
  CustomerItem,
  DisplayCurrency,
  DomainId,
  ExtensionActivityLog,
  ExtensionDefinition,
  FinancialPlanItem,
  FinXMessage,
  GroundingSource,
  LanguageCode,
  LanguagePreferences,
  PaperTradePosition,
  PayrollRecord,
  PersonalTransaction,
  ProductItem,
  PurchaseRecord,
  SaleRecord,
  SavingsGoal,
  ServiceClient,
  ServiceInvoice,
  ServiceProject,
  SubscriptionItem,
  SupplierItem,
  ThemeMode,
  ToastNotice,
  UploadedDocument,
  UserProfile,
  WorkspaceProfile,
  YtdUnifiedTransaction,
} from '../types/finx';
import { formatCurrency, generateId, setFormattingLocale } from '../utils/formatters';

const VALID_WORKSPACE_ROUTES = new Set<AppRoute>([
  'dashboard',
  'personal-finance',
  'product-business',
  'service-business',
  'investment-knowledge',
  'financial-intelligence',
  'assistant',
  'messages',
  'documents',
  'planner',
  'extensions',
  'learning',
  'reports',
  'security',
  'settings',
]);

const GUEST_LANG_KEY = 'finx_lang_guest_v1';
const DEMO_LANG_KEY = 'finx_lang_demo_workspace_v1';
const DRAFTS_STORAGE_KEY = 'finx_unsaved_drafts_v1';
const PENDING_ONBOARDING_PREFIX = 'finx_pending_onboarding_v1_';

function savePendingOnboarding(email: string, overrides: OnboardingOverrides) {
  try {
    const key = `${PENDING_ONBOARDING_PREFIX}${email.trim().toLowerCase()}`;
    localStorage.setItem(key, JSON.stringify(overrides));
  } catch {
    // ignore storage quota errors
  }
}

function consumePendingOnboarding(email?: string | null): OnboardingOverrides | undefined {
  if (!email) return undefined;
  try {
    const key = `${PENDING_ONBOARDING_PREFIX}${email.trim().toLowerCase()}`;
    const raw = localStorage.getItem(key);
    if (!raw) return undefined;
    localStorage.removeItem(key);
    return JSON.parse(raw) as OnboardingOverrides;
  } catch {
    return undefined;
  }
}

function sanitizeCloudError(err: unknown, fallback: string): string {
  const raw = err instanceof Error ? err.message : String(err || '');
  const trimmed = raw.trim();
  if (
    !trimmed ||
    trimmed.startsWith('{') ||
    trimmed.includes('FirestoreErrorInfo') ||
    trimmed.includes('users/')
  ) {
    return fallback;
  }
  return trimmed.slice(0, 180);
}

const DEFAULT_LANGUAGE_PREFS: LanguagePreferences = {
  useSameLanguageEverywhere: true,
  displayLanguage: 'en',
  textAssistantLanguage: 'en',
  voiceInputLocale: 'en-US',
  voiceOutputLocale: 'en-US',
  voiceOutputVoiceURI: 'auto',
  autoSpeakResponses: true,
  displayCurrency: 'USD',
  neuralVoiceName: 'Kore',
  preferNeuralVoice: true,
  handsFreeLoop: true,
};

const INITIAL_DEMO_SUPPLIERS: SupplierItem[] = [
  {
    id: 'sup-1',
    name: 'NordicOptics Manufacturing',
    contact: 'orders@nordicoptics.example',
    category: 'Workspace Lighting',
    leadTimeDays: 7,
    notes: 'Primary desk lamp supplier',
  },
  {
    id: 'sup-2',
    name: 'Shenzhen Precision Electronics',
    contact: 'supply@spe-hardware.example',
    category: 'Hardware Accessories',
    leadTimeDays: 14,
    notes: 'Thunderbolt hub & aluminum enclosures',
  },
];

const INITIAL_DEMO_CUSTOMERS: CustomerItem[] = [
  {
    id: 'cust-1',
    name: 'Apex Studio Collective',
    contact: 'procurement@apexstudio.example',
    totalOrders: 4,
    totalSpent: 2840,
    lastOrderDate: '2026-11-12',
  },
  {
    id: 'cust-2',
    name: 'Northbridge Architecture',
    contact: 'ops@northbridge.example',
    totalOrders: 2,
    totalSpent: 1290,
    lastOrderDate: '2026-11-16',
  },
];

const INITIAL_DEMO_INVOICES: ServiceInvoice[] = [
  {
    id: 'inv-201',
    invoiceNumber: 'FX-INV-2026-101',
    clientId: 'cli-1',
    clientName: 'Meridian Logistics',
    projectTitle: 'Q4 Working Capital Audit',
    issueDate: '2026-11-01',
    dueDate: '2026-11-15',
    amount: 4800,
    paidAmount: 4800,
    status: 'Paid',
    lineItems: [
      { description: 'Working Capital Diagnostics & Cash Modeling', amount: 3400 },
      { description: 'Executive Advisory Review', amount: 1400 },
    ],
  },
  {
    id: 'inv-202',
    invoiceNumber: 'FX-INV-2026-102',
    clientId: 'cli-2',
    clientName: 'Solstice Health Group',
    projectTitle: 'Unit Economics Modernization',
    issueDate: '2026-11-05',
    dueDate: '2026-11-28',
    amount: 6200,
    paidAmount: 3100,
    status: 'Partial',
    lineItems: [
      { description: 'Service Line Margin Audit', amount: 4000 },
      { description: 'Department Budget Rollout', amount: 2200 },
    ],
  },
];

function loadSavedLanguagePrefs(storageKey: string): LanguagePreferences {
  try {
    const raw = localStorage.getItem(storageKey);
    if (!raw) return { ...DEFAULT_LANGUAGE_PREFS };
    const parsed = JSON.parse(raw) as Partial<LanguagePreferences>;
    return { ...DEFAULT_LANGUAGE_PREFS, ...parsed };
  } catch {
    return { ...DEFAULT_LANGUAGE_PREFS };
  }
}

function loadSavedDrafts(): Record<string, Record<string, unknown>> {
  try {
    const raw = sessionStorage.getItem(DRAFTS_STORAGE_KEY);
    return raw ? (JSON.parse(raw) as Record<string, Record<string, unknown>>) : {};
  } catch {
    return {};
  }
}

function mapFirebaseAuthError(err: unknown): string {
  const code = (err as { code?: string })?.code || '';
  const message = (err as { message?: string })?.message || 'Authentication failed.';
  if (code === 'auth/popup-closed-by-user') return 'Google sign-in popup was closed before completion.';
  if (code === 'auth/popup-blocked') return 'Sign-in popup was blocked by browser settings. Please allow popups for this preview.';
  if (code === 'auth/operation-not-allowed') {
    return 'Email/Password sign-in is not yet enabled in Firebase Console > Authentication > Sign-in method. Use Google Sign-In or enable Email/Password there.';
  }
  if (code === 'auth/invalid-credential' || code === 'auth/wrong-password' || code === 'auth/user-not-found') {
    return 'Invalid email or password. Please verify your credentials.';
  }
  if (code === 'auth/email-already-in-use') {
    return 'An account with this email already exists. Try signing in instead.';
  }
  if (code === 'auth/weak-password') {
    return 'Password should be at least 6 characters.';
  }
  return sanitizeCloudError(err, message);
}

interface FinXContextValue {
  theme: ThemeMode;
  setTheme: (theme: ThemeMode) => void;
  toggleTheme: () => void;

  route: AppRoute;
  navigate: (to: AppRoute) => void;
  goBack: () => void;
  canGoBack: boolean;

  session: AuthSession | null;
  isAuthenticated: boolean;
  authLoading: boolean;
  authError: string | null;
  postLoginGreeting: string | null;
  dismissPostLoginGreeting: () => void;

  signInWithGoogle: (onboarding?: OnboardingOverrides) => Promise<{ ok: boolean; error?: string }>;
  signInWithEmailFirebase: (email: string, password: string) => Promise<{ ok: boolean; error?: string }>;
  registerWithEmailFirebase: (
    payload: RegisterPayload & {
      avatarCategory?: AvatarCategory;
      avatarPresetId?: string;
      customPhotoDataUrl?: string;
      enabledDomains?: DomainId[];
      currency?: DisplayCurrency;
    }
  ) => Promise<{ ok: boolean; error?: string; verificationSent?: boolean }>;
  loginDemo: (creds: LoginCredentials) => { ok: boolean; error?: string };
  loginOneClickDemo: (onboarding?: OnboardingOverrides) => void;
  registerDemo: (payload: RegisterPayload & OnboardingOverrides) => { ok: boolean; error?: string };
  logout: () => Promise<void>;
  updateUserProfile: (
    patch: Partial<
      Pick<
        UserProfile,
        'name' | 'businessName' | 'role' | 'avatarCategory' | 'avatarPresetId' | 'customPhotoDataUrl' | 'enabledDomains' | 'currency'
      >
    >
  ) => Promise<void>;

  workspaces: WorkspaceProfile[];
  activeWorkspace: WorkspaceProfile | null;
  createWorkspace: (input: {
    name: string;
    domain: DomainId;
    description?: string;
    currency: DisplayCurrency;
  }) => Promise<WorkspaceProfile | null>;
  switchWorkspace: (workspaceId: string) => Promise<void>;
  toggleEnabledDomain: (domainId: DomainId) => Promise<void>;
  seedSampleWorkspaceData: () => Promise<void>;

  languagePrefs: LanguagePreferences;
  updateLanguagePrefs: (patch: Partial<LanguagePreferences>) => void;
  setUnifiedLanguage: (code: LanguageCode) => void;

  settings: AppSettings;
  updateSettings: (patch: Partial<AppSettings>) => void;

  // Draft persistence & Toasts
  drafts: Record<string, Record<string, unknown>>;
  setDraft: (formKey: string, values: Record<string, unknown>) => void;
  clearDraft: (formKey: string) => void;
  toasts: ToastNotice[];
  pushToast: (toast: Omit<ToastNotice, 'id'>) => void;
  dismissToast: (id: string) => void;

  // YTD Drawer
  ytdDrawerOpen: boolean;
  setYtdDrawerOpen: (open: boolean) => void;
  ytdTransactions: YtdUnifiedTransaction[];
  ytdLoading: boolean;
  ytdError: string | null;
  ytdLastUpdated: string | null;
  refreshYtdTransactions: () => Promise<void>;

  // Domain 1: Personal Finance
  transactions: PersonalTransaction[];
  addTransaction: (tx: Omit<PersonalTransaction, 'id'>) => void;
  updateTransaction: (tx: PersonalTransaction) => void;
  deleteTransaction: (id: string) => void;
  budgets: BudgetCategory[];
  updateBudgetLimit: (id: string, limit: number) => void;
  addBudgetCategory: (category: string, monthlyLimit: number) => void;
  savingsGoals: SavingsGoal[];
  addSavingsGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  contributeToGoal: (id: string, amount: number) => void;
  bills: BillItem[];
  toggleBillPaid: (id: string) => void;
  subscriptions: SubscriptionItem[];
  toggleSubscriptionActive: (id: string) => void;

  // Domain 2: Product Business
  products: ProductItem[];
  addProduct: (prod: Omit<ProductItem, 'id' | 'unitsSold'>) => void;
  updateProduct: (prod: ProductItem) => void;
  deleteProduct: (id: string) => void;
  suppliers: SupplierItem[];
  addSupplier: (sup: Omit<SupplierItem, 'id'>) => void;
  customers: CustomerItem[];
  addCustomer: (cust: Omit<CustomerItem, 'id'>) => void;
  sales: SaleRecord[];
  recordSale: (params: { productId: string; quantity: number; customerName: string }) => { ok: boolean; error?: string };
  purchases: PurchaseRecord[];
  restockProduct: (params: { productId: string; quantity: number; supplier: string }) => void;
  businessExpenses: BusinessExpense[];
  addBusinessExpense: (exp: Omit<BusinessExpense, 'id'>) => void;

  // Domain 3: Service & Consultancy
  clients: ServiceClient[];
  addClient: (client: Omit<ServiceClient, 'id' | 'lastUpdated'>) => void;
  updateClient: (client: ServiceClient) => void;
  recordClientPayment: (clientId: string, amount: number) => void;
  projects: ServiceProject[];
  addProject: (proj: Omit<ServiceProject, 'id'>) => void;
  invoices: ServiceInvoice[];
  createInvoice: (inv: Omit<ServiceInvoice, 'id'>) => void;
  markInvoicePaid: (invoiceId: string) => void;
  payroll: PayrollRecord[];
  addPayrollRecord: (rec: Omit<PayrollRecord, 'id'>) => void;
  togglePayrollStatus: (id: string) => void;

  // Domain 4: Investment Knowledge (Paper Trading)
  paperTrades: PaperTradePosition[];
  addPaperTrade: (trade: Omit<PaperTradePosition, 'id'>) => void;

  // Domain 5: Intelligence Metrics
  metrics: ActualMetricsSummary;

  // Security Audit Logs
  auditLogs: AuditLogEntry[];

  // Messages & Notifications
  messages: FinXMessage[];
  unreadCount: number;
  markMessageRead: (id: string, read?: boolean) => void;
  markAllMessagesRead: () => void;
  deleteMessage: (id: string) => void;

  // Documents
  documents: UploadedDocument[];
  uploadDocumentDemo: (file: File, category: UploadedDocument['documentCategory']) => Promise<UploadedDocument>;

  // Planner
  plans: FinancialPlanItem[];
  addPlan: (plan: Omit<FinancialPlanItem, 'id'>) => void;
  updatePlan: (plan: FinancialPlanItem) => void;
  deletePlan: (id: string) => void;

  // Extensions
  extensions: ExtensionDefinition[];
  extensionLogs: ExtensionActivityLog[];
  toggleExtensionStatus: (id: string) => void;
  installOptionalExtension: (id: string) => void;
  uninstallOptionalExtension: (id: string) => void;
  updateExtensionConfig: (id: string, config: Record<string, string | boolean>) => void;

  // Assistant Overlay & Conversation
  assistantOpen: boolean;
  assistantMinimized: boolean;
  assistantMode: 'finance-assistant' | 'finx-guide';
  setAssistantMode: (mode: 'finance-assistant' | 'finx-guide') => void;
  openAssistant: (mode?: 'finance-assistant' | 'finx-guide') => void;
  minimizeAssistant: () => void;
  closeAssistant: () => void;
  assistantMessages: AssistantMessage[];
  assistantBusy: boolean;
  assistantError: string | null;
  aiHealth: { aiConfigured: boolean; model: string; groundingEnabled?: boolean } | null;
  sendAssistantMessage: (
    text: string,
    overrideMode?: 'finance-assistant' | 'finx-guide'
  ) => Promise<{ replyText: string; executedActionText?: string } | null>;
  resetAssistantChat: () => void;
}

const FinXContext = createContext<FinXContextValue | null>(null);

export const FinXProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { t } = useTranslation(['assistant', 'common']);

  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem('finx_theme_v1');
      return saved === 'light' ? 'light' : 'dark';
    } catch {
      return 'dark';
    }
  });

  const [route, setRoute] = useState<AppRoute>('welcome');
  const [routeHistory, setRouteHistory] = useState<AppRoute[]>([]);
  const [session, setSession] = useState<AuthSession | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [authError, setAuthError] = useState<string | null>(null);
  const [postLoginGreeting, setPostLoginGreeting] = useState<string | null>(null);

  const [workspaces, setWorkspaces] = useState<WorkspaceProfile[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);

  const [languagePrefs, setLanguagePrefs] = useState<LanguagePreferences>(() =>
    loadSavedLanguagePrefs(GUEST_LANG_KEY)
  );
  const [settings, setSettings] = useState<AppSettings>(INITIAL_SETTINGS);

  const initialDemo = useMemo(() => workspaceRepository.loadInitialDemoWorkspace(), []);
  const [transactions, setTransactions] = useState<PersonalTransaction[]>(initialDemo.transactions);
  const [budgets, setBudgets] = useState<BudgetCategory[]>(initialDemo.budgets);
  const [savingsGoals, setSavingsGoals] = useState<SavingsGoal[]>(initialDemo.savingsGoals);
  const [bills, setBills] = useState<BillItem[]>(initialDemo.bills);
  const [subscriptions, setSubscriptions] = useState<SubscriptionItem[]>(initialDemo.subscriptions);
  const [products, setProducts] = useState<ProductItem[]>(initialDemo.products);
  const [suppliers, setSuppliers] = useState<SupplierItem[]>(INITIAL_DEMO_SUPPLIERS);
  const [customers, setCustomers] = useState<CustomerItem[]>(INITIAL_DEMO_CUSTOMERS);
  const [sales, setSales] = useState<SaleRecord[]>(initialDemo.sales);
  const [purchases, setPurchases] = useState<PurchaseRecord[]>(initialDemo.purchases);
  const [businessExpenses, setBusinessExpenses] = useState<BusinessExpense[]>(initialDemo.businessExpenses);
  const [clients, setClients] = useState<ServiceClient[]>(initialDemo.clients);
  const [projects, setProjects] = useState<ServiceProject[]>(initialDemo.projects);
  const [invoices, setInvoices] = useState<ServiceInvoice[]>(INITIAL_DEMO_INVOICES);
  const [payroll, setPayroll] = useState<PayrollRecord[]>(initialDemo.payroll);
  const [paperTrades, setPaperTrades] = useState<PaperTradePosition[]>(initialDemo.paperTrades);
  const [messages, setMessages] = useState<FinXMessage[]>(initialDemo.messages);
  const [documents, setDocuments] = useState<UploadedDocument[]>(initialDemo.documents);
  const [plans, setPlans] = useState<FinancialPlanItem[]>(initialDemo.plans);
  const [extensions, setExtensions] = useState<ExtensionDefinition[]>(initialDemo.extensions);
  const [extensionLogs, setExtensionLogs] = useState<ExtensionActivityLog[]>(initialDemo.extensionLogs);

  const [drafts, setDrafts] = useState<Record<string, Record<string, unknown>>>(loadSavedDrafts);
  const [toasts, setToasts] = useState<ToastNotice[]>([]);

  // YTD Drawer state
  const [ytdDrawerOpen, setYtdDrawerOpen] = useState(false);
  const [firebaseYtdEntries, setFirebaseYtdEntries] = useState<YtdUnifiedTransaction[]>([]);
  const [ytdLoading, setYtdLoading] = useState(false);
  const [ytdError, setYtdError] = useState<string | null>(null);
  const [ytdLastUpdated, setYtdLastUpdated] = useState<string | null>(null);

  // Assistant state
  const [assistantOpen, setAssistantOpen] = useState(false);
  const [assistantMinimized, setAssistantMinimized] = useState(false);
  const [assistantMode, setAssistantMode] = useState<'finance-assistant' | 'finx-guide'>('finance-assistant');
  const [assistantMessages, setAssistantMessages] = useState<AssistantMessage[]>([
    {
      id: 'init-greeting',
      role: 'assistant',
      content: "Hello! I'm FinX, your intelligent financial companion. How can I help you today?",
      timestamp: new Date().toISOString(),
      mode: 'finance-assistant',
      languageCode: 'en',
    },
  ]);
  const [assistantBusy, setAssistantBusy] = useState(false);
  const [assistantError, setAssistantError] = useState<string | null>(null);
  const [aiHealth, setAiHealth] = useState<{ aiConfigured: boolean; model: string; groundingEnabled?: boolean } | null>(null);

  const inFlightLockRef = useRef(false);
  const abortRef = useRef<AbortController | null>(null);
  const pendingOnboardingRef = useRef<OnboardingOverrides | undefined>(undefined);
  const fsUnsubscribeRef = useRef<(() => void) | null>(null);

  const pushToast = useCallback((toast: Omit<ToastNotice, 'id'>) => {
    const id = generateId('toast');
    setToasts((prev) => [...prev.slice(-3), { ...toast, id }]);
    window.setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 4500);
  }, []);

  const notifyCloudSyncError = useCallback(
    (err?: unknown) => {
      console.warn('[FinX Cloud Sync Notice]', err);
      pushToast({
        kind: 'warning',
        title: t('common:toast.error'),
        description: t('common:toast.syncError'),
      });
    },
    [pushToast, t]
  );

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((item) => item.id !== id));
  }, []);

  const dismissPostLoginGreeting = useCallback(() => {
    setPostLoginGreeting(null);
  }, []);

  const loadDemoDataIntoState = useCallback(() => {
    const snap = workspaceRepository.loadInitialDemoWorkspace();
    setTransactions(snap.transactions);
    setBudgets(snap.budgets);
    setSavingsGoals(snap.savingsGoals);
    setBills(snap.bills);
    setSubscriptions(snap.subscriptions);
    setProducts(snap.products);
    setSuppliers(INITIAL_DEMO_SUPPLIERS);
    setCustomers(INITIAL_DEMO_CUSTOMERS);
    setSales(snap.sales);
    setPurchases(snap.purchases);
    setBusinessExpenses(snap.businessExpenses);
    setClients(snap.clients);
    setProjects(snap.projects);
    setInvoices(INITIAL_DEMO_INVOICES);
    setPayroll(snap.payroll);
    setPaperTrades(snap.paperTrades);
    setMessages(snap.messages);
    setDocuments(snap.documents);
    setPlans(snap.plans);
    setExtensions(snap.extensions);
    setExtensionLogs(snap.extensionLogs);
  }, []);

  const clearDomainStateForFirebaseWorkspace = useCallback(() => {
    setTransactions([]);
    setBudgets([]);
    setSavingsGoals([]);
    setBills([]);
    setSubscriptions([]);
    setProducts([]);
    setSuppliers([]);
    setCustomers([]);
    setSales([]);
    setPurchases([]);
    setBusinessExpenses([]);
    setClients([]);
    setProjects([]);
    setInvoices([]);
    setPayroll([]);
    setPaperTrades([]);
    setPlans([]);
    setMessages([]);
    setDocuments([]);
    setExtensionLogs([]);
  }, []);

  const applyFirestoreSnapshot = useCallback(
    (ledgerEntries: FirestoreLedgerEntry[], domainEntities: FirestoreDomainEntity[]) => {
      const txList: PersonalTransaction[] = [];
      const saleList: SaleRecord[] = [];
      const purchaseList: PurchaseRecord[] = [];
      const expList: BusinessExpense[] = [];
      const payList: PayrollRecord[] = [];

      ledgerEntries.forEach((entry) => {
        if (entry.recordKind === 'personal_tx') {
          txList.push({
            id: entry.id,
            amount: entry.amount,
            description: entry.title,
            category: entry.category,
            date: entry.date,
            paymentMethod: (entry.paymentMethod as PersonalTransaction['paymentMethod']) || 'Bank Transfer',
            type: entry.txType,
            notes: entry.notes,
          });
        } else if (entry.recordKind === 'product_sale') {
          saleList.push({
            id: entry.id,
            productId: entry.referenceCode || '',
            productName: entry.title,
            quantity: entry.quantity || 1,
            unitPrice: entry.unitPrice || entry.amount,
            totalAmount: entry.amount,
            date: entry.date,
            customerName: entry.counterparty || 'Customer',
          });
        } else if (entry.recordKind === 'product_purchase') {
          purchaseList.push({
            id: entry.id,
            productId: entry.referenceCode || '',
            productName: entry.title,
            quantity: entry.quantity || 1,
            unitCost: entry.unitPrice || entry.amount,
            totalCost: entry.amount,
            supplier: entry.counterparty || 'Supplier',
            date: entry.date,
          });
        } else if (entry.recordKind === 'business_expense') {
          expList.push({
            id: entry.id,
            domain: entry.domain === 'service-business' ? 'service' : 'product',
            category: entry.category,
            description: entry.title,
            amount: entry.amount,
            date: entry.date,
          });
        } else if (entry.recordKind === 'payroll') {
          payList.push({
            id: entry.id,
            memberName: entry.title,
            role: entry.category,
            amount: entry.amount,
            period: entry.date.slice(0, 7),
            status: entry.notes === 'Scheduled' ? 'Scheduled' : 'Paid',
          });
        }
      });

      const budgetList: BudgetCategory[] = [];
      const goalList: SavingsGoal[] = [];
      const billList: BillItem[] = [];
      const subList: SubscriptionItem[] = [];
      const prodList: ProductItem[] = [];
      const supList: SupplierItem[] = [];
      const custList: CustomerItem[] = [];
      const clientList: ServiceClient[] = [];
      const projList: ServiceProject[] = [];
      const invList: ServiceInvoice[] = [];
      const tradeList: PaperTradePosition[] = [];
      const planList: FinancialPlanItem[] = [];
      const msgList: FinXMessage[] = [];
      const docList: UploadedDocument[] = [];
      const fallbackGoalDate = new Date(Date.now() + 365 * 86400000).toISOString().slice(0, 10);

      domainEntities.forEach((ent) => {
        const p = ent.payload || {};
        switch (ent.entityType) {
          case 'budget':
            budgetList.push({
              id: ent.id,
              category: ent.title,
              monthlyLimit: Number(p.monthlyLimit || 500),
              alertThresholdPercent: Number(p.alertThresholdPercent || 85),
            });
            break;
          case 'goal':
            goalList.push({
              id: ent.id,
              title: ent.title,
              targetAmount: Number(p.targetAmount || 1000),
              currentAmount: Number(p.currentAmount || 0),
              targetDate: String(p.targetDate || fallbackGoalDate),
              priority: (p.priority as SavingsGoal['priority']) || 'Medium',
            });
            break;
          case 'bill':
            billList.push({
              id: ent.id,
              title: ent.title,
              amount: Number(p.amount || 0),
              dueDate: String(p.dueDate || ''),
              category: String(p.category || 'Utilities'),
              status: (ent.status as BillItem['status']) || 'Upcoming',
              autopay: Boolean(p.autopay),
            });
            break;
          case 'subscription':
            subList.push({
              id: ent.id,
              name: ent.title,
              amount: Number(p.amount || 0),
              billingCycle: (p.billingCycle as SubscriptionItem['billingCycle']) || 'Monthly',
              nextBillingDate: String(p.nextBillingDate || ''),
              category: String(p.category || 'Software & Tools'),
              active: ent.status === 'Active',
            });
            break;
          case 'product':
            prodList.push({
              id: ent.id,
              productCode: String(p.productCode || 'SKU'),
              name: ent.title,
              category: String(p.category || 'General'),
              purchaseCost: Number(p.purchaseCost || 0),
              sellingPrice: Number(p.sellingPrice || 0),
              availableQuantity: Number(p.availableQuantity || 0),
              reorderLevel: Number(p.reorderLevel || 5),
              unitsSold: Number(p.unitsSold || 0),
            });
            break;
          case 'supplier':
            supList.push({
              id: ent.id,
              name: ent.title,
              contact: String(p.contact || ''),
              category: String(p.category || 'General'),
              leadTimeDays: Number(p.leadTimeDays || 7),
              notes: String(p.notes || ''),
            });
            break;
          case 'customer':
            custList.push({
              id: ent.id,
              name: ent.title,
              contact: String(p.contact || ''),
              totalOrders: Number(p.totalOrders || 0),
              totalSpent: Number(p.totalSpent || 0),
              lastOrderDate: String(p.lastOrderDate || ''),
            });
            break;
          case 'client':
            clientList.push({
              id: ent.id,
              name: ent.title,
              contact: String(p.contact || ''),
              serviceProvided: String(p.serviceProvided || 'Consulting'),
              agreedAmount: Number(p.agreedAmount || 0),
              paidAmount: Number(p.paidAmount || 0),
              paymentStatus: (ent.status as ServiceClient['paymentStatus']) || 'Pending',
              dueDate: String(p.dueDate || ''),
              projectTitle: String(p.projectTitle || ''),
              lastUpdated: String(p.lastUpdated || ''),
            });
            break;
          case 'project':
            projList.push({
              id: ent.id,
              clientId: String(p.clientId || ''),
              clientName: String(p.clientName || ''),
              title: ent.title,
              status: (ent.status as ServiceProject['status']) || 'Active',
              startDate: String(p.startDate || ''),
              milestoneValue: Number(p.milestoneValue || 0),
              directCost: Number(p.directCost || 0),
            });
            break;
          case 'invoice': {
            const lineCount = Math.min(6, Math.max(0, Number(p.lineCount || 0)));
            const decodedItems: Array<{ description: string; amount: number }> = [];
            for (let i = 0; i < lineCount; i++) {
              const desc = String(p[`item${i}Desc`] || '');
              const amt = Number(p[`item${i}Amt`] || 0);
              if (desc) decodedItems.push({ description: desc, amount: amt });
            }
            if (decodedItems.length === 0) {
              decodedItems.push({
                description: String(p.lineSummary || ent.title),
                amount: Number(p.amount || 0),
              });
            }
            invList.push({
              id: ent.id,
              invoiceNumber: String(p.invoiceNumber || ent.id),
              clientId: String(p.clientId || ''),
              clientName: String(p.clientName || ''),
              projectTitle: ent.title,
              issueDate: String(p.issueDate || ''),
              dueDate: String(p.dueDate || ''),
              amount: Number(p.amount || 0),
              paidAmount: Number(p.paidAmount || 0),
              status: (ent.status as ServiceInvoice['status']) || 'Pending',
              lineItems: decodedItems,
            });
            break;
          }
          case 'paper_trade':
            tradeList.push({
              id: ent.id,
              symbol: String(p.symbol || 'INDEX'),
              name: ent.title,
              assetClass: (p.assetClass as PaperTradePosition['assetClass']) || 'Equity',
              shares: Number(p.shares || 0),
              simulatedEntryPrice: Number(p.simulatedEntryPrice || 0),
              historicalReferencePrice: Number(p.historicalReferencePrice || 0),
              purchaseDate: String(p.purchaseDate || ''),
            });
            break;
          case 'plan':
            planList.push({
              id: ent.id,
              title: ent.title,
              planType: (p.planType as FinancialPlanItem['planType']) || 'Savings Goal',
              targetAmount: Number(p.targetAmount || 0),
              allocatedAmount: Number(p.allocatedAmount || 0),
              dueDate: String(p.dueDate || ''),
              status: (ent.status as FinancialPlanItem['status']) || 'On Track',
              notes: String(p.notes || ''),
            });
            break;
          case 'finx_message':
            msgList.push({
              id: ent.id,
              type: (p.msgType as FinXMessage['type']) || 'financial_reminder',
              sender: String(p.sender || 'FinX System'),
              title: ent.title,
              content: String(p.content || ''),
              amount: p.hasAmount ? Number(p.amount || 0) : undefined,
              referenceId: String(p.referenceId || '') || undefined,
              timestamp: String(p.timestamp || new Date().toISOString()),
              read: ent.status === 'Read',
              sourceDomain: (p.sourceDomain as FinXMessage['sourceDomain']) || 'FinX System',
              isSimulatedInternal: p.isSimulatedInternal !== undefined ? Boolean(p.isSimulatedInternal) : true,
            });
            break;
          case 'uploaded_document':
            docList.push({
              id: ent.id,
              fileName: ent.title,
              fileType: String(p.fileType || 'text/plain'),
              fileSizeKb: Number(p.fileSizeKb || 0),
              uploadedAt: String(p.uploadedAt || new Date().toISOString()),
              documentCategory: (p.documentCategory as UploadedDocument['documentCategory']) || 'Invoice',
              status: (ent.status as UploadedDocument['status']) || 'Processed (Demo)',
              extractedSummary: String(p.extractedSummary || ''),
              extractedFields: {
                vendorOrEntity: p.vendorOrEntity ? String(p.vendorOrEntity) : undefined,
                documentDate: p.documentDate ? String(p.documentDate) : undefined,
                detectedAmount: p.hasDetectedAmount ? Number(p.detectedAmount || 0) : undefined,
                suggestedCategory: p.suggestedCategory ? String(p.suggestedCategory) : undefined,
                referenceNumber: p.referenceNumber ? String(p.referenceNumber) : undefined,
              },
            });
            break;
        }
      });

      setTransactions(txList.sort((a, b) => b.date.localeCompare(a.date)));
      setSales(saleList.sort((a, b) => b.date.localeCompare(a.date)));
      setPurchases(purchaseList.sort((a, b) => b.date.localeCompare(a.date)));
      setBusinessExpenses(expList.sort((a, b) => b.date.localeCompare(a.date)));
      setPayroll(payList);
      setBudgets(budgetList);
      setSavingsGoals(goalList);
      setBills(billList);
      setSubscriptions(subList);
      setProducts(prodList);
      setSuppliers(supList);
      setCustomers(custList);
      setClients(clientList);
      setProjects(projList);
      setInvoices(invList);
      setPaperTrades(tradeList);
      setPlans(planList);
      setMessages(msgList.sort((a, b) => b.timestamp.localeCompare(a.timestamp)));
      setDocuments(docList.sort((a, b) => b.uploadedAt.localeCompare(a.uploadedAt)));
    },
    []
  );

  const attachWorkspaceSubscription = useCallback(
    (uid: string, workspaceId: string) => {
      if (fsUnsubscribeRef.current) {
        fsUnsubscribeRef.current();
        fsUnsubscribeRef.current = null;
      }

      let latestLedger: FirestoreLedgerEntry[] = [];
      let latestEntities: FirestoreDomainEntity[] = [];

      const unsub = firestoreRepository.subscribeWorkspaceCollections(
        uid,
        workspaceId,
        (entries) => {
          latestLedger = entries;
          applyFirestoreSnapshot(latestLedger, latestEntities);
        },
        (entities) => {
          latestEntities = entities;
          applyFirestoreSnapshot(latestLedger, latestEntities);
        },
        (logs) => {
          setAuditLogs(logs);
        }
      );

      fsUnsubscribeRef.current = unsub;
    },
    [applyFirestoreSnapshot]
  );

  // Check Firestore connectivity + monitor Firebase Auth session
  useEffect(() => {
    testFirestoreConnection();

    const unsubAuth = onAuthStateChanged(auth, async (fbUser) => {
      if (!fbUser) {
        if (fsUnsubscribeRef.current) {
          fsUnsubscribeRef.current();
          fsUnsubscribeRef.current = null;
        }
        setSession((prev) => (prev?.authMode === 'demo-local' ? prev : null));
        setAuthLoading(false);
        return;
      }

      // Enforce verified email requirement matching firestore.rules
      if (!fbUser.emailVerified) {
        setAuthLoading(false);
        return;
      }

      try {
        const storedOnboarding = !pendingOnboardingRef.current
          ? consumePendingOnboarding(fbUser.email)
          : undefined;
        const resolvedOverrides = pendingOnboardingRef.current || storedOnboarding;
        pendingOnboardingRef.current = undefined;

        const result = await firestoreRepository.ensureUserAndDefaultWorkspace(
          fbUser,
          resolvedOverrides
        );

        const authMode: AuthSession['authMode'] =
          fbUser.providerData.some((p) => p.providerId === 'google.com')
            ? 'firebase-google'
            : 'firebase-email';

        const welcomeMessage = result.isNewUser
          ? `Welcome to FinX, ${result.user.name}! Your personal & business workspace "${result.user.businessName}" is ready.`
          : `Welcome back, ${result.user.name}! Your FinX workspace "${result.user.businessName}" is synced.`;

        setSession({
          user: result.user,
          sessionStartedAt: new Date().toISOString(),
          authMode,
          tokenNotice: 'Secured by Firebase Authentication & Cloud Firestore.',
          welcomeMessage,
        });
        setPostLoginGreeting(welcomeMessage);
        setWorkspaces(result.workspaces);
        setThemeState(result.theme);
        setSettings((prev) => ({ ...prev, reducedMotion: result.reducedMotion }));
        if (result.languagePrefs.displayLanguage) {
          setLanguagePrefs((prev) => ({ ...prev, ...result.languagePrefs }));
        }

        clearDomainStateForFirebaseWorkspace();
        attachWorkspaceSubscription(fbUser.uid, result.user.activeWorkspaceId);

        setRoute((curr) =>
          curr === 'welcome' || curr === 'login' || curr === 'register' ? 'dashboard' : curr
        );
        setAuthError(null);
      } catch (err) {
        setAuthError(sanitizeCloudError(err, 'Failed to load cloud workspace. Please retry.'));
      } finally {
        setAuthLoading(false);
      }
    });

    return () => {
      unsubAuth();
      if (fsUnsubscribeRef.current) {
        fsUnsubscribeRef.current();
      }
    };
  }, [attachWorkspaceSubscription, clearDomainStateForFirebaseWorkspace]);

  // Sync theme & reducedMotion to <html>
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');

    if (settings.reducedMotion) root.classList.add('reduced-motion');
    else root.classList.remove('reduced-motion');

    try {
      localStorage.setItem('finx_theme_v1', theme);
    } catch {
      // ignore storage errors
    }
  }, [settings.reducedMotion, theme]);

  // Sync language, RTL direction, and formatter locale
  useEffect(() => {
    const langDef = getLanguageDef(languagePrefs.displayLanguage);
    i18n.changeLanguage(langDef.code);
    document.documentElement.lang = langDef.code;
    document.documentElement.dir = langDef.dir;
    setFormattingLocale(langDef.defaultSpeechLocale, languagePrefs.displayCurrency);

    const storageKey = session ? DEMO_LANG_KEY : GUEST_LANG_KEY;
    try {
      const serialized = JSON.stringify(languagePrefs);
      localStorage.setItem(storageKey, serialized);
      if (session?.authMode === 'demo-local') {
        localStorage.setItem(GUEST_LANG_KEY, serialized);
      }
    } catch {
      // ignore storage errors
    }
  }, [languagePrefs, session]);

  // Update initial greeting when user has not started chatting yet
  useEffect(() => {
    setAssistantMessages((prev) => {
      if (prev.length === 1 && prev[0].id === 'init-greeting') {
        const localizedGreeting = i18n.t('assistant:greeting', {
          lng: languagePrefs.textAssistantLanguage,
        });
        return [
          {
            ...prev[0],
            content: localizedGreeting,
            languageCode: languagePrefs.textAssistantLanguage,
          },
        ];
      }
      return prev;
    });
  }, [languagePrefs.textAssistantLanguage]);

  // Check AI health on mount
  useEffect(() => {
    aiAssistantService.checkHealth().then(setAiHealth);
  }, []);

  const isFirebaseActive = Boolean(session && session.authMode !== 'demo-local' && auth.currentUser?.uid);

  const setTheme = useCallback(
    (next: ThemeMode) => {
      setThemeState(next);
      if (session && session.authMode !== 'demo-local') {
        firestoreRepository.updateUserProfileDoc(session.user.id, { theme: next }).catch(() => {});
      }
    },
    [session]
  );

  const toggleTheme = useCallback(() => {
    setThemeState((prev) => {
      const next = prev === 'dark' ? 'light' : 'dark';
      if (session && session.authMode !== 'demo-local') {
        firestoreRepository.updateUserProfileDoc(session.user.id, { theme: next }).catch(() => {});
      }
      return next;
    });
  }, [session]);

  const navigate = useCallback((to: AppRoute) => {
    setRoute((current) => {
      if (current === to) return current;
      setRouteHistory((hist) => [...hist.slice(-15), current]);
      return to;
    });
  }, []);

  const goBack = useCallback(() => {
    setRouteHistory((hist) => {
      if (hist.length === 0) return hist;
      const previous = hist[hist.length - 1];
      setRoute(previous);
      return hist.slice(0, -1);
    });
  }, []);

  const updateLanguagePrefs = useCallback(
    (patch: Partial<LanguagePreferences>) => {
      setLanguagePrefs((prev) => {
        const next = { ...prev, ...patch };
        if (next.useSameLanguageEverywhere && (patch.useSameLanguageEverywhere || patch.displayLanguage)) {
          const def = getLanguageDef(next.displayLanguage);
          next.textAssistantLanguage = def.code;
          next.voiceInputLocale = def.defaultSpeechLocale;
          next.voiceOutputLocale = def.defaultSpeechLocale;
          next.voiceOutputVoiceURI = 'auto';
        }
        const touchesCloudFields =
          patch.useSameLanguageEverywhere !== undefined ||
          patch.displayLanguage !== undefined ||
          patch.textAssistantLanguage !== undefined ||
          patch.voiceInputLocale !== undefined ||
          patch.voiceOutputLocale !== undefined ||
          patch.voiceOutputVoiceURI !== undefined ||
          patch.autoSpeakResponses !== undefined ||
          patch.neuralVoiceName !== undefined ||
          patch.preferNeuralVoice !== undefined ||
          patch.handsFreeLoop !== undefined ||
          patch.displayCurrency !== undefined;

        if (touchesCloudFields && session && session.authMode !== 'demo-local') {
          firestoreRepository
            .updateUserProfileDoc(session.user.id, {
              useSameLanguageEverywhere: next.useSameLanguageEverywhere,
              displayLanguage: next.displayLanguage,
              textAssistantLanguage: next.textAssistantLanguage,
              voiceInputLocale: next.voiceInputLocale,
              voiceOutputLocale: next.voiceOutputLocale,
              voiceOutputVoiceURI: next.voiceOutputVoiceURI,
              autoSpeakResponses: next.autoSpeakResponses,
              neuralVoiceName: next.neuralVoiceName,
              preferNeuralVoice: next.preferNeuralVoice,
              handsFreeLoop: next.handsFreeLoop,
              currency: next.displayCurrency,
            })
            .catch(notifyCloudSyncError);
        }
        return next;
      });
    },
    [notifyCloudSyncError, session]
  );

  const setUnifiedLanguage = useCallback(
    (code: LanguageCode) => {
      const def = getLanguageDef(code);
      setLanguagePrefs((prev) => {
        const next: LanguagePreferences = prev.useSameLanguageEverywhere
          ? {
              ...prev,
              displayLanguage: def.code,
              textAssistantLanguage: def.code,
              voiceInputLocale: def.defaultSpeechLocale,
              voiceOutputLocale: def.defaultSpeechLocale,
              voiceOutputVoiceURI: 'auto',
            }
          : {
              ...prev,
              displayLanguage: def.code,
            };
        if (session && session.authMode !== 'demo-local') {
          firestoreRepository
            .updateUserProfileDoc(session.user.id, {
              displayLanguage: next.displayLanguage,
              textAssistantLanguage: next.textAssistantLanguage,
              voiceInputLocale: next.voiceInputLocale,
              voiceOutputLocale: next.voiceOutputLocale,
              voiceOutputVoiceURI: next.voiceOutputVoiceURI,
            })
            .catch(() => {});
        }
        return next;
      });
    },
    [session]
  );

  const updateSettings = useCallback(
    (patch: Partial<AppSettings>) => {
      setSettings((prev) => {
        const next = { ...prev, ...patch };
        if (session && session.authMode !== 'demo-local') {
          firestoreRepository
            .updateUserProfileDoc(session.user.id, {
              reducedMotion: next.reducedMotion,
              voiceSpeechRate: next.voiceSpeechRate,
            })
            .catch(() => {});
        }
        return next;
      });
    },
    [session]
  );

  // Firebase Google Sign-In
  const signInWithGoogle = useCallback(
    async (onboarding?: OnboardingOverrides): Promise<{ ok: boolean; error?: string }> => {
      setAuthError(null);
      pendingOnboardingRef.current = {
        ...onboarding,
        languagePrefs,
        theme,
      };
      try {
        await signInWithPopup(auth, googleProvider);
        return { ok: true };
      } catch (err) {
        pendingOnboardingRef.current = undefined;
        const msg = mapFirebaseAuthError(err);
        setAuthError(msg);
        return { ok: false, error: msg };
      }
    },
    [languagePrefs, theme]
  );

  const signInWithEmailFirebase = useCallback(
    async (email: string, password: string): Promise<{ ok: boolean; error?: string }> => {
      setAuthError(null);
      try {
        const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
        if (!cred.user.emailVerified) {
          await sendEmailVerification(cred.user).catch(() => {});
          await signOut(auth);
          const msg =
            'Please verify your email address first. A fresh verification link has been sent to your inbox.';
          setAuthError(msg);
          return { ok: false, error: msg };
        }
        return { ok: true };
      } catch (err) {
        const msg = mapFirebaseAuthError(err);
        setAuthError(msg);
        return { ok: false, error: msg };
      }
    },
    []
  );

  const registerWithEmailFirebase = useCallback(
    async (
      payload: RegisterPayload & {
        avatarCategory?: AvatarCategory;
        avatarPresetId?: string;
        customPhotoDataUrl?: string;
        enabledDomains?: DomainId[];
        currency?: DisplayCurrency;
      }
    ): Promise<{ ok: boolean; error?: string; verificationSent?: boolean }> => {
      setAuthError(null);
      if (payload.password !== payload.confirmPassword) {
        return { ok: false, error: 'Passwords do not match.' };
      }
      const onboardingSnapshot: OnboardingOverrides = {
        name: payload.name,
        role: payload.role,
        businessName: payload.businessName,
        avatarCategory: payload.avatarCategory,
        avatarPresetId: payload.avatarPresetId,
        customPhotoDataUrl: payload.customPhotoDataUrl,
        enabledDomains: payload.enabledDomains,
        currency: payload.currency,
        languagePrefs,
        theme,
      };
      pendingOnboardingRef.current = onboardingSnapshot;
      savePendingOnboarding(payload.email, onboardingSnapshot);
      try {
        const cred = await createUserWithEmailAndPassword(auth, payload.email.trim(), payload.password);
        await updateProfile(cred.user, { displayName: payload.name.trim() }).catch(() => {});
        await sendEmailVerification(cred.user);
        await signOut(auth);
        return {
          ok: true,
          verificationSent: true,
        };
      } catch (err) {
        pendingOnboardingRef.current = undefined;
        consumePendingOnboarding(payload.email);
        const msg = mapFirebaseAuthError(err);
        setAuthError(msg);
        return { ok: false, error: msg };
      }
    },
    [languagePrefs, theme]
  );

  // Demo Sign-In (explicit local-only preview)
  const loginDemo = useCallback(
    (creds: LoginCredentials) => {
      const res = authService.loginDemo(creds);
      if (!res.ok || !res.data) {
        return { ok: false, error: res.error || 'Authentication failed.' };
      }
      loadDemoDataIntoState();
      const welcomeMessage = `Welcome to FinX Demo Workspace, ${res.data.user.name}!`;
      setSession({ ...res.data, welcomeMessage });
      setPostLoginGreeting(welcomeMessage);
      setWorkspaces([
        {
          id: 'ws-demo-primary',
          ownerId: res.data.user.id,
          name: res.data.user.businessName,
          domain: 'product-business',
          currency: res.data.user.currency,
          isDefault: true,
          createdAt: res.data.user.createdAt,
          updatedAt: new Date().toISOString(),
        },
      ]);
      const savedDemoLang = loadSavedLanguagePrefs(DEMO_LANG_KEY);
      if (localStorage.getItem(DEMO_LANG_KEY)) {
        setLanguagePrefs(savedDemoLang);
      }
      setRoute('dashboard');
      setRouteHistory([]);
      return { ok: true };
    },
    [loadDemoDataIntoState]
  );

  const loginOneClickDemo = useCallback(
    (onboarding?: OnboardingOverrides) => {
      const res = authService.loginOneClickDemo();
      if (res.ok && res.data) {
        loadDemoDataIntoState();
        const user: UserProfile = {
          ...res.data.user,
          avatarCategory: onboarding?.avatarCategory || res.data.user.avatarCategory,
          avatarPresetId: onboarding?.avatarPresetId || res.data.user.avatarPresetId,
          customPhotoDataUrl: onboarding?.customPhotoDataUrl || res.data.user.customPhotoDataUrl,
          enabledDomains:
            onboarding?.enabledDomains && onboarding.enabledDomains.length > 0
              ? onboarding.enabledDomains
              : res.data.user.enabledDomains,
        };
        const welcomeMessage = `Welcome to FinX Demo Preview, ${user.name}! Synthetic demo data is active.`;
        setSession({ ...res.data, user, welcomeMessage });
        setPostLoginGreeting(welcomeMessage);
        setWorkspaces([
          {
            id: 'ws-demo-primary',
            ownerId: user.id,
            name: user.businessName,
            domain: user.enabledDomains[0] || 'personal-finance',
            currency: user.currency,
            isDefault: true,
            createdAt: user.createdAt,
            updatedAt: new Date().toISOString(),
          },
        ]);
        const savedDemoLang = loadSavedLanguagePrefs(DEMO_LANG_KEY);
        if (localStorage.getItem(DEMO_LANG_KEY)) {
          setLanguagePrefs(savedDemoLang);
        }
        setRoute('dashboard');
        setRouteHistory([]);
      }
    },
    [loadDemoDataIntoState]
  );

  const registerDemo = useCallback(
    (payload: RegisterPayload & OnboardingOverrides) => {
      const res = authService.registerDemo(payload);
      if (!res.ok || !res.data) {
        return { ok: false, error: res.error || 'Registration failed.' };
      }
      loadDemoDataIntoState();
      const user: UserProfile = {
        ...res.data.user,
        avatarCategory: payload.avatarCategory || 'neutral',
        avatarPresetId: payload.avatarPresetId || 'neutral-compass',
        customPhotoDataUrl: payload.customPhotoDataUrl,
        enabledDomains:
          payload.enabledDomains && payload.enabledDomains.length > 0
            ? payload.enabledDomains
            : [...ALL_DOMAIN_IDS],
        activeWorkspaceId: 'ws-demo-primary',
      };
      const welcomeMessage = `Welcome to FinX, ${user.name}! Your workspace "${user.businessName}" is ready.`;
      setSession({ ...res.data, user, welcomeMessage });
      setPostLoginGreeting(welcomeMessage);
      setWorkspaces([
        {
          id: 'ws-demo-primary',
          ownerId: user.id,
          name: user.businessName,
          domain: user.enabledDomains[0] || 'personal-finance',
          currency: user.currency,
          isDefault: true,
          createdAt: user.createdAt,
          updatedAt: new Date().toISOString(),
        },
      ]);
      setRoute('dashboard');
      setRouteHistory([]);
      return { ok: true };
    },
    [loadDemoDataIntoState]
  );

  const logout = useCallback(async () => {
    if (fsUnsubscribeRef.current) {
      fsUnsubscribeRef.current();
      fsUnsubscribeRef.current = null;
    }
    if (auth.currentUser) {
      await signOut(auth).catch(() => {});
    }
    setSession(null);
    setWorkspaces([]);
    setAuditLogs([]);
    setPostLoginGreeting(null);
    setYtdDrawerOpen(false);
    setRoute('welcome');
    setRouteHistory([]);
    setLanguagePrefs(loadSavedLanguagePrefs(GUEST_LANG_KEY));
  }, []);

  const updateUserProfile = useCallback(
    async (
      patch: Partial<
        Pick<
          UserProfile,
          'name' | 'businessName' | 'role' | 'avatarCategory' | 'avatarPresetId' | 'customPhotoDataUrl' | 'enabledDomains' | 'currency'
        >
      >
    ) => {
      setSession((prev) =>
        prev
          ? {
              ...prev,
              user: {
                ...prev.user,
                ...patch,
              },
            }
          : null
      );

      if (patch.businessName !== undefined && session) {
        setWorkspaces((prev) =>
          prev.map((w) =>
            w.id === session.user.activeWorkspaceId ? { ...w, name: patch.businessName! } : w
          )
        );
      }

      if (session && session.authMode !== 'demo-local') {
        try {
          await firestoreRepository.updateUserProfileDoc(session.user.id, {
            name: patch.name,
            role: patch.role,
            avatarCategory: patch.avatarCategory,
            avatarPresetId: patch.avatarPresetId,
            customPhotoDataUrl: patch.customPhotoDataUrl,
            enabledDomains: patch.enabledDomains,
            currency: patch.currency,
          });
          if (patch.businessName !== undefined) {
            await firestoreRepository.updateWorkspaceName(
              session.user.id,
              session.user.activeWorkspaceId,
              patch.businessName
            );
          }
        } catch (err) {
          notifyCloudSyncError(err);
          return;
        }
      }
      pushToast({ kind: 'success', title: t('common:toast.saved') });
    },
    [notifyCloudSyncError, pushToast, session, t]
  );

  const activeWorkspace = useMemo(() => {
    if (!session) return null;
    return workspaces.find((w) => w.id === session.user.activeWorkspaceId) || workspaces[0] || null;
  }, [session, workspaces]);

  const createWorkspace = useCallback(
    async (input: {
      name: string;
      domain: DomainId;
      description?: string;
      currency: DisplayCurrency;
    }): Promise<WorkspaceProfile | null> => {
      if (!session) return null;
      const trimmedName = input.name.trim();
      if (!trimmedName) return null;

      if (session.authMode === 'demo-local') {
        const ws: WorkspaceProfile = {
          id: generateId('ws'),
          ownerId: session.user.id,
          name: trimmedName,
          domain: input.domain,
          description: input.description,
          currency: input.currency,
          isDefault: false,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        setWorkspaces((prev) => [...prev, ws]);
        setSession((prev) =>
          prev
            ? {
                ...prev,
                user: {
                  ...prev.user,
                  activeWorkspaceId: ws.id,
                  businessName: ws.name,
                  enabledDomains: Array.from(new Set([...prev.user.enabledDomains, input.domain])),
                },
              }
            : null
        );
        pushToast({ kind: 'success', title: `Workspace "${ws.name}" created` });
        return ws;
      }

      const created = await firestoreRepository.createWorkspaceDoc(session.user.id, input);
      const nextDomains = Array.from(new Set([...session.user.enabledDomains, input.domain]));
      await firestoreRepository.updateUserProfileDoc(session.user.id, {
        activeWorkspaceId: created.id,
        enabledDomains: nextDomains,
      });
      setWorkspaces((prev) => [...prev, created]);
      setSession((prev) =>
        prev
          ? {
              ...prev,
              user: {
                ...prev.user,
                activeWorkspaceId: created.id,
                businessName: created.name,
                enabledDomains: nextDomains,
              },
            }
          : null
      );
      clearDomainStateForFirebaseWorkspace();
      attachWorkspaceSubscription(session.user.id, created.id);
      pushToast({ kind: 'success', title: `Created & switched to "${created.name}"` });
      return created;
    },
    [attachWorkspaceSubscription, clearDomainStateForFirebaseWorkspace, pushToast, session]
  );

  const switchWorkspace = useCallback(
    async (workspaceId: string) => {
      if (!session) return;
      const target = workspaces.find((w) => w.id === workspaceId);
      if (!target) return;

      setSession((prev) =>
        prev
          ? {
              ...prev,
              user: {
                ...prev.user,
                activeWorkspaceId: target.id,
                businessName: target.name,
              },
            }
          : null
      );

      if (session.authMode !== 'demo-local') {
        await firestoreRepository.updateUserProfileDoc(session.user.id, {
          activeWorkspaceId: target.id,
        });
        clearDomainStateForFirebaseWorkspace();
        attachWorkspaceSubscription(session.user.id, target.id);
      }

      pushToast({ kind: 'info', title: `Switched workspace to "${target.name}"` });
    },
    [attachWorkspaceSubscription, clearDomainStateForFirebaseWorkspace, pushToast, session, workspaces]
  );

  const toggleEnabledDomain = useCallback(
    async (domainId: DomainId) => {
      if (!session) return;
      const current = session.user.enabledDomains;
      const exists = current.includes(domainId);
      if (exists && current.length <= 1) {
        pushToast({
          kind: 'warning',
          title: 'At least one financial domain must remain active.',
        });
        return;
      }
      const next = exists ? current.filter((d) => d !== domainId) : [...current, domainId];
      await updateUserProfile({ enabledDomains: next });
    },
    [pushToast, session, updateUserProfile]
  );

  // Explicit starter kit seeder for authenticated real users who want sample records to explore
  const seedSampleWorkspaceData = useCallback(async () => {
    if (!session || session.authMode === 'demo-local') return;
    const uid = session.user.id;
    const wsId = session.user.activeWorkspaceId;
    const today = new Date().toISOString().slice(0, 10);

    await Promise.all([
      firestoreRepository.upsertLedgerEntry(uid, wsId, {
        id: generateId('tx'),
        domain: 'personal-finance',
        recordKind: 'personal_tx',
        txType: 'income',
        title: 'Monthly Salary Deposit',
        category: 'Salary & Income',
        amount: 4200,
        date: today,
        paymentMethod: 'Bank Transfer',
      }),
      firestoreRepository.upsertLedgerEntry(uid, wsId, {
        id: generateId('tx'),
        domain: 'personal-finance',
        recordKind: 'personal_tx',
        txType: 'expense',
        title: 'Household Groceries & Essentials',
        category: 'Food & Dining',
        amount: 245,
        date: today,
        paymentMethod: 'Credit Card',
      }),
      firestoreRepository.upsertDomainEntity(uid, wsId, {
        id: generateId('bdg'),
        domain: 'personal-finance',
        entityType: 'budget',
        title: 'Food & Dining',
        status: 'Active',
        payload: { monthlyLimit: 800, alertThresholdPercent: 85 },
      }),
      firestoreRepository.upsertDomainEntity(uid, wsId, {
        id: generateId('prod'),
        domain: 'product-business',
        entityType: 'product',
        title: 'Ergonomic Desk Stand',
        status: 'Active',
        payload: {
          productCode: 'FX-STD-101',
          category: 'Workspace Hardware',
          purchaseCost: 34,
          sellingPrice: 89,
          availableQuantity: 28,
          reorderLevel: 10,
          unitsSold: 0,
        },
      }),
      firestoreRepository.upsertDomainEntity(uid, wsId, {
        id: generateId('cli'),
        domain: 'service-business',
        entityType: 'client',
        title: 'Horizon Advisory Client',
        status: 'Pending',
        payload: {
          contact: 'finance@horizon.example',
          serviceProvided: 'Quarterly Cash-Flow Review',
          agreedAmount: 2400,
          paidAmount: 1200,
          dueDate: today,
          projectTitle: 'Q4 Advisory Retainer',
          lastUpdated: today,
        },
      }),
      firestoreRepository.appendAuditLog(
        uid,
        wsId,
        'SAMPLE_KIT_ADDED',
        'system',
        'Added starter records for exploration.'
      ),
    ]);

    pushToast({ kind: 'success', title: 'Starter sample records saved to your workspace' });
  }, [pushToast, session]);

  // Draft helpers
  const setDraft = useCallback((formKey: string, values: Record<string, unknown>) => {
    setDrafts((prev) => {
      const next = { ...prev, [formKey]: values };
      try {
        sessionStorage.setItem(DRAFTS_STORAGE_KEY, JSON.stringify(next));
      } catch {
        // ignore storage quota errors
      }
      return next;
    });
  }, []);

  const clearDraft = useCallback((formKey: string) => {
    setDrafts((prev) => {
      if (!(formKey in prev)) return prev;
      const copy = { ...prev };
      delete copy[formKey];
      try {
        sessionStorage.setItem(DRAFTS_STORAGE_KEY, JSON.stringify(copy));
      } catch {
        // ignore
      }
      return copy;
    });
  }, []);

  const persistFinXMessage = useCallback(
    (msg: FinXMessage) => {
      if (!isFirebaseActive || !session) return;
      firestoreRepository
        .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
          id: msg.id,
          domain: 'personal-finance',
          entityType: 'finx_message',
          title: msg.title,
          status: msg.read ? 'Read' : 'Unread',
          payload: {
            msgType: msg.type,
            sender: msg.sender,
            content: msg.content,
            hasAmount: msg.amount !== undefined,
            amount: msg.amount ?? 0,
            referenceId: msg.referenceId || '',
            timestamp: msg.timestamp,
            sourceDomain: msg.sourceDomain,
          },
        })
        .catch(notifyCloudSyncError);
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  // Domain 1 CRUD + internal FinX Message triggers + Firestore sync
  const addTransaction = useCallback(
    (tx: Omit<PersonalTransaction, 'id'>) => {
      const created: PersonalTransaction = { ...tx, id: generateId('tx') };
      setTransactions((prev) => [created, ...prev]);

      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertLedgerEntry(session.user.id, session.user.activeWorkspaceId, {
            id: created.id,
            domain: 'personal-finance',
            recordKind: 'personal_tx',
            txType: created.type,
            title: created.description,
            category: created.category,
            amount: created.amount,
            date: created.date,
            paymentMethod: created.paymentMethod,
            notes: created.notes,
          })
          .catch(notifyCloudSyncError);
      }

      const msg = workspaceRepository.createInternalMessage({
        type: created.type === 'income' ? 'payment_received' : 'payment_sent',
        sender: 'FinX Personal Ledger',
        title: `${created.type === 'income' ? 'Income' : 'Expense'} Recorded — ${created.description}`,
        content: `Internal FinX record added for ${created.category} (${created.paymentMethod}).`,
        amount: created.amount,
        referenceId: created.id.toUpperCase(),
        sourceDomain: 'Personal Finance',
      });
      setMessages((prev) => [msg, ...prev]);
      persistFinXMessage(msg);

      if (created.type === 'expense' && settings.budgetWarningNotifications) {
        const budget = budgets.find((b) => b.category === created.category);
        if (budget) {
          const txMonthPrefix = created.date.slice(0, 7);
          const currentSpent =
            transactions
              .filter(
                (tItem) =>
                  tItem.type === 'expense' &&
                  tItem.category === created.category &&
                  tItem.date.startsWith(txMonthPrefix)
              )
              .reduce((s, tItem) => s + tItem.amount, 0) + created.amount;
          const pct = Math.round((currentSpent / budget.monthlyLimit) * 100);
          if (pct >= budget.alertThresholdPercent) {
            const warnMsg = workspaceRepository.createInternalMessage({
              type: 'budget_warning',
              sender: 'FinX Budget Guard',
              title: `Budget Warning — ${created.category} at ${pct}%`,
              content: `Spending in ${created.category} has reached ${formatCurrency(currentSpent, languagePrefs.displayCurrency)} of your ${formatCurrency(budget.monthlyLimit, languagePrefs.displayCurrency)} limit.`,
              amount: currentSpent,
              referenceId: budget.id.toUpperCase(),
              sourceDomain: 'Personal Finance',
            });
            setMessages((prev) => [warnMsg, ...prev]);
            persistFinXMessage(warnMsg);
          }
        }
      }
      pushToast({ kind: 'success', title: t('common:toast.saved') });
    },
    [budgets, isFirebaseActive, languagePrefs.displayCurrency, notifyCloudSyncError, persistFinXMessage, pushToast, session, settings.budgetWarningNotifications, t, transactions]
  );

  const updateTransaction = useCallback(
    (updated: PersonalTransaction) => {
      setTransactions((prev) => prev.map((tx) => (tx.id === updated.id ? updated : tx)));
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertLedgerEntry(session.user.id, session.user.activeWorkspaceId, {
            id: updated.id,
            domain: 'personal-finance',
            recordKind: 'personal_tx',
            txType: updated.type,
            title: updated.description,
            category: updated.category,
            amount: updated.amount,
            date: updated.date,
            paymentMethod: updated.paymentMethod,
            notes: updated.notes,
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  const deleteTransaction = useCallback(
    (id: string) => {
      setTransactions((prev) => prev.filter((tx) => tx.id !== id));
      if (isFirebaseActive && session) {
        firestoreRepository
          .deleteLedgerEntry(session.user.id, session.user.activeWorkspaceId, id)
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'info', title: t('common:toast.deleted') });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session, t]
  );

  const updateBudgetLimit = useCallback(
    (id: string, limit: number) => {
      const target = budgets.find((b) => b.id === id);
      const nextLimit = Math.max(1, limit);
      setBudgets((prev) =>
        prev.map((b) => (b.id === id ? { ...b, monthlyLimit: nextLimit } : b))
      );
      if (isFirebaseActive && session && target) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'personal-finance',
            entityType: 'budget',
            title: target.category,
            status: 'Active',
            payload: { monthlyLimit: nextLimit, alertThresholdPercent: target.alertThresholdPercent },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [budgets, isFirebaseActive, notifyCloudSyncError, session]
  );

  const addBudgetCategory = useCallback(
    (category: string, monthlyLimit: number) => {
      const id = generateId('bdg');
      setBudgets((prev) => [...prev, { id, category, monthlyLimit, alertThresholdPercent: 85 }]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'personal-finance',
            entityType: 'budget',
            title: category,
            status: 'Active',
            payload: { monthlyLimit, alertThresholdPercent: 85 },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  const addSavingsGoal = useCallback(
    (goal: Omit<SavingsGoal, 'id'>) => {
      const id = generateId('goal');
      setSavingsGoals((prev) => [...prev, { ...goal, id }]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'personal-finance',
            entityType: 'goal',
            title: goal.title,
            status: 'Active',
            payload: {
              targetAmount: goal.targetAmount,
              currentAmount: goal.currentAmount,
              targetDate: goal.targetDate,
              priority: goal.priority,
            },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  const contributeToGoal = useCallback(
    (id: string, amount: number) => {
      const target = savingsGoals.find((g) => g.id === id);
      if (!target) return;
      const nextAmt = target.currentAmount + amount;
      setSavingsGoals((prev) =>
        prev.map((g) => (g.id === id ? { ...g, currentAmount: nextAmt } : g))
      );
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'personal-finance',
            entityType: 'goal',
            title: target.title,
            status: nextAmt >= target.targetAmount ? 'Completed' : 'Active',
            payload: {
              targetAmount: target.targetAmount,
              currentAmount: nextAmt,
              targetDate: target.targetDate,
              priority: target.priority,
            },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, savingsGoals, session]
  );

  const toggleBillPaid = useCallback(
    (id: string) => {
      const target = bills.find((b) => b.id === id);
      if (!target) return;
      const nextStatus: BillItem['status'] = target.status === 'Paid' ? 'Upcoming' : 'Paid';
      setBills((prev) => prev.map((b) => (b.id === id ? { ...b, status: nextStatus } : b)));
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'personal-finance',
            entityType: 'bill',
            title: target.title,
            status: nextStatus,
            payload: {
              amount: target.amount,
              dueDate: target.dueDate,
              category: target.category,
              autopay: target.autopay,
            },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [bills, isFirebaseActive, notifyCloudSyncError, session]
  );

  const toggleSubscriptionActive = useCallback(
    (id: string) => {
      const target = subscriptions.find((s) => s.id === id);
      if (!target) return;
      const nextActive = !target.active;
      setSubscriptions((prev) => prev.map((s) => (s.id === id ? { ...s, active: nextActive } : s)));
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'personal-finance',
            entityType: 'subscription',
            title: target.name,
            status: nextActive ? 'Active' : 'Paused',
            payload: {
              amount: target.amount,
              billingCycle: target.billingCycle,
              nextBillingDate: target.nextBillingDate,
              category: target.category,
            },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session, subscriptions]
  );

  // Domain 2: Product Business
  const addProduct = useCallback(
    (prod: Omit<ProductItem, 'id' | 'unitsSold'>) => {
      const id = generateId('prod');
      setProducts((prev) => [{ ...prod, id, unitsSold: 0 }, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'product-business',
            entityType: 'product',
            title: prod.name,
            status: 'Active',
            payload: {
              productCode: prod.productCode,
              category: prod.category,
              purchaseCost: prod.purchaseCost,
              sellingPrice: prod.sellingPrice,
              availableQuantity: prod.availableQuantity,
              reorderLevel: prod.reorderLevel,
              unitsSold: 0,
            },
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: `Product "${prod.name}" added` });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session]
  );

  const updateProduct = useCallback(
    (prod: ProductItem) => {
      setProducts((prev) => prev.map((p) => (p.id === prod.id ? prod : p)));
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id: prod.id,
            domain: 'product-business',
            entityType: 'product',
            title: prod.name,
            status: 'Active',
            payload: {
              productCode: prod.productCode,
              category: prod.category,
              purchaseCost: prod.purchaseCost,
              sellingPrice: prod.sellingPrice,
              availableQuantity: prod.availableQuantity,
              reorderLevel: prod.reorderLevel,
              unitsSold: prod.unitsSold,
            },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  const deleteProduct = useCallback(
    (id: string) => {
      setProducts((prev) => prev.filter((p) => p.id !== id));
      if (isFirebaseActive && session) {
        firestoreRepository
          .deleteDomainEntity(session.user.id, session.user.activeWorkspaceId, id)
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  const addSupplier = useCallback(
    (sup: Omit<SupplierItem, 'id'>) => {
      const id = generateId('sup');
      setSuppliers((prev) => [{ ...sup, id }, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'product-business',
            entityType: 'supplier',
            title: sup.name,
            status: 'Active',
            payload: {
              contact: sup.contact,
              category: sup.category,
              leadTimeDays: sup.leadTimeDays,
              notes: sup.notes || '',
            },
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: `Supplier "${sup.name}" added` });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session]
  );

  const addCustomer = useCallback(
    (cust: Omit<CustomerItem, 'id'>) => {
      const id = generateId('cust');
      setCustomers((prev) => [{ ...cust, id }, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'product-business',
            entityType: 'customer',
            title: cust.name,
            status: 'Active',
            payload: {
              contact: cust.contact,
              totalOrders: cust.totalOrders,
              totalSpent: cust.totalSpent,
              lastOrderDate: cust.lastOrderDate,
            },
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: `Customer "${cust.name}" added` });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session]
  );

  const recordSale = useCallback(
    (params: { productId: string; quantity: number; customerName: string }) => {
      const target = products.find((p) => p.id === params.productId);
      if (!target) return { ok: false, error: 'Product not found.' };
      if (params.quantity <= 0) return { ok: false, error: 'Quantity must be positive.' };
      if (params.quantity > target.availableQuantity) {
        return {
          ok: false,
          error: `Only ${target.availableQuantity} units available in stock.`,
        };
      }

      const nextQty = target.availableQuantity - params.quantity;
      const nextUnitsSold = target.unitsSold + params.quantity;
      const totalAmount = target.sellingPrice * params.quantity;
      const today = new Date().toISOString().slice(0, 10);
      const sale: SaleRecord = {
        id: generateId('sale'),
        productId: target.id,
        productName: target.name,
        quantity: params.quantity,
        unitPrice: target.sellingPrice,
        totalAmount,
        date: today,
        customerName: params.customerName.trim() || 'Walk-in Customer',
      };

      setProducts((prev) =>
        prev.map((p) =>
          p.id === target.id
            ? { ...p, availableQuantity: nextQty, unitsSold: nextUnitsSold }
            : p
        )
      );
      setSales((prev) => [sale, ...prev]);

      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id: target.id,
            domain: 'product-business',
            entityType: 'product',
            title: target.name,
            status: 'Active',
            payload: {
              productCode: target.productCode,
              category: target.category,
              purchaseCost: target.purchaseCost,
              sellingPrice: target.sellingPrice,
              availableQuantity: nextQty,
              reorderLevel: target.reorderLevel,
              unitsSold: nextUnitsSold,
            },
          })
          .catch(notifyCloudSyncError);

        firestoreRepository
          .upsertLedgerEntry(session.user.id, session.user.activeWorkspaceId, {
            id: sale.id,
            domain: 'product-business',
            recordKind: 'product_sale',
            txType: 'income',
            title: target.name,
            category: target.category,
            amount: totalAmount,
            quantity: params.quantity,
            unitPrice: target.sellingPrice,
            date: today,
            counterparty: sale.customerName,
            referenceCode: target.id,
          })
          .catch(notifyCloudSyncError);
      }

      const saleMsg = workspaceRepository.createInternalMessage({
        type: 'business_payment_confirmation',
        sender: 'FinX Product Ledger',
        title: `Product Sale Recorded — ${target.name}`,
        content: `Sold ${params.quantity} unit(s) to ${sale.customerName}. Internal ledger updated.`,
        amount: totalAmount,
        referenceId: sale.id.toUpperCase(),
        sourceDomain: 'Product Business',
      });
      setMessages((prev) => [saleMsg, ...prev]);
      persistFinXMessage(saleMsg);

      if (nextQty <= target.reorderLevel && settings.lowStockNotifications) {
        const stockMsg = workspaceRepository.createInternalMessage({
          type: 'low_inventory',
          sender: 'FinX Inventory Monitor',
          title: `Low Stock Alert — ${target.name}`,
          content: `Remaining stock is ${nextQty} unit(s) (reorder threshold: ${target.reorderLevel}).`,
          referenceId: target.productCode,
          sourceDomain: 'Product Business',
        });
        setMessages((prev) => [stockMsg, ...prev]);
        persistFinXMessage(stockMsg);
      }

      pushToast({ kind: 'success', title: `Sale recorded: ${target.name}` });
      return { ok: true };
    },
    [isFirebaseActive, notifyCloudSyncError, persistFinXMessage, products, pushToast, session, settings.lowStockNotifications]
  );

  const restockProduct = useCallback(
    (params: { productId: string; quantity: number; supplier: string }) => {
      const target = products.find((p) => p.id === params.productId);
      if (!target || params.quantity <= 0) return;

      const today = new Date().toISOString().slice(0, 10);
      const nextQty = target.availableQuantity + params.quantity;
      const purchase: PurchaseRecord = {
        id: generateId('pur'),
        productId: target.id,
        productName: target.name,
        quantity: params.quantity,
        unitCost: target.purchaseCost,
        totalCost: target.purchaseCost * params.quantity,
        supplier: params.supplier.trim() || 'Primary Supplier',
        date: today,
      };

      setProducts((prev) =>
        prev.map((p) => (p.id === target.id ? { ...p, availableQuantity: nextQty } : p))
      );
      setPurchases((prev) => [purchase, ...prev]);

      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id: target.id,
            domain: 'product-business',
            entityType: 'product',
            title: target.name,
            status: 'Active',
            payload: {
              productCode: target.productCode,
              category: target.category,
              purchaseCost: target.purchaseCost,
              sellingPrice: target.sellingPrice,
              availableQuantity: nextQty,
              reorderLevel: target.reorderLevel,
              unitsSold: target.unitsSold,
            },
          })
          .catch(notifyCloudSyncError);

        firestoreRepository
          .upsertLedgerEntry(session.user.id, session.user.activeWorkspaceId, {
            id: purchase.id,
            domain: 'product-business',
            recordKind: 'product_purchase',
            txType: 'expense',
            title: `Restock ${target.name}`,
            category: 'Inventory Purchase',
            amount: purchase.totalCost,
            quantity: params.quantity,
            unitPrice: target.purchaseCost,
            date: today,
            counterparty: purchase.supplier,
            referenceCode: target.id,
          })
          .catch(notifyCloudSyncError);
      }

      pushToast({ kind: 'success', title: `Restocked +${params.quantity} ${target.name}` });
    },
    [isFirebaseActive, notifyCloudSyncError, products, pushToast, session]
  );

  const addBusinessExpense = useCallback(
    (exp: Omit<BusinessExpense, 'id'>) => {
      const created: BusinessExpense = { ...exp, id: generateId('bexp') };
      setBusinessExpenses((prev) => [created, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertLedgerEntry(session.user.id, session.user.activeWorkspaceId, {
            id: created.id,
            domain: created.domain === 'service' ? 'service-business' : 'product-business',
            recordKind: 'business_expense',
            txType: 'expense',
            title: created.description,
            category: created.category,
            amount: created.amount,
            date: created.date,
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: t('common:toast.saved') });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session, t]
  );

  // Domain 3: Service & Consultancy
  const addClient = useCallback(
    (client: Omit<ServiceClient, 'id' | 'lastUpdated'>) => {
      const today = new Date().toISOString().slice(0, 10);
      const created: ServiceClient = {
        ...client,
        id: generateId('cli'),
        lastUpdated: today,
      };
      setClients((prev) => [created, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id: created.id,
            domain: 'service-business',
            entityType: 'client',
            title: created.name,
            status: created.paymentStatus,
            payload: {
              contact: created.contact,
              serviceProvided: created.serviceProvided,
              agreedAmount: created.agreedAmount,
              paidAmount: created.paidAmount,
              dueDate: created.dueDate,
              projectTitle: created.projectTitle,
              lastUpdated: today,
            },
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: `Client "${created.name}" added` });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session]
  );

  const updateClient = useCallback(
    (client: ServiceClient) => {
      const today = new Date().toISOString().slice(0, 10);
      const updated = { ...client, lastUpdated: today };
      setClients((prev) => prev.map((c) => (c.id === client.id ? updated : c)));
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id: updated.id,
            domain: 'service-business',
            entityType: 'client',
            title: updated.name,
            status: updated.paymentStatus,
            payload: {
              contact: updated.contact,
              serviceProvided: updated.serviceProvided,
              agreedAmount: updated.agreedAmount,
              paidAmount: updated.paidAmount,
              dueDate: updated.dueDate,
              projectTitle: updated.projectTitle,
              lastUpdated: today,
            },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  const recordClientPayment = useCallback(
    (clientId: string, amount: number) => {
      if (!Number.isFinite(amount) || amount <= 0) return;
      const target = clients.find((c) => c.id === clientId);
      if (!target) return;

      const newPaid = Math.min(target.agreedAmount, target.paidAmount + amount);
      const newStatus: ServiceClient['paymentStatus'] =
        newPaid >= target.agreedAmount ? 'Paid' : newPaid > 0 ? 'Partial' : target.paymentStatus;
      const today = new Date().toISOString().slice(0, 10);

      setClients((prev) =>
        prev.map((c) =>
          c.id === clientId
            ? {
                ...c,
                paidAmount: newPaid,
                paymentStatus: newStatus,
                lastUpdated: today,
              }
            : c
        )
      );

      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id: target.id,
            domain: 'service-business',
            entityType: 'client',
            title: target.name,
            status: newStatus,
            payload: {
              contact: target.contact,
              serviceProvided: target.serviceProvided,
              agreedAmount: target.agreedAmount,
              paidAmount: newPaid,
              dueDate: target.dueDate,
              projectTitle: target.projectTitle,
              lastUpdated: today,
            },
          })
          .catch(notifyCloudSyncError);

        firestoreRepository
          .upsertLedgerEntry(session.user.id, session.user.activeWorkspaceId, {
            id: generateId('spay'),
            domain: 'service-business',
            recordKind: 'service_payment',
            txType: 'income',
            title: `Payment from ${target.name}`,
            category: target.serviceProvided || 'Consulting Revenue',
            amount,
            date: today,
            counterparty: target.name,
            paymentMethod: 'Bank Transfer',
            referenceCode: target.id,
          })
          .catch(notifyCloudSyncError);
      }

      const msg = workspaceRepository.createInternalMessage({
        type: 'business_payment_confirmation',
        sender: 'FinX Service Ledger',
        title: `Client Payment Recorded — ${target.name}`,
        content: `Internal FinX record updated: received ${formatCurrency(amount, languagePrefs.displayCurrency)} for ${target.projectTitle}. Status: ${newStatus}.`,
        amount,
        referenceId: target.id.toUpperCase(),
        sourceDomain: 'Service Business',
      });
      setMessages((msgs) => [msg, ...msgs]);
      persistFinXMessage(msg);
      pushToast({ kind: 'success', title: `Payment received from ${target.name}` });
    },
    [clients, isFirebaseActive, languagePrefs.displayCurrency, notifyCloudSyncError, persistFinXMessage, pushToast, session]
  );

  const addProject = useCallback(
    (proj: Omit<ServiceProject, 'id'>) => {
      const id = generateId('proj');
      setProjects((prev) => [{ ...proj, id }, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'service-business',
            entityType: 'project',
            title: proj.title,
            status: proj.status,
            payload: {
              clientId: proj.clientId,
              clientName: proj.clientName,
              startDate: proj.startDate,
              milestoneValue: proj.milestoneValue,
              directCost: proj.directCost || 0,
            },
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: `Project "${proj.title}" added` });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session]
  );

  const encodeInvoiceLinePayload = (inv: Omit<ServiceInvoice, 'id'> | ServiceInvoice): Record<string, string | number | boolean> => {
    const items = (inv.lineItems || []).slice(0, 6);
    const flat: Record<string, string | number | boolean> = {
      invoiceNumber: inv.invoiceNumber,
      clientId: inv.clientId,
      clientName: inv.clientName,
      issueDate: inv.issueDate,
      dueDate: inv.dueDate,
      amount: inv.amount,
      paidAmount: inv.paidAmount,
      lineSummary: items.map((l) => l.description).join('; '),
      lineCount: items.length,
    };
    items.forEach((item, idx) => {
      flat[`item${idx}Desc`] = item.description.slice(0, 120);
      flat[`item${idx}Amt`] = item.amount;
    });
    return flat;
  };

  const createInvoice = useCallback(
    (inv: Omit<ServiceInvoice, 'id'>) => {
      const id = generateId('inv');
      const created: ServiceInvoice = { ...inv, id };
      setInvoices((prev) => [created, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'service-business',
            entityType: 'invoice',
            title: inv.projectTitle,
            status: inv.status,
            payload: encodeInvoiceLinePayload(inv),
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: `Invoice ${inv.invoiceNumber} created` });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session]
  );

  const markInvoicePaid = useCallback(
    (invoiceId: string) => {
      const target = invoices.find((i) => i.id === invoiceId);
      if (!target) return;
      const updated: ServiceInvoice = { ...target, paidAmount: target.amount, status: 'Paid' };
      setInvoices((prev) => prev.map((i) => (i.id === invoiceId ? updated : i)));
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id: target.id,
            domain: 'service-business',
            entityType: 'invoice',
            title: target.projectTitle,
            status: 'Paid',
            payload: encodeInvoiceLinePayload(updated),
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: `Invoice ${target.invoiceNumber} marked Paid` });
    },
    [invoices, isFirebaseActive, notifyCloudSyncError, pushToast, session]
  );

  const addPayrollRecord = useCallback(
    (rec: Omit<PayrollRecord, 'id'>) => {
      const id = generateId('pay');
      setPayroll((prev) => [{ ...rec, id }, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertLedgerEntry(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'service-business',
            recordKind: 'payroll',
            txType: 'expense',
            title: rec.memberName,
            category: rec.role,
            amount: rec.amount,
            date: `${rec.period.slice(0, 7)}-01`,
            notes: rec.status,
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: `Payroll added for ${rec.memberName}` });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session]
  );

  const togglePayrollStatus = useCallback(
    (id: string) => {
      const target = payroll.find((p) => p.id === id);
      if (!target) return;
      const nextStatus: PayrollRecord['status'] = target.status === 'Paid' ? 'Scheduled' : 'Paid';
      setPayroll((prev) => prev.map((p) => (p.id === id ? { ...p, status: nextStatus } : p)));
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertLedgerEntry(session.user.id, session.user.activeWorkspaceId, {
            id: target.id,
            domain: 'service-business',
            recordKind: 'payroll',
            txType: 'expense',
            title: target.memberName,
            category: target.role,
            amount: target.amount,
            date: `${target.period.slice(0, 7)}-01`,
            notes: nextStatus,
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, payroll, session]
  );

  // Domain 4: Paper trading
  const addPaperTrade = useCallback(
    (trade: Omit<PaperTradePosition, 'id'>) => {
      const id = generateId('pt');
      setPaperTrades((prev) => [{ ...trade, id }, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'investment-knowledge',
            entityType: 'paper_trade',
            title: trade.name,
            status: 'Simulated',
            payload: {
              symbol: trade.symbol,
              assetClass: trade.assetClass,
              shares: trade.shares,
              simulatedEntryPrice: trade.simulatedEntryPrice,
              historicalReferencePrice: trade.historicalReferencePrice,
              purchaseDate: trade.purchaseDate,
            },
          })
          .catch(notifyCloudSyncError);
      }
      pushToast({ kind: 'success', title: `Paper position added: ${trade.symbol}` });
    },
    [isFirebaseActive, notifyCloudSyncError, pushToast, session]
  );

  // Intelligence metrics
  const metrics = useMemo(
    () =>
      intelligenceService.computeActualMetrics({
        transactions,
        products,
        sales,
        businessExpenses,
        clients,
        payroll,
      }),
    [businessExpenses, clients, payroll, products, sales, transactions]
  );

  // Unified YTD Transactions (live Firestore across all workspaces or derived from Demo workspace)
  const localDerivedYtd = useMemo<YtdUnifiedTransaction[]>(() => {
    const wsName = activeWorkspace?.name || session?.user.businessName || 'Workspace';
    const wsId = activeWorkspace?.id || 'ws-local';
    const list: YtdUnifiedTransaction[] = [];

    transactions.forEach((tx) => {
      list.push({
        id: tx.id,
        workspaceId: wsId,
        workspaceName: wsName,
        domain: 'personal-finance',
        recordKind: 'personal_tx',
        txType: tx.type,
        title: tx.description,
        category: tx.category,
        amount: tx.amount,
        date: tx.date,
        paymentMethod: tx.paymentMethod,
      });
    });

    sales.forEach((s) => {
      list.push({
        id: s.id,
        workspaceId: wsId,
        workspaceName: wsName,
        domain: 'product-business',
        recordKind: 'product_sale',
        txType: 'income',
        title: `Sale: ${s.productName} (x${s.quantity})`,
        category: 'Product Revenue',
        amount: s.totalAmount,
        date: s.date,
        counterparty: s.customerName,
      });
    });

    purchases.forEach((p) => {
      list.push({
        id: p.id,
        workspaceId: wsId,
        workspaceName: wsName,
        domain: 'product-business',
        recordKind: 'product_purchase',
        txType: 'expense',
        title: `Restock: ${p.productName} (x${p.quantity})`,
        category: 'Inventory Purchase',
        amount: p.totalCost,
        date: p.date,
        counterparty: p.supplier,
      });
    });

    businessExpenses.forEach((e) => {
      list.push({
        id: e.id,
        workspaceId: wsId,
        workspaceName: wsName,
        domain: e.domain === 'service' ? 'service-business' : 'product-business',
        recordKind: 'business_expense',
        txType: 'expense',
        title: e.description,
        category: e.category,
        amount: e.amount,
        date: e.date,
      });
    });

    const todayIso = new Date().toISOString().slice(0, 10);

    clients.forEach((c) => {
      if (c.paidAmount > 0) {
        list.push({
          id: `svc-${c.id}`,
          workspaceId: wsId,
          workspaceName: wsName,
          domain: 'service-business',
          recordKind: 'service_payment',
          txType: 'income',
          title: c.projectTitle || c.serviceProvided,
          category: 'Service Retainer',
          amount: c.paidAmount,
          date: c.lastUpdated || todayIso,
          counterparty: c.name,
        });
      }
    });

    payroll.forEach((pay) => {
      if (pay.status === 'Paid') {
        const payDate = /^\d{4}-\d{2}/.test(pay.period) ? `${pay.period.slice(0, 7)}-01` : `${todayIso.slice(0, 7)}-01`;
        list.push({
          id: `pay-${pay.id}`,
          workspaceId: wsId,
          workspaceName: wsName,
          domain: 'service-business',
          recordKind: 'payroll',
          txType: 'expense',
          title: `Payroll: ${pay.memberName}`,
          category: pay.role,
          amount: pay.amount,
          date: payDate,
          counterparty: pay.memberName,
        });
      }
    });

    return list.sort((a, b) => b.date.localeCompare(a.date));
  }, [activeWorkspace?.id, activeWorkspace?.name, businessExpenses, clients, payroll, purchases, sales, session?.user.businessName, transactions]);

  const refreshYtdTransactions = useCallback(async () => {
    setYtdLoading(true);
    setYtdError(null);
    try {
      if (isFirebaseActive && session && workspaces.length > 0) {
        const fetched = await firestoreRepository.fetchAllYtdLedgerEntries(session.user.id, workspaces);
        setFirebaseYtdEntries(fetched);
      }
      setYtdLastUpdated(new Date().toISOString());
    } catch (err) {
      setYtdError(sanitizeCloudError(err, 'Unable to refresh YTD ledger.'));
    } finally {
      setYtdLoading(false);
    }
  }, [isFirebaseActive, session, workspaces]);

  const ytdTransactions = useMemo(() => {
    if (isFirebaseActive && firebaseYtdEntries.length > 0) {
      return firebaseYtdEntries;
    }
    return localDerivedYtd;
  }, [firebaseYtdEntries, isFirebaseActive, localDerivedYtd]);

  // Refresh YTD automatically when drawer opens
  useEffect(() => {
    if (ytdDrawerOpen) {
      refreshYtdTransactions();
    }
  }, [refreshYtdTransactions, ytdDrawerOpen]);

  // Messages
  const unreadCount = useMemo(() => messages.filter((m) => !m.read).length, [messages]);

  const markMessageRead = useCallback(
    (id: string, read = true) => {
      const target = messages.find((m) => m.id === id);
      setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, read } : m)));
      if (target) {
        persistFinXMessage({ ...target, read });
      }
    },
    [messages, persistFinXMessage]
  );

  const markAllMessagesRead = useCallback(() => {
    setMessages((prev) => {
      const updated = prev.map((m) => ({ ...m, read: true }));
      prev.filter((m) => !m.read).forEach((m) => persistFinXMessage({ ...m, read: true }));
      return updated;
    });
  }, [persistFinXMessage]);

  const deleteMessage = useCallback(
    (id: string) => {
      setMessages((prev) => prev.filter((m) => m.id !== id));
      if (isFirebaseActive && session) {
        firestoreRepository
          .deleteDomainEntity(session.user.id, session.user.activeWorkspaceId, id)
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  // Documents
  const uploadDocumentDemo = useCallback(
    async (file: File, category: UploadedDocument['documentCategory']) => {
      const parsed = await documentsService.parseUploadedFileDemo(file, category);
      setDocuments((prev) => [parsed, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id: parsed.id,
            domain: 'personal-finance',
            entityType: 'uploaded_document',
            title: parsed.fileName,
            status: parsed.status,
            payload: {
              fileType: parsed.fileType,
              fileSizeKb: parsed.fileSizeKb,
              uploadedAt: parsed.uploadedAt,
              documentCategory: parsed.documentCategory,
              extractedSummary: parsed.extractedSummary,
              hasDetectedAmount: parsed.extractedFields.detectedAmount !== undefined,
              detectedAmount: parsed.extractedFields.detectedAmount ?? 0,
              documentDate: parsed.extractedFields.documentDate || '',
              vendorOrEntity: parsed.extractedFields.vendorOrEntity || '',
              suggestedCategory: parsed.extractedFields.suggestedCategory || '',
              referenceNumber: parsed.extractedFields.referenceNumber || '',
            },
          })
          .catch(notifyCloudSyncError);
      }
      return parsed;
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  // Plans
  const addPlan = useCallback(
    (plan: Omit<FinancialPlanItem, 'id'>) => {
      const id = generateId('plan');
      setPlans((prev) => [{ ...plan, id }, ...prev]);
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id,
            domain: 'personal-finance',
            entityType: 'plan',
            title: plan.title,
            status: plan.status,
            payload: {
              planType: plan.planType,
              targetAmount: plan.targetAmount,
              allocatedAmount: plan.allocatedAmount,
              dueDate: plan.dueDate,
              notes: plan.notes,
            },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  const updatePlan = useCallback(
    (plan: FinancialPlanItem) => {
      setPlans((prev) => prev.map((p) => (p.id === plan.id ? plan : p)));
      if (isFirebaseActive && session) {
        firestoreRepository
          .upsertDomainEntity(session.user.id, session.user.activeWorkspaceId, {
            id: plan.id,
            domain: 'personal-finance',
            entityType: 'plan',
            title: plan.title,
            status: plan.status,
            payload: {
              planType: plan.planType,
              targetAmount: plan.targetAmount,
              allocatedAmount: plan.allocatedAmount,
              dueDate: plan.dueDate,
              notes: plan.notes,
            },
          })
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  const deletePlan = useCallback(
    (id: string) => {
      setPlans((prev) => prev.filter((p) => p.id !== id));
      if (isFirebaseActive && session) {
        firestoreRepository
          .deleteDomainEntity(session.user.id, session.user.activeWorkspaceId, id)
          .catch(notifyCloudSyncError);
      }
    },
    [isFirebaseActive, notifyCloudSyncError, session]
  );

  // Extensions
  const logExtensionAction = useCallback(
    (ext: ExtensionDefinition, action: string, result: 'Success' | 'Blocked' = 'Success') => {
      setExtensionLogs((prev) => [
        {
          id: generateId('elog'),
          extensionId: ext.id,
          extensionName: ext.name,
          action,
          timestamp: new Date().toISOString(),
          result,
        },
        ...prev,
      ]);
    },
    []
  );

  const toggleExtensionStatus = useCallback(
    (id: string) => {
      const target = extensions.find((ext) => ext.id === id);
      if (!target) return;
      if (!target.compatible) {
        logExtensionAction(target, 'Blocked activation: requires FinX platform v1.2.0+', 'Blocked');
        return;
      }
      const nextStatus = target.status === 'Installed' ? 'Disabled' : 'Installed';
      setExtensions((prev) =>
        prev.map((ext) => (ext.id === id ? { ...ext, status: nextStatus } : ext))
      );
      logExtensionAction(target, `Changed extension state to ${nextStatus}`);
    },
    [extensions, logExtensionAction]
  );

  const installOptionalExtension = useCallback(
    (id: string) => {
      const target = extensions.find((ext) => ext.id === id);
      if (!target || target.status === 'Coming Soon') return;
      if (!target.compatible) {
        logExtensionAction(target, 'Compatibility validation failed', 'Blocked');
        return;
      }
      setExtensions((prev) =>
        prev.map((ext) => (ext.id === id ? { ...ext, status: 'Installed' } : ext))
      );
      logExtensionAction(target, `Installed optional module v${target.version}`);
    },
    [extensions, logExtensionAction]
  );

  const uninstallOptionalExtension = useCallback(
    (id: string) => {
      const target = extensions.find((ext) => ext.id === id);
      if (!target || !target.optional) return;
      setExtensions((prev) =>
        prev.map((ext) => (ext.id === id ? { ...ext, status: 'Available' } : ext))
      );
      logExtensionAction(target, 'Uninstalled optional extension from workspace');
    },
    [extensions, logExtensionAction]
  );

  const updateExtensionConfig = useCallback(
    (id: string, config: Record<string, string | boolean>) => {
      const target = extensions.find((ext) => ext.id === id);
      if (!target) return;
      setExtensions((prev) =>
        prev.map((ext) => (ext.id === id ? { ...ext, config } : ext))
      );
      logExtensionAction(target, 'Updated extension configuration preferences');
    },
    [extensions, logExtensionAction]
  );

  // Assistant Overlay controls
  const openAssistant = useCallback((mode?: 'finance-assistant' | 'finx-guide') => {
    if (mode) setAssistantMode(mode);
    setAssistantOpen(true);
    setAssistantMinimized(false);
  }, []);

  const minimizeAssistant = useCallback(() => {
    setAssistantMinimized(true);
    setAssistantOpen(false);
  }, []);

  const closeAssistant = useCallback(() => {
    setAssistantOpen(false);
    setAssistantMinimized(false);
  }, []);

  const resetAssistantChat = useCallback(() => {
    if (abortRef.current) {
      abortRef.current.abort();
      abortRef.current = null;
    }
    inFlightLockRef.current = false;
    setAssistantBusy(false);
    setAssistantError(null);
    const localizedGreeting = i18n.t('assistant:greeting', {
      lng: languagePrefs.textAssistantLanguage,
    });
    setAssistantMessages([
      {
        id: 'init-greeting',
        role: 'assistant',
        content: localizedGreeting,
        timestamp: new Date().toISOString(),
        mode: assistantMode,
        languageCode: languagePrefs.textAssistantLanguage,
      },
    ]);
  }, [assistantMode, languagePrefs.textAssistantLanguage]);

  const sendAssistantMessage = useCallback(
    async (
      rawText: string,
      overrideMode?: 'finance-assistant' | 'finx-guide'
    ): Promise<{ replyText: string; executedActionText?: string } | null> => {
      const trimmed = rawText.trim();
      if (!trimmed || inFlightLockRef.current) return null;

      inFlightLockRef.current = true;
      setAssistantBusy(true);
      setAssistantError(null);

      const activeMode = overrideMode || assistantMode;
      const isAuthenticated = Boolean(session);

      const userTurn: AssistantMessage = {
        id: generateId('usr'),
        role: 'user',
        content: trimmed,
        timestamp: new Date().toISOString(),
        mode: activeMode,
        languageCode: languagePrefs.textAssistantLanguage,
      };

      const historySnapshot = [...assistantMessages, userTurn];
      setAssistantMessages((prev) => [...prev, userTurn]);

      // Check centralized multilingual intent registry FIRST
      const matchedCommand = matchCentralizedVoiceCommand(trimmed, isAuthenticated);
      if (matchedCommand) {
        const executedText = getIntentConfirmationText(
          matchedCommand,
          languagePrefs.textAssistantLanguage
        );

        if (matchedCommand.type === 'theme' && matchedCommand.theme) {
          setTheme(matchedCommand.theme);
        } else if (matchedCommand.type === 'go-back') {
          goBack();
        } else if (
          (matchedCommand.type === 'navigate' || matchedCommand.type === 'open-notifications') &&
          matchedCommand.route
        ) {
          navigate(matchedCommand.route);
        }

        if (matchedCommand.type !== 'explain-page') {
          const cmdReply: AssistantMessage = {
            id: generateId('ast'),
            role: 'assistant',
            content: executedText,
            timestamp: new Date().toISOString(),
            mode: activeMode,
            languageCode: languagePrefs.textAssistantLanguage,
            suggestedRoute: matchedCommand.route,
          };
          setAssistantMessages((prev) => [...prev, cmdReply]);
          inFlightLockRef.current = false;
          setAssistantBusy(false);
          return { replyText: executedText, executedActionText: executedText };
        }
      }

      // Build strictly authorized workspace context ONLY if authenticated
      const authorizedSummary = isAuthenticated
        ? {
            userName: session?.user.name,
            businessName: session?.user.businessName,
            enabledDomains: session?.user.enabledDomains,
            displayCurrency: languagePrefs.displayCurrency,
            ytdTotals: {
              income: ytdTransactions.filter((tItem) => tItem.txType === 'income').reduce((s, tItem) => s + tItem.amount, 0),
              expense: ytdTransactions.filter((tItem) => tItem.txType === 'expense').reduce((s, tItem) => s + tItem.amount, 0),
              count: ytdTransactions.length,
            },
            personalFinance: {
              income: metrics.personalIncome,
              expenses: metrics.personalExpenses,
              netSavings: metrics.personalNetSavings,
              savingsRatePercent: metrics.savingsRatePercent,
              recentTransactions: transactions.slice(0, 6).map((tx) => ({
                description: tx.description,
                amount: tx.amount,
                category: tx.category,
                type: tx.type,
                date: tx.date,
              })),
              budgets: budgets.map((b) => ({
                category: b.category,
                monthlyLimit: b.monthlyLimit,
              })),
              savingsGoals: savingsGoals.map((g) => ({
                title: g.title,
                currentAmount: g.currentAmount,
                targetAmount: g.targetAmount,
              })),
            },
            productBusiness: {
              revenue: metrics.productRevenue,
              cogs: metrics.productCOGS,
              operatingExpenses: metrics.productOperatingExpenses,
              netProfit: metrics.productNetProfit,
              inventoryValuationAtCost: metrics.inventoryValuationAtCost,
              lowStockItems: products
                .filter((p) => p.availableQuantity <= p.reorderLevel)
                .map((p) => ({ name: p.name, available: p.availableQuantity, reorderAt: p.reorderLevel })),
            },
            serviceBusiness: {
              collectedRevenue: metrics.serviceCollectedRevenue,
              pendingReceivables: metrics.servicePendingReceivables,
              overdueAmount: metrics.serviceOverdueAmount,
              netProfit: metrics.serviceNetProfit,
              clientsCount: clients.length,
            },
            unreadMessagesCount: unreadCount,
          }
        : null;

      const controller = new AbortController();
      abortRef.current = controller;

      try {
        const cleanHistory = historySnapshot.slice(0, -1).filter((turn) => !turn.isError);

        const res = await aiAssistantService.sendMessage({
          message: trimmed,
          history: cleanHistory,
          language: languagePrefs.textAssistantLanguage,
          mode: activeMode,
          isAuthenticated,
          currentRoute: route,
          authorizedSummary,
          signal: controller.signal,
        });

        let executedActionText: string | undefined;
        if (res.themeAction === 'dark' || res.themeAction === 'light') {
          setTheme(res.themeAction);
          executedActionText = `Theme updated to ${res.themeAction}.`;
        }
        const validNavRoute =
          res.navigationRoute && VALID_WORKSPACE_ROUTES.has(res.navigationRoute)
            ? res.navigationRoute
            : null;
        if (validNavRoute && isAuthenticated) {
          navigate(validNavRoute);
          executedActionText = `Navigated to ${validNavRoute}.`;
        }

        const fullContent = res.followUpSuggestion
          ? `${res.reply}\n\n${res.followUpSuggestion}`
          : res.reply;

        const sources: GroundingSource[] | undefined =
          Array.isArray(res.sources) && res.sources.length > 0 ? res.sources : undefined;

        const assistantTurn: AssistantMessage = {
          id: generateId('ast'),
          role: 'assistant',
          content: fullContent,
          timestamp: new Date().toISOString(),
          mode: activeMode,
          languageCode: languagePrefs.textAssistantLanguage,
          detectedLanguage: res.detectedLanguage || undefined,
          sources,
          suggestedRoute: validNavRoute || undefined,
        };

        setAssistantMessages((prev) => [...prev, assistantTurn]);
        return { replyText: res.reply, executedActionText };
      } catch (err: unknown) {
        if ((err as Error)?.name === 'AbortError') return null;
        const msg = (err as Error)?.message || t('common:states.errorGeneric');
        setAssistantError(msg);
        const errTurn: AssistantMessage = {
          id: generateId('err'),
          role: 'assistant',
          content: `AI Service Notice: ${msg}`,
          timestamp: new Date().toISOString(),
          mode: activeMode,
          languageCode: languagePrefs.textAssistantLanguage,
          isError: true,
        };
        setAssistantMessages((prev) => [...prev, errTurn]);
        return null;
      } finally {
        inFlightLockRef.current = false;
        abortRef.current = null;
        setAssistantBusy(false);
      }
    },
    [
      assistantMessages,
      assistantMode,
      budgets,
      clients.length,
      goBack,
      languagePrefs.displayCurrency,
      languagePrefs.textAssistantLanguage,
      metrics,
      navigate,
      products,
      route,
      savingsGoals,
      session,
      setTheme,
      t,
      transactions,
      unreadCount,
      ytdTransactions,
    ]
  );

  const value: FinXContextValue = {
    theme,
    setTheme,
    toggleTheme,
    route,
    navigate,
    goBack,
    canGoBack: routeHistory.length > 0,
    session,
    isAuthenticated: Boolean(session),
    authLoading,
    authError,
    postLoginGreeting,
    dismissPostLoginGreeting,
    signInWithGoogle,
    signInWithEmailFirebase,
    registerWithEmailFirebase,
    loginDemo,
    loginOneClickDemo,
    registerDemo,
    logout,
    updateUserProfile,
    workspaces,
    activeWorkspace,
    createWorkspace,
    switchWorkspace,
    toggleEnabledDomain,
    seedSampleWorkspaceData,
    languagePrefs,
    updateLanguagePrefs,
    setUnifiedLanguage,
    settings,
    updateSettings,
    drafts,
    setDraft,
    clearDraft,
    toasts,
    pushToast,
    dismissToast,
    ytdDrawerOpen,
    setYtdDrawerOpen,
    ytdTransactions,
    ytdLoading,
    ytdError,
    ytdLastUpdated,
    refreshYtdTransactions,
    transactions,
    addTransaction,
    updateTransaction,
    deleteTransaction,
    budgets,
    updateBudgetLimit,
    addBudgetCategory,
    savingsGoals,
    addSavingsGoal,
    contributeToGoal,
    bills,
    toggleBillPaid,
    subscriptions,
    toggleSubscriptionActive,
    products,
    addProduct,
    updateProduct,
    deleteProduct,
    suppliers,
    addSupplier,
    customers,
    addCustomer,
    sales,
    recordSale,
    purchases,
    restockProduct,
    businessExpenses,
    addBusinessExpense,
    clients,
    addClient,
    updateClient,
    recordClientPayment,
    projects,
    addProject,
    invoices,
    createInvoice,
    markInvoicePaid,
    payroll,
    addPayrollRecord,
    togglePayrollStatus,
    paperTrades,
    addPaperTrade,
    metrics,
    auditLogs,
    messages,
    unreadCount,
    markMessageRead,
    markAllMessagesRead,
    deleteMessage,
    documents,
    uploadDocumentDemo,
    plans,
    addPlan,
    updatePlan,
    deletePlan,
    extensions,
    extensionLogs,
    toggleExtensionStatus,
    installOptionalExtension,
    uninstallOptionalExtension,
    updateExtensionConfig,
    assistantOpen,
    assistantMinimized,
    assistantMode,
    setAssistantMode,
    openAssistant,
    minimizeAssistant,
    closeAssistant,
    assistantMessages,
    assistantBusy,
    assistantError,
    aiHealth,
    sendAssistantMessage,
    resetAssistantChat,
  };

  return <FinXContext.Provider value={value}>{children}</FinXContext.Provider>;
};

export function useFinX(): FinXContextValue {
  const ctx = useContext(FinXContext);
  if (!ctx) throw new Error('useFinX must be used inside FinXProvider');
  return ctx;
}
