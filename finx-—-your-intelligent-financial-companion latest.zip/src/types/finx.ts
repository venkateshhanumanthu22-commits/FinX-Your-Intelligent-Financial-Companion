export type ThemeMode = 'dark' | 'light';

export type DomainId =
  | 'personal-finance'
  | 'product-business'
  | 'service-business'
  | 'investment-knowledge'
  | 'financial-intelligence';

export type AppRoute =
  | 'welcome'
  | 'login'
  | 'register'
  | 'dashboard'
  | DomainId
  | 'assistant'
  | 'messages'
  | 'documents'
  | 'planner'
  | 'extensions'
  | 'learning'
  | 'reports'
  | 'security'
  | 'settings';

export type LanguageCode =
  | 'en'
  | 'te'
  | 'hi'
  | 'ta'
  | 'kn'
  | 'ml'
  | 'bn'
  | 'mr'
  | 'gu'
  | 'pa'
  | 'ur'
  | 'or'
  | 'as'
  | 'es'
  | 'fr'
  | 'de'
  | 'ar'
  | 'zh'
  | 'ja'
  | 'ko'
  | 'pt';

export type VoiceLanguage = string;

export type DisplayCurrency = 'USD' | 'INR' | 'EUR' | 'GBP' | 'AED' | 'JPY';

export type AvatarCategory = 'male' | 'female' | 'neutral';

export type NeuralVoiceName = 'Kore' | 'Zephyr' | 'Puck' | 'Charon' | 'Fenrir';

export interface LanguagePreferences {
  useSameLanguageEverywhere: boolean;
  displayLanguage: LanguageCode;
  textAssistantLanguage: LanguageCode;
  voiceInputLocale: string;
  voiceOutputLocale: string;
  voiceOutputVoiceURI: string;
  autoSpeakResponses: boolean;
  displayCurrency: DisplayCurrency;
  neuralVoiceName?: NeuralVoiceName;
  preferNeuralVoice?: boolean;
  handsFreeLoop?: boolean;
}

export type VoiceStatus =
  | 'idle'
  | 'requesting-permission'
  | 'listening'
  | 'processing'
  | 'speaking'
  | 'error';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: 'Individual & Entrepreneur' | 'Product Business Owner' | 'Consultant' | 'Individual';
  businessName: string;
  currency: DisplayCurrency;
  avatarUrl: string;
  avatarCategory: AvatarCategory;
  avatarPresetId: string;
  customPhotoDataUrl?: string;
  enabledDomains: DomainId[];
  activeWorkspaceId: string;
  isDemoAccount: boolean;
  createdAt: string;
}

export interface WorkspaceProfile {
  id: string;
  ownerId: string;
  name: string;
  domain: DomainId;
  description?: string;
  currency: DisplayCurrency;
  isDefault: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLogEntry {
  id: string;
  ownerId: string;
  workspaceId: string;
  action: string;
  domain: string;
  summary: string;
  createdAt: string;
}

export interface AuthSession {
  user: UserProfile;
  sessionStartedAt: string;
  authMode: 'firebase-google' | 'firebase-email' | 'demo-local';
  tokenNotice: string;
  welcomeMessage?: string;
}

export type TransactionType = 'income' | 'expense';

export type PaymentMethod = 'UPI' | 'Bank Transfer' | 'Credit Card' | 'Debit Card' | 'Cash';

export interface PersonalTransaction {
  id: string;
  amount: number;
  description: string;
  category: string;
  date: string;
  paymentMethod: PaymentMethod;
  type: TransactionType;
  notes?: string;
}

export interface BudgetCategory {
  id: string;
  category: string;
  monthlyLimit: number;
  alertThresholdPercent: number;
}

export interface SavingsGoal {
  id: string;
  title: string;
  targetAmount: number;
  currentAmount: number;
  targetDate: string;
  priority: 'High' | 'Medium' | 'Low';
}

export interface BillItem {
  id: string;
  title: string;
  amount: number;
  dueDate: string;
  category: string;
  status: 'Paid' | 'Upcoming' | 'Overdue';
  autopay: boolean;
}

export interface SubscriptionItem {
  id: string;
  name: string;
  amount: number;
  billingCycle: 'Monthly' | 'Annual';
  nextBillingDate: string;
  category: string;
  active: boolean;
}

export interface ProductItem {
  id: string;
  productCode: string;
  name: string;
  category: string;
  purchaseCost: number;
  sellingPrice: number;
  availableQuantity: number;
  reorderLevel: number;
  unitsSold: number;
}

export interface SupplierItem {
  id: string;
  name: string;
  contact: string;
  category: string;
  leadTimeDays: number;
  notes?: string;
}

export interface CustomerItem {
  id: string;
  name: string;
  contact: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderDate: string;
}

export interface SaleRecord {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  totalAmount: number;
  date: string;
  customerName: string;
}

export interface PurchaseRecord {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
  supplier: string;
  date: string;
}

export interface BusinessExpense {
  id: string;
  domain: 'product' | 'service';
  category: string;
  description: string;
  amount: number;
  date: string;
}

export type ClientPaymentStatus = 'Paid' | 'Pending' | 'Overdue' | 'Partial';

export interface ServiceClient {
  id: string;
  name: string;
  contact: string;
  serviceProvided: string;
  agreedAmount: number;
  paidAmount: number;
  paymentStatus: ClientPaymentStatus;
  dueDate: string;
  projectTitle: string;
  lastUpdated: string;
}

export interface ServiceProject {
  id: string;
  clientId: string;
  clientName: string;
  title: string;
  status: 'Active' | 'Completed' | 'On Hold';
  startDate: string;
  milestoneValue: number;
  directCost?: number;
}

export interface ServiceInvoice {
  id: string;
  invoiceNumber: string;
  clientId: string;
  clientName: string;
  projectTitle: string;
  issueDate: string;
  dueDate: string;
  amount: number;
  paidAmount: number;
  status: ClientPaymentStatus;
  lineItems: { description: string; amount: number }[];
}

export interface PayrollRecord {
  id: string;
  memberName: string;
  role: string;
  amount: number;
  period: string;
  status: 'Paid' | 'Scheduled';
}

export interface PaperTradePosition {
  id: string;
  symbol: string;
  name: string;
  assetClass: 'Equity' | 'Index Fund' | 'Bond ETF';
  shares: number;
  simulatedEntryPrice: number;
  historicalReferencePrice: number;
  purchaseDate: string;
}

export interface MarketHistoryPoint {
  period: string;
  equityIndex: number;
  balancedFund: number;
  govtBondIndex: number;
}

export interface InvestmentTopic {
  id: string;
  title: string;
  category: 'Stocks' | 'Mutual Funds' | 'Bonds' | 'Terminology' | 'Risk & Return';
  summary: string;
  keyPoints: string[];
  riskLevel: 'Low' | 'Moderate' | 'High' | 'Educational';
}

export type NotificationType =
  | 'payment_received'
  | 'payment_sent'
  | 'payment_pending'
  | 'payment_failed'
  | 'refund_recorded'
  | 'business_payment_confirmation'
  | 'low_inventory'
  | 'budget_warning'
  | 'financial_reminder';

export interface FinXMessage {
  id: string;
  type: NotificationType;
  sender: string;
  title: string;
  content: string;
  amount?: number;
  referenceId?: string;
  sourceDomain: 'Personal Finance' | 'Product Business' | 'Service Business' | 'FinX System';
  timestamp: string;
  read: boolean;
  isSimulatedInternal: boolean;
}

export interface UploadedDocument {
  id: string;
  fileName: string;
  fileType: string;
  fileSizeKb: number;
  documentCategory: 'Invoice' | 'Receipt' | 'Financial Statement' | 'Expense Record' | 'Business Report';
  uploadedAt: string;
  status: 'Processed (Demo)' | 'Failed';
  extractedSummary: string;
  extractedFields: {
    vendorOrEntity?: string;
    documentDate?: string;
    detectedAmount?: number;
    suggestedCategory?: string;
    referenceNumber?: string;
  };
}

export interface FinancialPlanItem {
  id: string;
  title: string;
  planType: 'Monthly Budget' | 'Savings Goal' | 'Bill Reminder' | 'Business Cash-Flow';
  targetAmount: number;
  allocatedAmount: number;
  dueDate: string;
  status: 'On Track' | 'Attention Needed' | 'Completed';
  notes: string;
}

export type ExtensionCategory =
  | 'Finance'
  | 'Business'
  | 'AI Tools'
  | 'Analytics'
  | 'Documents'
  | 'Productivity'
  | 'Integrations';

export type ExtensionStatus = 'Installed' | 'Available' | 'Coming Soon' | 'Disabled';

export interface ExtensionDefinition {
  id: string;
  name: string;
  description: string;
  category: ExtensionCategory;
  version: string;
  minPlatformVersion: string;
  compatible: boolean;
  status: ExtensionStatus;
  optional: boolean;
  permissions: string[];
  dataBoundary: string;
  config: Record<string, string | boolean>;
}

export interface ExtensionActivityLog {
  id: string;
  extensionId: string;
  extensionName: string;
  action: string;
  timestamp: string;
  result: 'Success' | 'Blocked';
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface AssistantMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  mode: 'finance-assistant' | 'finx-guide';
  languageCode?: LanguageCode;
  detectedLanguage?: string;
  sources?: GroundingSource[];
  suggestedRoute?: AppRoute;
  suggestedRouteLabel?: string;
  isError?: boolean;
}

export interface VoiceDiagnosticInfo {
  origin: string;
  isSecureContext: boolean;
  mediaDevicesAvailable: boolean;
  speechRecognitionAvailable: boolean;
  speechSynthesisAvailable: boolean;
  permissionState: 'granted' | 'denied' | 'prompt' | 'unsupported';
  lastErrorName: string | null;
  lastErrorMessage: string | null;
  activeSpeechInputLocale: string;
  activeSpeechOutputLocale: string;
  availableVoicesCount: number;
}

export interface LearningArticle {
  id: string;
  topic: string;
  category: string;
  readTime: string;
  level: 'Beginner' | 'Intermediate';
  summary: string;
  sections: { heading: string; body: string }[];
  keyTakeaway: string;
}

export interface AppSettings {
  language: VoiceLanguage;
  autoListenInVoiceSession: boolean;
  voiceSpeechRate: number;
  budgetWarningNotifications: boolean;
  lowStockNotifications: boolean;
  paymentReminders: boolean;
  reducedMotion: boolean;
  highContrastNumbers: boolean;
}

export interface YtdUnifiedTransaction {
  id: string;
  workspaceId: string;
  workspaceName: string;
  domain: DomainId;
  recordKind:
    | 'personal_tx'
    | 'product_sale'
    | 'product_purchase'
    | 'business_expense'
    | 'service_payment'
    | 'payroll';
  txType: TransactionType;
  title: string;
  category: string;
  amount: number;
  date: string;
  counterparty?: string;
  paymentMethod?: string;
}

export interface ToastNotice {
  id: string;
  kind: 'success' | 'info' | 'warning' | 'error';
  title: string;
  description?: string;
}
