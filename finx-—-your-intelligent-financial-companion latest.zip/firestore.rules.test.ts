/**
 * Firestore Security Rules Verification Specification (Dirty Dozen + Valid Paths)
 * Run with Firebase Emulator Suite when validating rules locally:
 *   firebase emulators:exec --only firestore "npx tsx firestore.rules.test.ts"
 */
export interface RuleTestCase {
  id: string;
  description: string;
  path: string;
  operation: 'get' | 'list' | 'create' | 'update' | 'delete';
  authUid: string | null;
  emailVerified: boolean;
  expected: 'ALLOW' | 'PERMISSION_DENIED';
  payload?: Record<string, unknown>;
}

export const FINX_RULES_TEST_MATRIX: RuleTestCase[] = [
  {
    id: 'DD-01',
    description: 'Cross-tenant user profile read must fail',
    path: 'users/userA',
    operation: 'get',
    authUid: 'userB',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-02',
    description: 'Unverified email user write must fail',
    path: 'users/userA',
    operation: 'create',
    authUid: 'userA',
    emailVerified: false,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-03',
    description: 'Shadow field (isAdmin) on user profile create must fail',
    path: 'users/userA',
    operation: 'create',
    authUid: 'userA',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
    payload: { uid: 'userA', isAdmin: true },
  },
  {
    id: 'DD-04',
    description: 'Workspace ownerId spoofing must fail',
    path: 'users/userB/workspaces/ws1',
    operation: 'create',
    authUid: 'userB',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
    payload: { id: 'ws1', ownerId: 'userA', name: 'Hijacked', domain: 'product-business' },
  },
  {
    id: 'DD-05',
    description: 'Invalid document ID characters must fail',
    path: 'users/userA/workspaces/bad$id',
    operation: 'create',
    authUid: 'userA',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-06',
    description: 'Oversized customPhotoDataUrl (>65000 bytes) must fail',
    path: 'users/userA',
    operation: 'update',
    authUid: 'userA',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
    payload: { customPhotoDataUrl: 'x'.repeat(70000) },
  },
  {
    id: 'DD-07',
    description: 'Orphan ledger entry without existing parent workspace must fail',
    path: 'users/userA/workspaces/missing_ws/ledgerEntries/tx1',
    operation: 'create',
    authUid: 'userA',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-08',
    description: 'Negative ledger amount must fail',
    path: 'users/userA/workspaces/ws1/ledgerEntries/tx_neg',
    operation: 'create',
    authUid: 'userA',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
    payload: { amount: -150 },
  },
  {
    id: 'DD-09',
    description: 'Immutable ownerId reassignment on workspace update must fail',
    path: 'users/userA/workspaces/ws1',
    operation: 'update',
    authUid: 'userA',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
    payload: { ownerId: 'userB' },
  },
  {
    id: 'DD-10',
    description: 'Audit log deletion or mutation must fail',
    path: 'users/userA/auditLogs/log1',
    operation: 'delete',
    authUid: 'userA',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-11',
    description: 'Default workspace deletion must fail',
    path: 'users/userA/workspaces/ws_default',
    operation: 'delete',
    authUid: 'userA',
    emailVerified: true,
    expected: 'PERMISSION_DENIED',
  },
  {
    id: 'DD-12',
    description: 'Unauthenticated list on workspaces must fail',
    path: 'users/userA/workspaces',
    operation: 'list',
    authUid: null,
    emailVerified: false,
    expected: 'PERMISSION_DENIED',
  },
];
