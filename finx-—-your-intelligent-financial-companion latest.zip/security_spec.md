# FinX Security Specification & Dirty Dozen Adversarial Matrix

## 1. Core Data Invariants
1. **Strict Ownership**: Every document under `/users/{userId}` and its subcollections (`/workspaces`, `/ledgerEntries`, `/domainEntities`, `/auditLogs`) can only be read or written by the authenticated, email-verified user whose `request.auth.uid == userId` and matches `ownerId`/`uid`.
2. **Workspace Referential Integrity**: Creating a `ledgerEntry` or `domainEntity` inside `/users/{userId}/workspaces/{workspaceId}` requires the parent workspace document to exist and belong to `userId`.
3. **Zero Unbounded Arrays & Payload Caps**: `enabledDomains` on user profiles is strictly capped at `<= 5` items; `customPhotoDataUrl` is capped at `<= 65000` characters; all strings and document IDs are strictly size- and regex-validated.
4. **Temporal Integrity & Immutability**: `createdAt` and `updatedAt` must equal `request.time` on create; `ownerId`, `uid`, `workspaceId`, and `createdAt` are immutable on update; `auditLogs` are append-only (no client updates or deletes).
5. **No Shadow Fields**: Both `create` and `update` reject any unexpected keys via `keys().hasOnly(...)` and `diff().affectedKeys().hasOnly(...)`.

## 2. The "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. **Cross-Tenant Profile Read/Write**: User B attempts `get`/`update` on `/users/userA`.
2. **Unverified Email Spoof**: Request with `email_verified: false` attempts write to `/users/userA`.
3. **Ghost Shadow Field on Create**: Creating `/users/userA` with extra `{ isAdmin: true }` field.
4. **UID Spoofing**: User B creates `/users/userB/workspaces/ws1` with `ownerId: 'userA'`.
5. **ID Poisoning**: Document ID > 128 chars or containing `/` / `$` characters.
6. **Oversized Avatar DoS**: Updating `customPhotoDataUrl` with a 250KB string (`> 65000` chars).
7. **Orphan Ledger Entry**: Creating a `ledgerEntry` under a non-existent `workspaceId`.
8. **Negative / Non-Numeric Ledger Amount**: Creating a `ledgerEntry` with `amount: -500` or `amount: "1000"`.
9. **Client Timestamp Forgery**: Creating a `ledgerEntry` with backdated `createdAt` instead of `serverTimestamp()`.
10. **Immutable Owner Tampering**: Updating an existing `workspace` to reassign `ownerId`.
11. **Audit Log Tampering**: User A attempts to `update` or `delete` an entry in `/users/userA/auditLogs/{logId}`.
12. **Blanket Collection Scraping**: Unauthenticated or cross-user `list` query on `/users/userA/workspaces`.
