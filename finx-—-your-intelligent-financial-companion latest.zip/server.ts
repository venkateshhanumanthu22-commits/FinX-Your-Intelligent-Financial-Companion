import 'dotenv/config';
import http from 'http';
import express, { type NextFunction, type Request, type Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, ThinkingLevel } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function resolveServerPort(): number {
  const portFlagIndex = process.argv.indexOf('--port');
  if (portFlagIndex !== -1 && process.argv[portFlagIndex + 1]) {
    const cliPort = Number(process.argv[portFlagIndex + 1]);
    if (Number.isFinite(cliPort) && cliPort > 0) return cliPort;
  }
  const envPort = Number(process.env.PORT || 3000);
  return Number.isFinite(envPort) && envPort > 0 ? envPort : 3000;
}

const PORT = resolveServerPort();
const GEMINI_MODEL = 'gemini-4-hydrogen';
const FALLBACK_GEMINI_MODEL = 'gemini-3.1-flash-lite';
const TTS_GEMINI_MODEL = 'gemini-3.8-flash-lite-tts';
const TRANSCRIBE_GEMINI_MODEL = 'gemini-3.5-transcribe';
const ALLOWED_NEURAL_VOICES = new Set(['Kore', 'Zephyr', 'Puck', 'Charon', 'Fenrir']);

interface ChatHistoryTurn {
  role: 'user' | 'assistant';
  content: string;
}

interface AssistantChatRequest {
  message?: string;
  history?: ChatHistoryTurn[];
  language?: string;
  languageLabel?: string;
  mode?: 'finance-assistant' | 'finx-guide';
  isAuthenticated?: boolean;
  currentRoute?: string;
  authorizedSummary?: Record<string, unknown> | null;
}

interface GroundingSource {
  title: string;
  uri: string;
}

function createGeminiClient(apiVersion: 'v1beta' | 'v1alpha' = 'v1beta'): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    apiVersion,
    httpOptions: {
      apiVersion,
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function buildSystemInstruction(payload: AssistantChatRequest): string {
  const preferredLang = payload.languageLabel || payload.language || 'English (en-US)';
  const todayIso = new Date().toISOString().slice(0, 10);

  const languageRule = `LANGUAGE & FRIENDLY COMPANION RULE:
- Default preferred language: ${preferredLang}.
- SPONTANEOUS CHAT LANGUAGE SWITCHING: Carefully detect the language of the user's LATEST message (for example Telugu, Hindi, Tamil, Kannada, Malayalam, Spanish, French, Arabic, English, or even mixed conversational transliteration like Telugu/Hindi in Latin script if clearly asked). If the user explicitly asks to speak in another language OR writes their message in a different language, respond warmly and naturally in THAT language without requiring any website settings change! Otherwise respond in ${preferredLang}.
- Preserve all financial figures, currency values, percentages, dates, and reference numbers with 100% numeric accuracy.`;

  const truthAndGroundingRule = `CURRENT DATE: ${todayIso}.
LIVE INFORMATION & TRUTH DISTINCTION:
- You have live Google Search grounding available. Whenever the user asks about current news, live market trends, interest rates, inflation, tax/regulatory updates, FX rates, or real-world facts, use Google Search so your answer is current and well-sourced.
- Clearly distinguish between:
  1) Verified current facts (cite date/source context),
  2) User's own authorized workspace records (from AUTHORIZED_WORKSPACE_DATA below),
  3) Deterministic estimates or educational explanations.
- NEVER fabricate fake market quotes, fake news, or unverified transaction records. If you cannot verify a live figure, say so clearly and kindly.`;

  const authRule = payload.isAuthenticated
    ? `AUTHENTICATED WORKSPACE ACCESS:
The user is signed in. You may read and cite ONLY verified figures inside AUTHORIZED_WORKSPACE_DATA below. Never invent transactions, clients, balances, or products absent from AUTHORIZED_WORKSPACE_DATA.`
    : `PRE-LOGIN PRIVACY PROTECTION:
The user is NOT signed in yet. Do NOT expose, guess, or invent any personal balances, private transactions, or business revenue. If they ask about their private account figures, warmly explain that personal records stay private until they click "Login to Workspace" or "Get Started", while remaining happy to answer general finance, market, or FinX platform questions.`;

  const modeRule =
    payload.mode === 'finx-guide'
      ? `MODE — FINX GUIDE: Be an approachable, friendly product guide. Give clear step-by-step guidance for FinX screens (Dashboard, Personal Finance, Product Business, Service & Consultancy, Investment Knowledge, Financial Intelligence, YTD Transactions Drawer, FinX Messages, Document Analyzer, Smart Planner, Extension Center, Learning Center, Reports, Privacy & Security, Settings).`
      : `MODE — FINX INTELLIGENT COMPANION: Be warm, conversational, encouraging, and practical across all 5 FinX domains: 1) Personal Finance, 2) Product-Based Business, 3) Service & Consultancy, 4) Investment Knowledge (strictly educational, never personalized financial advice or guaranteed returns), and 5) Financial Intelligence.`;

  const formattingAndDirectives = `STYLE & ACTION DIRECTIVES:
- Keep answers friendly, clear, and well-paced for reading or voice listening (2–4 concise paragraphs or crisp bullet points). Avoid repeating greetings or canned boilerplate.
- Never authorize payments, UPI transfers, bank logins, OTPs, PINs, or real-money trades.
- Optional machine metadata tags ONLY at the very end on their own line if relevant (the server strips these before displaying):
  - If user asks to switch to a screen: [FINX_NAV:<route>] where route is one of: welcome, login, register, dashboard, personal-finance, product-business, service-business, investment-knowledge, financial-intelligence, assistant, messages, documents, planner, extensions, learning, reports, security, settings
  - If user asks to toggle theme: [FINX_THEME:dark] or [FINX_THEME:light]
  - Always include: [FINX_LANG:<English name of the language you replied in, e.g. English, Telugu, Hindi>]`;

  const authorizedBlock =
    payload.isAuthenticated && payload.authorizedSummary
      ? `\nAUTHORIZED_WORKSPACE_DATA (verified user state — cite only what is here):\n${JSON.stringify(payload.authorizedSummary)}`
      : '';

  return [
    `Identity: FinX — Your Friendly, Secure Intelligent Financial Companion.`,
    `Current Screen: ${payload.currentRoute || 'welcome'}`,
    languageRule,
    truthAndGroundingRule,
    modeRule,
    authRule,
    formattingAndDirectives,
    authorizedBlock,
  ].join('\n\n');
}

function parseAssistantOutput(rawText: string): {
  reply: string;
  navigationRoute: string | null;
  themeAction: 'dark' | 'light' | null;
  detectedLanguage: string | null;
} {
  let text = rawText.trim();
  let navigationRoute: string | null = null;
  let themeAction: 'dark' | 'light' | null = null;
  let detectedLanguage: string | null = null;

  const navMatch = text.match(/\[FINX_NAV:([a-z-]+)\]/i);
  if (navMatch) {
    navigationRoute = navMatch[1].toLowerCase();
    text = text.replace(navMatch[0], '');
  }

  const themeMatch = text.match(/\[FINX_THEME:(dark|light)\]/i);
  if (themeMatch) {
    themeAction = themeMatch[1].toLowerCase() as 'dark' | 'light';
    text = text.replace(themeMatch[0], '');
  }

  const langMatch = text.match(/\[FINX_LANG:([^\]]+)\]/i);
  if (langMatch) {
    detectedLanguage = langMatch[1].trim();
    text = text.replace(langMatch[0], '');
  }

  return {
    reply: text.trim(),
    navigationRoute,
    themeAction,
    detectedLanguage,
  };
}

function extractGroundingSources(response: unknown): GroundingSource[] {
  const seen = new Set<string>();
  const sources: GroundingSource[] = [];
  const candidates = (response as { candidates?: Array<{ groundingMetadata?: { groundingChunks?: Array<{ web?: { uri?: string; title?: string } }> } }> })?.candidates;
  const chunks = candidates?.[0]?.groundingMetadata?.groundingChunks;
  if (!Array.isArray(chunks)) return sources;

  for (const chunk of chunks) {
    const uri = chunk?.web?.uri?.trim();
    const title = chunk?.web?.title?.trim() || uri;
    if (uri && !seen.has(uri)) {
      seen.add(uri);
      sources.push({ title: title || 'Web Source', uri });
    }
    if (sources.length >= 6) break;
  }
  return sources;
}

function parseFriendlyUpstreamError(
  err: unknown,
  context: 'chat' | 'tts' | 'transcribe'
): { status: number; message: string; code: string; isTransientNotice: boolean } {
  const errorObj = err as { status?: number; message?: string; name?: string };
  const rawMsg = String(errorObj?.message || '');

  let parsedMessage = '';
  let parsedStatusText = '';
  let parsedCodeNum: number | undefined;
  if (rawMsg.trim().startsWith('{')) {
    try {
      const obj = JSON.parse(rawMsg) as { error?: { code?: number; message?: string; status?: string } };
      if (obj?.error) {
        parsedCodeNum = typeof obj.error.code === 'number' ? obj.error.code : undefined;
        parsedMessage = typeof obj.error.message === 'string' ? obj.error.message : '';
        parsedStatusText = typeof obj.error.status === 'string' ? obj.error.status : '';
      }
    } catch {
      // Ignore non-JSON error message
    }
  }

  const combinedText = `${rawMsg} ${parsedMessage} ${parsedStatusText}`.toLowerCase();
  const numericStatus =
    typeof errorObj?.status === 'number'
      ? errorObj.status
      : typeof parsedCodeNum === 'number'
        ? parsedCodeNum
        : 500;

  const isTimeout =
    errorObj?.name === 'TimeoutError' ||
    errorObj?.name === 'AbortError' ||
    combinedText.includes('timeout') ||
    numericStatus === 504;
  if (isTimeout) {
    return {
      status: 504,
      message:
        context === 'tts'
          ? 'Neural voice took too long to respond.'
          : context === 'transcribe'
            ? 'Audio transcription timed out. Please speak a shorter phrase or try again.'
            : 'The AI service took too long to respond. Please try again.',
      code: context === 'tts' ? 'TTS_TIMEOUT' : context === 'transcribe' ? 'TRANSCRIBE_TIMEOUT' : 'AI_TIMEOUT',
      isTransientNotice: true,
    };
  }

  const isQuota =
    numericStatus === 429 ||
    combinedText.includes('429') ||
    combinedText.includes('resource_exhausted');
  if (isQuota) {
    return {
      status: 429,
      message:
        context === 'tts'
          ? 'Neural voice rate limit reached temporarily.'
          : context === 'transcribe'
            ? 'Audio transcription rate limit reached temporarily.'
            : 'FinX AI is experiencing high demand right now and reached a temporary rate limit. Please wait a few seconds and try again.',
      code: context === 'tts' ? 'TTS_QUOTA' : context === 'transcribe' ? 'TRANSCRIBE_QUOTA' : 'AI_QUOTA_EXCEEDED',
      isTransientNotice: true,
    };
  }

  const isBusy =
    numericStatus === 503 ||
    parsedStatusText === 'UNAVAILABLE' ||
    combinedText.includes('high demand') ||
    combinedText.includes('overloaded');
  if (isBusy) {
    return {
      status: 503,
      message:
        context === 'tts'
          ? 'Neural voice service is temporarily busy. Please retry shortly.'
          : context === 'transcribe'
            ? 'Audio transcription service is temporarily busy. Please try again shortly.'
            : 'FinX AI is experiencing temporary high demand right now. Please try again in a few seconds.',
      code: context === 'tts' ? 'TTS_BUSY' : context === 'transcribe' ? 'TRANSCRIBE_BUSY' : 'AI_BUSY',
      isTransientNotice: true,
    };
  }

  const isAuthErr =
    numericStatus === 401 ||
    numericStatus === 403 ||
    combinedText.includes('api_key_invalid') ||
    combinedText.includes('permission_denied');
  if (isAuthErr) {
    return {
      status: 503,
      message: 'FinX AI credentials need attention in Settings > Secrets.',
      code: 'AI_AUTH_ERROR',
      isTransientNotice: false,
    };
  }

  const isInvalidArg = numericStatus === 400 || parsedStatusText === 'INVALID_ARGUMENT';
  if (isInvalidArg) {
    return {
      status: 400,
      message:
        context === 'transcribe'
          ? 'Audio clip could not be decoded. Please record a clear 1–10 second message and try again.'
          : parsedMessage || 'The AI request payload could not be processed.',
      code: context === 'tts' ? 'TTS_INVALID_REQUEST' : context === 'transcribe' ? 'TRANSCRIBE_INVALID_AUDIO' : 'AI_INVALID_REQUEST',
      isTransientNotice: true,
    };
  }

  return {
    status: numericStatus >= 400 && numericStatus < 600 ? numericStatus : 500,
    message:
      context === 'tts'
        ? 'Neural speech synthesis is temporarily unavailable.'
        : context === 'transcribe'
          ? 'Audio transcription failed. Please try speaking again.'
          : 'Unable to reach the FinX AI assistant service right now.',
    code: context === 'tts' ? 'TTS_ERROR' : context === 'transcribe' ? 'TRANSCRIBE_ERROR' : 'AI_UPSTREAM_ERROR',
    isTransientNotice: false,
  };
}

async function startServer() {
  const app = express();
  const httpServer = http.createServer(app);

  const json1mb = express.json({ limit: '1mb' });
  app.use((req: Request, res: Response, next: NextFunction) => {
    if (req.path === '/api/assistant/transcribe') {
      next();
      return;
    }
    json1mb(req, res, next);
  });

  let lastChatStatus: {
    startedAt?: string;
    finishedAt?: string;
    durationMs?: number;
    outcome?: string;
    error?: string;
  } | null = null;

  let hydrogenSearchCooldownUntil = 0;
  let hydrogenPlainCooldownUntil = 0;
  let flashSearchCooldownUntil = 0;

  const ttsCache = new Map<string, { audioBase64: string; voiceName: string; ts: number }>();
  const TTS_CACHE_MAX = 30;
  const TTS_CACHE_TTL_MS = 30 * 60 * 1000;

  app.get('/api/assistant/health', (_req: Request, res: Response) => {
    const client = createGeminiClient('v1beta');
    res.json({
      status: 'ok',
      aiConfigured: Boolean(client),
      model: GEMINI_MODEL,
      ttsModel: TTS_GEMINI_MODEL,
      transcribeModel: TRANSCRIBE_GEMINI_MODEL,
      groundingEnabled: true,
      backendTarget: 'Express API Bridge (Firebase + FastAPI contract ready)',
      lastChatStatus,
    });
  });

  app.post('/api/assistant/chat', async (req: Request, res: Response) => {
    const startedMs = Date.now();
    lastChatStatus = { startedAt: new Date(startedMs).toISOString(), outcome: 'in_progress' };

    try {
      const body = (req.body || {}) as AssistantChatRequest;
      const userMessage = typeof body.message === 'string' ? body.message.trim() : '';

      if (!userMessage) {
        lastChatStatus = {
          startedAt: lastChatStatus.startedAt,
          finishedAt: new Date().toISOString(),
          durationMs: Date.now() - startedMs,
          outcome: 'empty_message',
        };
        res.status(400).json({
          error: 'Message text is required.',
          code: 'EMPTY_MESSAGE',
        });
        return;
      }

      const ai = createGeminiClient('v1beta');
      if (!ai) {
        lastChatStatus = {
          startedAt: lastChatStatus.startedAt,
          finishedAt: new Date().toISOString(),
          durationMs: Date.now() - startedMs,
          outcome: 'ai_unavailable',
        };
        res.status(503).json({
          error: 'FinX AI assistant is currently unavailable. Please try again in a few minutes.',
          code: 'AI_UNAVAILABLE',
        });
        return;
      }

      const history = Array.isArray(body.history) ? body.history.slice(-12) : [];
      const contents = [
        ...history
          .filter((turn) => turn && typeof turn.content === 'string' && turn.content.trim().length > 0)
          .map((turn) => ({
            role: turn.role === 'assistant' ? 'model' : 'user',
            parts: [{ text: turn.content }],
          })),
        {
          role: 'user',
          parts: [{ text: userMessage }],
        },
      ];

      const systemInstruction = buildSystemInstruction(body);
      const nowMs = Date.now();
      const wantsLiveWebSearch =
        /\b(today|current|latest|now|news|rate|rates|repo|fed|rbi|inflation|gdp|cpi|tax|stock|nifty|sensex|nasdaq|sp500|s&p|crypto|bitcoin|gold|silver|usd|inr|eur|exchange|price|market|forecast|2025|2026|2027|update|regulation)\b/i.test(
          userMessage
        ) || body.currentRoute === 'investment-knowledge';

      const attempts: Array<{
        key: 'h_search' | 'h_plain' | 'f_search' | 'f_plain';
        model: string;
        useSearch: boolean;
        thinkingLow: boolean;
        timeoutMs: number;
      }> = [];

      if (wantsLiveWebSearch && nowMs >= hydrogenSearchCooldownUntil) {
        attempts.push({ key: 'h_search', model: GEMINI_MODEL, useSearch: true, thinkingLow: true, timeoutMs: 10000 });
      }
      if (nowMs >= hydrogenPlainCooldownUntil) {
        attempts.push({ key: 'h_plain', model: GEMINI_MODEL, useSearch: false, thinkingLow: true, timeoutMs: 11000 });
      }
      if (wantsLiveWebSearch && nowMs >= flashSearchCooldownUntil) {
        attempts.push({ key: 'f_search', model: FALLBACK_GEMINI_MODEL, useSearch: true, thinkingLow: false, timeoutMs: 12000 });
      }
      attempts.push({ key: 'f_plain', model: FALLBACK_GEMINI_MODEL, useSearch: false, thinkingLow: false, timeoutMs: 18000 });
      attempts.push({ key: 'f_plain', model: FALLBACK_GEMINI_MODEL, useSearch: false, thinkingLow: false, timeoutMs: 20000 });

      let usedModel = GEMINI_MODEL;
      let response: Awaited<ReturnType<typeof ai.models.generateContent>> | null = null;
      let lastErr: unknown = null;

      for (let i = 0; i < attempts.length; i += 1) {
        const attempt = attempts[i];
        try {
          usedModel = attempt.model;
          response = await ai.models.generateContent({
            model: attempt.model,
            contents,
            config: {
              abortSignal: AbortSignal.timeout(attempt.timeoutMs),
              systemInstruction,
              ...(attempt.thinkingLow ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
              ...(attempt.useSearch ? { tools: [{ googleSearch: {} }] } : {}),
            },
          });
          if (response) break;
        } catch (attemptErr: unknown) {
          lastErr = attemptErr;
          const errName = (attemptErr as { name?: string })?.name || '';
          const msg = String((attemptErr as { message?: string })?.message || '');
          const st = (attemptErr as { status?: number })?.status;
          const isQuotaErr = st === 429 || msg.includes('429') || msg.includes('RESOURCE_EXHAUSTED');
          const isTimeoutErr = errName === 'TimeoutError' || errName === 'AbortError' || msg.toLowerCase().includes('timeout');
          const isBusyErr = st === 503 || msg.includes('UNAVAILABLE') || msg.toLowerCase().includes('high demand');
          const isRetryable =
            isTimeoutErr ||
            isQuotaErr ||
            isBusyErr ||
            st === 500 ||
            st === 502 ||
            st === 504 ||
            msg.includes('googleSearch');

          if (isRetryable) {
            if (isQuotaErr || isBusyErr) {
              const cooldownUntil = Date.now() + 90_000;
              if (attempt.key === 'h_search') hydrogenSearchCooldownUntil = cooldownUntil;
              if (attempt.key === 'h_plain') hydrogenPlainCooldownUntil = cooldownUntil;
              if (attempt.key === 'f_search') flashSearchCooldownUntil = cooldownUntil;
            }
            if (i < attempts.length - 1) {
              await new Promise((resolve) => setTimeout(resolve, isBusyErr ? 450 : 150));
            }
          } else {
            throw attemptErr;
          }
        }
      }

      if (!response) {
        throw lastErr || new Error('FinX AI service is temporarily busy. Please try again shortly.');
      }

      const rawText = response.text?.trim();
      if (!rawText) {
        lastChatStatus = {
          startedAt: lastChatStatus.startedAt,
          finishedAt: new Date().toISOString(),
          durationMs: Date.now() - startedMs,
          outcome: 'empty_ai_response',
        };
        res.status(502).json({
          error: 'The AI service returned an empty response. Please try again.',
          code: 'EMPTY_AI_RESPONSE',
        });
        return;
      }

      const parsed = parseAssistantOutput(rawText);
      const sources = extractGroundingSources(response);

      lastChatStatus = {
        startedAt: lastChatStatus.startedAt,
        finishedAt: new Date().toISOString(),
        durationMs: Date.now() - startedMs,
        outcome: 'ok',
      };

      res.json({
        reply: parsed.reply,
        followUpSuggestion: null,
        navigationRoute: body.isAuthenticated ? parsed.navigationRoute : null,
        themeAction: parsed.themeAction,
        detectedLanguage: parsed.detectedLanguage,
        sources,
        model: usedModel,
      });
    } catch (err: unknown) {
      const friendly = parseFriendlyUpstreamError(err, 'chat');

      lastChatStatus = {
        startedAt: lastChatStatus?.startedAt,
        finishedAt: new Date().toISOString(),
        durationMs: Date.now() - startedMs,
        outcome: friendly.code.toLowerCase(),
        error: friendly.message,
      };
      if (friendly.isTransientNotice) {
        console.warn('[FinX AI Notice]', friendly.status, friendly.message);
      } else {
        console.error('[FinX AI Error]', friendly.status, friendly.message);
      }
      res.status(friendly.status).json({
        error: friendly.message,
        code: friendly.code,
      });
    }
  });

  app.post('/api/assistant/tts', async (req: Request, res: Response) => {
    try {
      const body = (req.body || {}) as {
        text?: string;
        voiceName?: string;
        languageLabel?: string;
        style?: string;
      };
      const rawText = typeof body.text === 'string' ? body.text : '';
      const cleaned = rawText
        .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
        .replace(/[*_`#>]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 950);

      if (!cleaned) {
        res.status(400).json({ error: 'Text is required for speech synthesis.', code: 'EMPTY_TTS_TEXT' });
        return;
      }

      const ai = createGeminiClient('v1beta');
      if (!ai) {
        res.status(503).json({ error: 'Speech synthesis is temporarily unavailable.', code: 'AI_UNAVAILABLE' });
        return;
      }

      const voiceName = ALLOWED_NEURAL_VOICES.has(String(body.voiceName))
        ? String(body.voiceName)
        : 'Kore';

      const cacheKey = `${voiceName}:${body.languageLabel || 'auto'}:${cleaned}`;
      const cached = ttsCache.get(cacheKey);
      if (cached && Date.now() - cached.ts < TTS_CACHE_TTL_MS) {
        res.json({
          audioBase64: cached.audioBase64,
          mimeType: 'audio/wav',
          voiceName: cached.voiceName,
          model: TTS_GEMINI_MODEL,
          cached: true,
        });
        return;
      }

      const response = await ai.models.generateContent({
        model: TTS_GEMINI_MODEL,
        contents: [
          {
            role: 'user',
            parts: [{ text: cleaned }],
          },
        ],
        config: {
          abortSignal: AbortSignal.timeout(15000),
          responseModalities: ['AUDIO'],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
          },
        },
      });

      const audioPart = response.candidates?.[0]?.content?.parts?.find((part) => part.inlineData?.data);
      const base64Audio = audioPart?.inlineData?.data;
      const detectedMime = audioPart?.inlineData?.mimeType || 'audio/wav';
      if (!base64Audio) {
        res.status(502).json({ error: 'No audio returned by TTS model.', code: 'EMPTY_TTS_AUDIO' });
        return;
      }

      if (ttsCache.size >= TTS_CACHE_MAX) {
        const oldestKey = ttsCache.keys().next().value;
        if (oldestKey) ttsCache.delete(oldestKey);
      }
      ttsCache.set(cacheKey, { audioBase64: base64Audio, voiceName, ts: Date.now() });

      res.json({
        audioBase64: base64Audio,
        mimeType: detectedMime,
        voiceName,
        model: TTS_GEMINI_MODEL,
        cached: false,
      });
    } catch (err: unknown) {
      const friendly = parseFriendlyUpstreamError(err, 'tts');
      console.warn('[FinX TTS Notice]', friendly.status, friendly.message);
      res.status(friendly.status).json({
        error: friendly.message,
        code: friendly.code,
      });
    }
  });

  app.post('/api/assistant/transcribe', express.json({ limit: '10mb' }), async (req: Request, res: Response) => {
    try {
      const body = (req.body || {}) as {
        audioBase64?: string;
        mimeType?: string;
        languageHint?: string;
      };
      const rawBase64 = typeof body.audioBase64 === 'string' ? body.audioBase64.trim() : '';
      const cleanBase64 = rawBase64.replace(/^data:[^;]+;base64,/, '');

      if (!cleanBase64 || cleanBase64.length < 32) {
        res.status(400).json({ error: 'Recorded audio payload is required.', code: 'EMPTY_AUDIO' });
        return;
      }

      const ai = createGeminiClient('v1beta');
      if (!ai) {
        res.status(503).json({ error: 'Audio transcription is temporarily unavailable.', code: 'AI_UNAVAILABLE' });
        return;
      }

      const safeMimeType =
        typeof body.mimeType === 'string' && /^audio\/(webm|wav|mp3|mpeg|ogg|mp4|aac|flac)/.test(body.mimeType)
          ? body.mimeType.split(';')[0]
          : 'audio/webm';

      const promptText =
        typeof body.languageHint === 'string' && body.languageHint.trim()
          ? `Transcribe this speech accurately in its original spoken language (expected locale: ${body.languageHint.trim()}). Return only the spoken words.`
          : 'Transcribe this speech accurately in its original spoken language. Return only the spoken words.';

      const response = await ai.models.generateContent({
        model: TRANSCRIBE_GEMINI_MODEL,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: safeMimeType,
                data: cleanBase64,
              },
            },
            { text: promptText },
          ],
        },
        config: {
          abortSignal: AbortSignal.timeout(15000),
        },
      });

      const transcript = response.text?.trim() || '';
      res.json({
        transcript,
        model: TRANSCRIBE_GEMINI_MODEL,
      });
    } catch (err: unknown) {
      const friendly = parseFriendlyUpstreamError(err, 'transcribe');
      console.warn('[FinX Transcribe Notice]', friendly.status, friendly.message);
      res.status(friendly.status).json({
        error: friendly.message,
        code: friendly.code,
      });
    }
  });

  app.use((err: unknown, req: Request, res: Response, next: NextFunction) => {
    if (!req.path.startsWith('/api')) {
      next(err);
      return;
    }
    const errObj = err as { type?: string; status?: number; message?: string };
    if (errObj?.type === 'entity.too.large' || errObj?.status === 413) {
      res.status(413).json({
        error: 'Audio or JSON payload exceeds the allowed upload limit.',
        code: 'PAYLOAD_TOO_LARGE',
      });
      return;
    }
    if (err instanceof SyntaxError || errObj?.status === 400) {
      res.status(400).json({
        error: 'Malformed JSON request payload.',
        code: 'INVALID_JSON',
      });
      return;
    }
    res.status(500).json({
      error: errObj?.message || 'Unexpected API error.',
      code: 'INTERNAL_API_ERROR',
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR == 'true' ? { server: httpServer } : false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, '0.0.0.0', () => {
    console.log(`FinX server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start FinX server:', error);
  process.exit(1);
});
